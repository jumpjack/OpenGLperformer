/*******************************************************

	PROPRIETARY RIGHTS NOTICE: All rights reserved. This program
	contains proprietary information and trade secrets of 
        MultiGen-Paradigm Inc. of San Jose, CA., and embodies 
        substantial creative efforts and confidential information, 
        ideas, and expressions.  No part of this program may be 
        reproduced in any form, or by any means electronic, 
        mechanical, or otherwise, without the written permission 
        of MultiGen-Paradigm Inc..

	COPYRIGHT NOTICE: Copyright (C) 1986 to 1999, 
        MultiGen-Paradigm Inc., 550 South Winchester Blvd, STE 500
	San Jose CA 95128.
   
*******************************************************/

/*
 * Copyright 1992, 1997 Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * UNPUBLISHED -- Rights reserved under the copyright laws of the United
 * States.   Use of a copyright notice is precautionary only and does not
 * imply publication or disclosure.
 *
 * U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 * Use, duplication or disclosure by the Government is subject to restrictions
 * as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 * in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 * in similar or successor clauses in the FAR, or the DOD or NASA FAR
 * Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 * 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 *
 * THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 * INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 * DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 * PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 * GRAPHICS, INC.
 */

/*
 * $RCSfile: pfflt.h,v $
 * $Revision: 1.2 $ 
 * $Date: 2005/01/28 02:52:41 $ 
 */

#ifndef pfflt_h
#define pfflt_h

#ifdef WIN32

	#if defined(_PSI_STATIC_LIBS) || defined(PFSTATICLIB)
		/* building static*/
		#define PFFLT_DLLEXPORT
	#else 
		#ifdef _EXPORT_PFFLT
			/* Building DLL - need to export */
			#define PFFLT_DLLEXPORT	__declspec( dllexport )
		#else
			/* Using DLL - need to import */
			#define PFFLT_DLLEXPORT	__declspec( dllimport )
		#endif
	#endif

#else

	#define PFFLT_DLLEXPORT 

#endif

#ifndef WIN32
        #include <assert.h>
        #define ASSERT assert

#endif

#ifdef __cplusplus
extern "C" {
#endif

PFFLT_DLLEXPORT pfNode*	pfdLoadFile_flt ( char const* file );
PFFLT_DLLEXPORT void	pfdConverterAttr_flt ( int attr, void* val );
PFFLT_DLLEXPORT void*	pfdGetConverterAttr_flt ( int attr );
PFFLT_DLLEXPORT void	pfdConverterMode_flt ( int mode, int val );
PFFLT_DLLEXPORT int	pfdGetConverterMode_flt ( int mode );
PFFLT_DLLEXPORT void	pfdExitConverter_flt ( void );
PFFLT_DLLEXPORT int     pfdInitConverter_flt ( void );
PFFLT_DLLEXPORT void	pfdConverterVal_flt ( int which, float val );
PFFLT_DLLEXPORT float	pfdGetConverterVal_flt ( int which );

    /*------------------------------------------------------------*/
    /*----pfdConverter*_flt() stuff-------------------------------*/

/* loader attrs */
#define PFFLT_REGISTER_NODE		1
#define PFFLT_REGISTER_NODEDATA		2
#define PFFLT_REGISTER_USERDATA		PFFLT_REGISTER_NODEDATA	/* deprecated */
#define PFFLT_REGISTER_DRIVERS		3
#define PFFLT_REGISTER_DRIVERDATA	4

/* loader modes */
#define PFFLT_FLATTEN			1
#define PFFLT_CLEAN			2
#define PFFLT_COMBINELODS		3
#define PFFLT_SEQUENCES			4
#define PFFLT_AMBIENT_IS_DIFFUSE	5
#define PFFLT_SHOWTSTRIPS		6
#define PFFLT_COMPUTENORMALS		7
#define PFFLT_MONOCHROME		8
#define PFFLT_LAYER			9
#define PFFLT_USELONGIDS		10
#define PFFLT_USEUNITS			11
#define PFFLT_AUTO_ORIENT		12
#define PFFLT_GSTATE_TABLES		13
#define PFFLT_USE_ATTRIBUTES		14	/* same as fltAttrE, not used */
#define PFFLT_LPSTATE_TEX		15	/*MCB: obsolete for now*/
#define PFFLT_INHERIT_GSTATE		16
#define PFFLT_OLD_STYLE_XREFS		17
#define PFFLT_FORCE_XREF_FLAGS		18
#define PFFLT_TRANSPARENCY		19
#define PFFLT_USE_TEXMAP		20
#define PFFLT_CAT_ALGORITHM		21
#define PFFLT_CAT_SCALAR		22
#define PFFLT_CAT_SCALER		22	/*MCB: deprecated*/
#define PFFLT_SHARE_LPSTATE		23
#define PFFLT_USE_ALIGN_ZOFFSET		24
#define PFFLT_COLLAPSE_GEOM		25
#define PFFLT_BEHAVIORS			26
#define PFFLT_CENTER_CLIPTEX		27
#define PFFLT_SORT_FEATURE		28
#define PFFLT_LPSTATE_ANIM  	    	29
#if ! (PF_MAJOR_VERSION == 1 || PF_MAJOR_VERSION == 2 && PF_MINOR_VERSION < 2)
#define PFFLT_USERDATA_SLOT 	    	30
#endif

/* loader values */
#define PFFLT_FRAMERATE			1	/* Hertz */
#define PFFLT_ALIGN_ZOFFSET		2	/* database units */

/* use units */
#define FLT_METERS	0
#define FLT_KILOMETERS	1
#define FLT_FEET	2
#define FLT_INCHES	3
#define FLT_NAUT_MILES	4

/* cat algorithms */	/*MCB: for 2.1 only */
#define FLT_CAT_APP_CULL	1
#define FLT_CAT_APP_SLICE	2

/* cat scalers */
#define FLT_CAT_LOD_SCALE	1
#define FLT_CAT_CHAN_STRESS	2

/* FEATURE sort criteria */
#define FLT_FTR_ALL		-1
#define FLT_FTR_NONE    	 0
#define FLT_FTR_FACES    	 1
#define FLT_FTR_LPOINTS 	 2

    /*------------------------------------------------------------*/


/*AE see above in C++ linkage: */
/* pfNode*	pfdLoadFile_flt ( char const* file );*/
/* void	pfdConverterAttr_flt ( int attr, void* val );*/
/* void*	pfdGetConverterAttr_flt ( int attr );*/
/* void	pfdConverterMode_flt ( int mode, int val );  */
/* int	pfdGetConverterMode_flt ( int mode );        */


    /*------------------------------------------------------------*/
    /*----geostate stuff------------------------------------------*/

/*
 * NOTE: fltAttrE enumerates the supported OpenFlight attributes
 *	 related to pfGeoState construction and binding.  Some
 *	 catagories (materials) may not make sense when more
 *	 than one value from the catagory is set.
 */

typedef enum fltAttrE
{
    FLTA_NONE		= 0x00000000,
    
    FLTA_LIGHTPOINT	= 0x00000001,

    FLTA_TEXTURE	= 0x00000010,
    FLTA_TEXDETAIL	= 0x00000020,
    FLTA_TEXENV		= 0x00000040,
    FLTA_TEXGEN		= 0x00000080,

    FLTA_MATERIAL	= 0x00000100,
    FLTA_IRMATERIAL	= 0x00000200,
    FLTA_SMC	    	= 0x00000400,	/* MCB: deprecated */
    
    FLTA_FID		= 0x00001000,	/* MCB: deprecated */
    FLTA_FEATURE	= 0x00001000,	/* fltFeature objects */

/*
 * NOTE: render map zero gets FLTA_DEFAULTS attributes by default.
 * NOTE: render map one gets FLTA_IRDEFAULTS attributes by default.
 */

    FLTA_DEFAULTS	= FLTA_TEXTURE | FLTA_TEXDETAIL | FLTA_TEXENV |
			  FLTA_TEXGEN  | FLTA_MATERIAL  | FLTA_LIGHTPOINT |
			  FLTA_FEATURE,

    FLTA_IRDEFAULTS	= FLTA_TEXTURE | FLTA_TEXDETAIL  | FLTA_TEXENV |
			  FLTA_TEXGEN  | FLTA_IRMATERIAL | FLTA_LIGHTPOINT |
			  FLTA_FEATURE

} fltAttrE;

typedef struct fltAttrKey
{
    fltAttrE	attr;	/* OpenFlight polygon attribute */
    int		value;	/* OpenFlight polygon attribute index */
} fltAttrKey;

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct fltSharedObj
{
    pfObject*	object;	/* pfMaterial, pfTexture, pfTexTEnv, pfTexGen, and pfGeoState */
    fltAttrKey	key;	/* loader sets this once: depth first, left to right */
} fltSharedObj;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

/*
 * NOTE: fltNewSharedObj() allocates a shared object suitable for adding
 *	 to the shared palette's corresponding shared object list.
 *	 fltFreeSharedObj() deallocates a given shared object.
 *
 * NOTE: the shared object is not implicitly added (or removed) to (or from)
 *	 any shared palette shared object list.  This must be done explicitly
 *	 using the appropriate pfAdd() or pfRemove() function.
 */

fltSharedObj*	fltNewSharedObj ( pfObject* obj, fltAttrKey const* key, void* arena );
void		fltFreeSharedObj ( fltSharedObj* object );

    /*------------------------------------------------------------*/

/*
 * NOTE: fltRenderMap (render-map) encapsulates the knowledge
 *	 used in the creation of a "geostate table".
 *
 *	 rendition is a pfList* of pfList* of pfGeoState* such
 *	 that you can call:
 *
 *	    pfChanGStateTable( chan, pfGet( renditions, WHICH ) );
 *
 *       attributes is a pfList* of fltAttrE, one for each
 *	 rendition, such that you can call:
 *
 *	    pfGet( attributes, WHICH );
 *
 *	 to learn the geostate properties of WHICH rendition.
 *
 *	 where WHICH is the "geostate table" of interest.
 */

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct fltRenderMap
{
    pfList*	attributes;	/* of fltAttrE, one for each rendition */
    pfList*	renditions;	/* of pfList* of pfGeoState* */
} fltRenderMap;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

/*
 * NOTE: fltRenderMapAttr() sets the attributes for a given render-map.
 *	 fltGetRenderMapAttr() gets the attributes for a given render-map.
 */

void		fltRenderMapAttr ( fltRenderMap* rendMap, int which, fltAttrE attr );
fltAttrE	fltGetRenderMapAttr ( fltRenderMap* rendMap, int which );

    /*------------------------------------------------------------*/

/*
 * NOTE: fltObjectCBack is a user defined function expecting:
 *
 *	 pfObject*	obj:  the associated pfObject
 *	 fltAttrKey*	key:  the pfObject's attribute key (if any)
 *	 fltAttrE	attr: the render-map's attributes (or FLTA_NONE)
 *	 void*		data: extra OpenFlight data (if any)
 *
 *	 both key and data must be copied if needed.  They are temporary.
 */
 
typedef void ( *fltObjectCBack )( pfObject* obj, fltAttrKey* key,
				  fltAttrE attr, void* data );
/*
 * NOTE: fltSharedPalette::rendMap (render-map) is a
 *	 fltRenderMap* such that you can call:
 *
 *	   fltSharedPalette*	palette = fltGetCurSharedPalette();
 *	   fltRenderMap*	rendMap = palette->rendMap;
 *	   pfChanGStateTable( chan, pfGet( rendMap->renditions, WHICH ) );
 *
 *       where WHICH is the "geostate table" of interest.
 *
 * NOTE: Optionally a post constructor callback can be set.  It will be
 *	 called after each new pfObject is created (pfMaterial, pfTexture,
 *	 pfTexTEnv, and pfGeoState) to enable you modify the pfObject's
 *	 attribute bindings and do your own bookkeeping.  This should be
 *	 done wrt the palette render-map attributes though.
 */

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct fltSharedPalette
{
    fltRenderMap*	rendMap;	/* ... the geostate tables */
    pfList*		ftrList;	/* of fltFeature* */
    pfList*		lptList;	/* of fltSharedObj* of pfLPointState */
    pfList*		matList;	/* of fltSharedObj* of pfMaterial */
    pfList*		tevList;	/* of fltSharedObj* of pfTexture */
    pfList*		texList;	/* of fltSharedObj* of pfTexEnv */
    pfList*		tgnList;	/* of fltSharedObj* of pfTexGen */
    fltObjectCBack	ObjCtor;	/* constructor post-callback */

} fltSharedPalette;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

/*
 * NOTE: fltNewSharedPalette() allocates a new shared palette.
 *	 fltFreeSharedPalette() deallocates a given shared palette.
 *
 * NOTE: The loader allocates a palette for itself if one is not applied.
 * NOTE: Do not free a palette currently used by the loader!
 */

fltSharedPalette*	fltNewSharedPalette ( int numMaps,
					      fltObjectCBack ctor,
					      void* arena );

void	fltFreeSharedPalette ( fltSharedPalette* palette );

/*
 * NOTE: fltApplySharedPalette() sets the loader's current palette.
 *	 fltGetCurSharedPalette() gets the loader's current palette.
 *
 * NOTE: this stuff is not fully MP safe yet!
 * NOTE: once the APP gets a palette, use pfList(3) API to manipulate it.
 */

void			fltApplySharedPalette ( fltSharedPalette* palette );
fltSharedPalette*	fltGetCurSharedPalette ( void );

    /*------------------------------------------------------------*/
    /*----node callback stuff-------------------------------------*/

#define CB_HEADER		1
#define CB_GROUP		2
#define CB_LOD			3
#define CB_OBJECT		4
#define CB_PUSH			10
#define CB_POP			11
#define CB_DOF			13
#define CB_EYEPOINTS		65
#define CB_SOUND		91
#define CB_PATH			92
#define CB_TEXT			95
#define CB_SWITCH		96
#define CB_CLIPPLANE            98
#define FLTCLIPMAX              5   /*AE HACK! See clipPlane.cpp for this enum*/
#define CB_LIGHTSRC		102
#define CB_IMPOSSIBLE		-100000000

#define CB_CLEANNODE		1000
#define CB_CLONE		1001

typedef struct {
    int length;
    char *text;
} COMMENTcb;

typedef void ( *fltRegisterNodeT )
(
    pfNode*	node,
    int		mgOp,
    int*	cbs,
    COMMENTcb*	comment,
    void*	userData
);

typedef struct {
    int		formatrev;
    int		rev;
    char	date[ 32 ];
    int		flags;
    short	udiv;
    char	texwhite;
    char	units;
    short	vtxtype;
    int 	dbl_orig;
    double	swifmt[ 2 ];
    double	tertrans[ 2 ];
    int		swcornerlat;
    int		swcornerlong;
    int		necornerlat;
    int		necornerlong;
    int		originlat;
    int		originlong;
    int		projection;
    int		oswifmt[ 2 ];
    int		otertrans[ 2 ];
    int		upperlat;
    int		lowerlat;
    /*
     * These fields are new in OpenFlight R14.0 (formatrev == 14)
     */
    double	swcornerlat1;
    double	swcornerlong1;
    double	necornerlat1;
    double	necornerlong1;
    double	originlat1;
    double	originlong1;
    double	upperlat1;
    double	lowerlat1;
} HEADERcb;

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct {
    float minx, curx, maxx;
    float miny, cury, maxy;
    float minz, curz, maxz;

    float minazim, curazim, maxazim;	/* pitch */
    float minincl, curincl, maxincl;	/* roll */
    float mintwist, curtwist, maxtwist;	/* heading (yaw) */

    float minscalex, curscalex, maxscalex;
    float minscaley, curscaley, maxscaley;
    float minscalez, curscalez, maxscalez;

    pfMatrix putmat, putinvmat;

    pfVec3 origin;

    float incx, incy, incz;
    float incazim, incincl, inctwist;
    float incxscale, incyscale, inczscale;

    struct {
	unsigned xlimited: 1;		/* TRUE to limit range of motion */
	unsigned ylimited: 1;
	unsigned zlimited: 1;
	unsigned azimlimited: 1;	/* pitch */
	unsigned incllimited: 1;	/* roll */
	unsigned twistlimited: 1;	/* heading (yaw) */
	unsigned xscalelimited: 1;
	unsigned yscalelimited: 1;
	unsigned zscalelimited: 1;
	unsigned reserved: 2;
	unsigned spareflags: 21;
    } flags;

} DOFcb;

typedef struct {
    int		flags;
    short	prio; 
    short	significance;
    short	special1, special2;	/* real time special effects */
    pfSCS*	itsTransform;	/* parent of pfNode* in callback, if any */
} GROUPcb;

typedef struct {
    int		flags;
    int		indist, outdist;	
    short	special1, special2;	/* real time special effects */
    pfVec3	center;
    pfSCS*	itsTransform;	/* parent of pfNode* in callback, if any */
} LODcb;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

typedef struct {
    int		flags;
    short	prio; 
    unsigned short transparency;
    short	significance;
    short	special1, special2;	/* real time special effects */
} OBJcb;

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct {			/* ten for each view window */
    double	rotcenter[ 3 ];		/* center of rotation for window */
    float	yaw, pitch, roll;
    pfMatrix	rotmatrix;		/* cumulative rotation matrix */
    float	fov, scale;
    float	nearclip, farclip;
    pfMatrix	flymatrix;	/* matrix for rotating eye within data base */
    float	lookfrom[ 3 ];	/* current position of eye in db */
    float	flyyaw;		/* current yaw of eye in flythrough */
    float	flypitch;	/* current pitch of eye in flythrough */
    float	eyedir[ 3 ];	/* current direction of eye */
    int		nofly;		/* eye positioned by flythrough */
    int		active;		/* whether this structure has been used */
    double	conv;		/* unit conversion factor */
} EyeSave;

typedef struct { 
    EyeSave	eyesave[ 10 ];
} EYEcb;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

typedef struct {
    struct {
	unsigned doppler: 1;	
	unsigned absorption: 1;
	unsigned delay: 1;
	unsigned direction: 2;
	unsigned active: 1;
    } flags;
    float 	priority;
    int		index;
    float 	amplitude;
    float 	normal[ 3 ];
    float 	width;
    float 	pitchbend;
    float 	falloff;
    double	offset[ 3 ];
    char	file[ PF_MAXSTRING ];	/* null terminated */
} SOUNDcb;

#ifdef __cplusplus
extern "C++" {	/* give structs containing Performer classes C++ linkage */
#endif

typedef struct {
    int		wordCount;	/* 32 bit words per switch */
    int		numSwitches;
    int		curSwitch;
    pfSCS*	itsTransform;	/* parent of pfNode* in callback, if any */
    unsigned	switches[ 1 ];	/* really numSwitches * wordCount elements */
} SWITCHcb;

typedef enum { PFFLT_LS_INFINITE, PFFLT_LS_LOCAL, PFFLT_LS_SPOT } PffltLightType;

typedef struct {
    int		index;
    int		global;	/* has global or sub-graph affect */
    pfSCS*	itsTransform;	/* parent of pfNode* in callback, if any */
} LIGHTSRCcb;

typedef	struct 	{

	char	enabled[ FLTCLIPMAX ];
	#ifdef IRISGL
		float	planes[ FLTCLIPMAX ][ 4 ];
	#else /* OPENGL */
			double	planes[ FLTCLIPMAX ][ 4 ];
	#endif /* IRISGL */
} CLIPPLANEcb;

typedef	struct 	{

  int     justification;
  int     primcolor;
  int     seccolor;
  int     material;
  int     maxnumchars;
  double  llrect[3];
  double  ulrect[3];
  char    fontname[120];
  int     drawvertical;
  int     drawbold;
  int     drawitalic;
  int     drawunderline;
  int     linestyle;

} TEXTcb;

#ifdef __cplusplus
}	/* end of C++ linkage */
#endif

    /*------------------------------------------------------------*/
    /*----behavior control stuff----------------------------------*/

/*
 * NOTE: Each driver is evaluated once per frame by pfAppFrame, similar
 *       to pfSequence's. No interpolation or extrapolation is done.
 */

/* Driver Control Modes */
#define FLT_DCM_PAUSE	0
#define FLT_DCM_RESUME	1
#define FLT_DCM_START	2
#define FLT_DCM_STOP	3

typedef struct fltDriverControl	fltDriverControl;

void	fltDCtlDuration ( fltDriverControl*, float speed, int reps );
void	fltDCtlMode ( fltDriverControl*, int mode );
void	fltDCtlRate ( fltDriverControl*, float rate );

void	fltGetDCtlDuration ( fltDriverControl*, float* speed, int* reps );
int	fltGetDCtlMode ( fltDriverControl* );
float	fltGetDCtlRate ( fltDriverControl* );

char const*	fltGetDCtlName ( fltDriverControl* );

int	fltDCtlIsFile ( fltDriverControl* );
int	fltDCtlIsInternal ( fltDriverControl* );
int	fltDCtlIsVariable ( fltDriverControl* );

/*
 * After getting the control list, scan for variable drivers by name
 * and set their source function. It will be called each integration
 * step.
 */

typedef	float ( *fltDCtlVarSourceT ) ( void );

void	fltDCtlVarSource ( fltDriverControl*, fltDCtlVarSourceT srcFunc );

    /*------------------------------------------------------------*\
	this list owns its elements
    \*------------------------------------------------------------*/

#if PF_CPLUSPLUS_API

typedef class pfuAutoList   fltAutoList;    /*MCB: deprecated alias*/

#else

typedef struct _pfuAutoList fltAutoList;    /*MCB: deprecated alias*/

#endif

int fltGetNum ( fltAutoList* );     	    /*MCB: deprecated*/


/*
 * use PFFLT_REGISTER_DRIVERS to get the driver control list
 * this is the type of function to provide.
 */

#if PF_CPLUSPLUS_API

typedef
void ( *fltRegisterDriversT ) ( pfNode*, pfuAutoList*, void* userData );

fltDriverControl*   fltGetDriverControl ( pfuAutoList*, int which );

#else

typedef
void ( *fltRegisterDriversT ) ( pfNode*, struct _pfuAutoList*, void* userData );

fltDriverControl*   fltGetDriverControl ( struct _pfuAutoList*, int which );

#endif

    /*------------------------------------------------------------*/
    /*----extra geometry attributes-------------------------------*/

    /*------------------------------------------------------------*\
	features attached as pfGeoState::userData
    \*------------------------------------------------------------*/

typedef struct fltFeature fltFeature;

int	fltGetFtrFID( fltFeature const* );
int	fltGetFtrSMC( fltFeature const* );

pfType* fltGetFeatureClassType( void );

    /*------------------------------------------------------------*\
	light point animation attached as pfLPointState::userData
    \*------------------------------------------------------------*/

/* Light point Animation Modes */
#define FLT_LAM_NONE	    0
#define FLT_LAM_FLASH	    1
#define FLT_LAM_ROTATE	    2
#define FLT_LAM_ROTATE_CCW  3

typedef struct fltLPointAnim fltLPointAnim;

PFFLT_DLLEXPORT void	fltGetLPAnimAxis   ( fltLPointAnim const*, float vec[ 3 ] );
PFFLT_DLLEXPORT float	fltGetLPAnimDelay  ( fltLPointAnim const* );
PFFLT_DLLEXPORT int	fltGetLPAnimMode   ( fltLPointAnim const* );
PFFLT_DLLEXPORT float	fltGetLPAnimPeriod ( fltLPointAnim const* );
PFFLT_DLLEXPORT float	fltGetLPAnimTimeOn ( fltLPointAnim const* );

PFFLT_DLLEXPORT pfType* fltGetLPAnimClassType( void );


#ifdef __cplusplus
}	/* end of C linkage */
#endif

#endif /* pfflt_h */
