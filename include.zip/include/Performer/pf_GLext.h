
/* 
** This file is based upon freely available glext.h, located at:
** 
** http://oss.sgi.com/projects/ogl-sample/ARB/glext.h
*/

/*
** License Applicability. Except to the extent portions of this file are
** made subject to an alternative license as permitted in the SGI Free
** Software License B, Version 1.1 (the "License"), the contents of this
** file are subject only to the provisions of the License. You may not use
** this file except in compliance with the License. You may obtain a copy
** of the License at Silicon Graphics, Inc., attn: Legal Services, 1600
** Amphitheatre Parkway, Mountain View, CA 94043-1351, or at:
** 
** http://oss.sgi.com/projects/FreeB
** 
** Note that, as provided in the License, the Software is distributed on an
** "AS IS" basis, with ALL EXPRESS AND IMPLIED WARRANTIES AND CONDITIONS
** DISCLAIMED, INCLUDING, WITHOUT LIMITATION, ANY IMPLIED WARRANTIES AND
** CONDITIONS OF MERCHANTABILITY, SATISFACTORY QUALITY, FITNESS FOR A
** PARTICULAR PURPOSE, AND NON-INFRINGEMENT.
** 
** Original Code. The Original Code is: OpenGL Sample Implementation,
** Version 1.2.1, released January 26, 2000, developed by Silicon Graphics,
** Inc. The Original Code is Copyright (c) 1991-2004 Silicon Graphics, Inc.
** Copyright in any portions created by third parties is as indicated
** elsewhere herein. All Rights Reserved.
** 
** Additional Notice Provisions: This software was created using the
** OpenGL(R) version 1.2.1 Sample Implementation published by SGI, but has
** not been independently verified as being compliant with the OpenGL(R)
** version 1.2.1 Specification.
*/

#ifndef __PF_GLEXT_H__
#define __PF_GLEXT_H__

#ifdef __cplusplus
extern "C" {
#endif

#ifdef WIN32
#include <windows.h>
#elif !defined(APIENTRY)
#define APIENTRY
#endif

#include <GL/gl.h>

/* Since we use slightly different typedefs for our extension 
   and version function pointer types, they are outside of the 
   ifndefs, because they must always be defined
 */

#ifndef GL_ARB_vertex_program
#define GL_ARB_vertex_program 1

#define GL_COLOR_SUM_ARB                          0x8458
#define GL_VERTEX_PROGRAM_ARB                     0x8620
#define GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB        0x8622
#define GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB           0x8623
#define GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB         0x8624
#define GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB           0x8625
#define GL_CURRENT_VERTEX_ATTRIB_ARB              0x8626
#define GL_PROGRAM_LENGTH_ARB                     0x8627
#define GL_PROGRAM_STRING_ARB                     0x8628
#define GL_MAX_PROGRAM_MATRIX_STACK_DEPTH_ARB     0x862E
#define GL_MAX_PROGRAM_MATRICES_ARB               0x862F
#define GL_CURRENT_MATRIX_STACK_DEPTH_ARB         0x8640
#define GL_CURRENT_MATRIX_ARB                     0x8641
#define GL_VERTEX_PROGRAM_POINT_SIZE_ARB          0x8642
#define GL_VERTEX_PROGRAM_TWO_SIDE_ARB            0x8643
#define GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB        0x8645
#define GL_PROGRAM_ERROR_POSITION_ARB             0x864B
#define GL_PROGRAM_BINDING_ARB                    0x8677
#define GL_MAX_VERTEX_ATTRIBS_ARB                 0x8869
#define GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB     0x886A
#define GL_PROGRAM_ERROR_STRING_ARB               0x8874
#define GL_PROGRAM_FORMAT_ASCII_ARB               0x8875
#define GL_PROGRAM_FORMAT_ARB                     0x8876
#define GL_PROGRAM_INSTRUCTIONS_ARB               0x88A0
#define GL_MAX_PROGRAM_INSTRUCTIONS_ARB           0x88A1
#define GL_PROGRAM_NATIVE_INSTRUCTIONS_ARB        0x88A2
#define GL_MAX_PROGRAM_NATIVE_INSTRUCTIONS_ARB    0x88A3
#define GL_PROGRAM_TEMPORARIES_ARB                0x88A4
#define GL_MAX_PROGRAM_TEMPORARIES_ARB            0x88A5
#define GL_PROGRAM_NATIVE_TEMPORARIES_ARB         0x88A6
#define GL_MAX_PROGRAM_NATIVE_TEMPORARIES_ARB     0x88A7
#define GL_PROGRAM_PARAMETERS_ARB                 0x88A8
#define GL_MAX_PROGRAM_PARAMETERS_ARB             0x88A9
#define GL_PROGRAM_NATIVE_PARAMETERS_ARB          0x88AA
#define GL_MAX_PROGRAM_NATIVE_PARAMETERS_ARB      0x88AB
#define GL_PROGRAM_ATTRIBS_ARB                    0x88AC
#define GL_MAX_PROGRAM_ATTRIBS_ARB                0x88AD
#define GL_PROGRAM_NATIVE_ATTRIBS_ARB             0x88AE
#define GL_MAX_PROGRAM_NATIVE_ATTRIBS_ARB         0x88AF
#define GL_PROGRAM_ADDRESS_REGISTERS_ARB          0x88B0
#define GL_MAX_PROGRAM_ADDRESS_REGISTERS_ARB      0x88B1
#define GL_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB   0x88B2
#define GL_MAX_PROGRAM_NATIVE_ADDRESS_REGISTERS_ARB 0x88B3
#define GL_MAX_PROGRAM_LOCAL_PARAMETERS_ARB       0x88B4
#define GL_MAX_PROGRAM_ENV_PARAMETERS_ARB         0x88B5
#define GL_PROGRAM_UNDER_NATIVE_LIMITS_ARB        0x88B6
#define GL_TRANSPOSE_CURRENT_MATRIX_ARB           0x88B7
#define GL_MATRIX0_ARB                            0x88C0
#define GL_MATRIX1_ARB                            0x88C1
#define GL_MATRIX2_ARB                            0x88C2
#define GL_MATRIX3_ARB                            0x88C3
#define GL_MATRIX4_ARB                            0x88C4
#define GL_MATRIX5_ARB                            0x88C5
#define GL_MATRIX6_ARB                            0x88C6
#define GL_MATRIX7_ARB                            0x88C7
#define GL_MATRIX8_ARB                            0x88C8
#define GL_MATRIX9_ARB                            0x88C9
#define GL_MATRIX10_ARB                           0x88CA
#define GL_MATRIX11_ARB                           0x88CB
#define GL_MATRIX12_ARB                           0x88CC
#define GL_MATRIX13_ARB                           0x88CD
#define GL_MATRIX14_ARB                           0x88CE
#define GL_MATRIX15_ARB                           0x88CF
#define GL_MATRIX16_ARB                           0x88D0
#define GL_MATRIX17_ARB                           0x88D1
#define GL_MATRIX18_ARB                           0x88D2
#define GL_MATRIX19_ARB                           0x88D3
#define GL_MATRIX20_ARB                           0x88D4
#define GL_MATRIX21_ARB                           0x88D5
#define GL_MATRIX22_ARB                           0x88D6
#define GL_MATRIX23_ARB                           0x88D7
#define GL_MATRIX24_ARB                           0x88D8
#define GL_MATRIX25_ARB                           0x88D9
#define GL_MATRIX26_ARB                           0x88DA
#define GL_MATRIX27_ARB                           0x88DB
#define GL_MATRIX28_ARB                           0x88DC
#define GL_MATRIX29_ARB                           0x88DD
#define GL_MATRIX30_ARB                           0x88DE
#define GL_MATRIX31_ARB                           0x88DF

#endif /* ARB_vertex_program */

typedef void (APIENTRY * PFNGL_VERTEXATTRIBPOINTERARBPROC)(unsigned int index, int size, GLenum type, GLboolean norm, GLsizei stride, const void *ptr);
typedef void (APIENTRY * PFNGL_ENABLEVERTEXATTRIBARRAYARBPROC)(unsigned int index);
typedef void (APIENTRY * PFNGL_DISABLEVERTEXATTRIBARRAYARBPROC)(unsigned int index);
typedef void (APIENTRY * PFNGL_PROGRAMSTRINGARBPROC)(GLenum targ, GLenum format, GLsizei len, const void *str);
typedef void (APIENTRY * PFNGL_BINDPROGRAMARBPROC)(GLenum targ, GLuint prog);
typedef void (APIENTRY * PFNGL_DELETEPROGRAMSARBPROC)(GLsizei n, const GLuint *progs);
typedef void (APIENTRY * PFNGL_GENPROGRAMSARBPROC)(GLsizei n, GLuint *progs);
typedef void (APIENTRY * PFNGL_PROGRAMENVPARAMETER4DVARBPROC)(GLenum target, GLuint index, const double *params);
typedef void (APIENTRY * PFNGL_PROGRAMENVPARAMETER4FVARBPROC)(GLenum target, GLuint index, const float *params);
typedef void (APIENTRY * PFNGL_PROGRAMLOCALPARAMETER4DVARBPROC)(GLenum target, GLuint index, const double *params);
typedef void (APIENTRY * PFNGL_PROGRAMLOCALPARAMETER4FVARBPROC)(GLenum target, GLuint index, const float *params);
typedef void (APIENTRY * PFNGL_PROGRAMLOCALPARAMETER4FARBPROC)(GLenum target, GLuint index, GLfloat x, GLfloat y, GLfloat z, GLfloat w);
typedef void (APIENTRY * PFNGL_GETPROGRAMIVARBPROC)(GLenum targ, GLenum pname, GLint *parms);
typedef void (APIENTRY * PFNGL_GETPROGRAMSTRINGARBPROC)(GLenum targ, GLenum pname, void *string);
typedef GLboolean (APIENTRY * PFNGL_ISPROGRAMARBPROC)(GLuint prog);

#ifndef GL_ARB_fragment_program
#define GL_ARB_fragment_program 1

#define GL_FRAGMENT_PROGRAM_ARB                   0x8804
#define GL_PROGRAM_ALU_INSTRUCTIONS_ARB           0x8805
#define GL_PROGRAM_TEX_INSTRUCTIONS_ARB           0x8806
#define GL_PROGRAM_TEX_INDIRECTIONS_ARB           0x8807
#define GL_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB    0x8808
#define GL_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB    0x8809
#define GL_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB    0x880A
#define GL_MAX_PROGRAM_ALU_INSTRUCTIONS_ARB       0x880B
#define GL_MAX_PROGRAM_TEX_INSTRUCTIONS_ARB       0x880C
#define GL_MAX_PROGRAM_TEX_INDIRECTIONS_ARB       0x880D
#define GL_MAX_PROGRAM_NATIVE_ALU_INSTRUCTIONS_ARB 0x880E
#define GL_MAX_PROGRAM_NATIVE_TEX_INSTRUCTIONS_ARB 0x880F
#define GL_MAX_PROGRAM_NATIVE_TEX_INDIRECTIONS_ARB 0x8810
#define GL_MAX_TEXTURE_COORDS_ARB                 0x8871
#define GL_MAX_TEXTURE_IMAGE_UNITS_ARB            0x8872

#endif /* ARB_fragment_program */

#ifndef GL_ATI_vertex_array_object
#define GL_ATI_vertex_array_object 1

#define GL_STATIC_ATI                             0x8760
#define GL_DYNAMIC_ATI                            0x8761
#define GL_PRESERVE_ATI                           0x8762
#define GL_DISCARD_ATI                            0x8763
#define GL_OBJECT_BUFFER_SIZE_ATI                 0x8764
#define GL_OBJECT_BUFFER_USAGE_ATI                0x8765
#define GL_ARRAY_OBJECT_BUFFER_ATI                0x8766
#define GL_ARRAY_OBJECT_OFFSET_ATI                0x8767

#endif /* ATI_vertex_array_object */

typedef GLuint (APIENTRY * PFNGL_NEWOBJECTBUFFERATIPROC)(GLsizei size, const void *pointer, GLenum usage);
typedef GLboolean (APIENTRY * PFNGL_ISOBJECTBUFFERATIPROC)(GLuint buffer);
typedef void (APIENTRY * PFNGL_UPDATEOBJECTBUFFERATIPROC)(GLuint buffer, GLuint offset, GLsizei size, const void *pointer, GLenum preserve);
typedef void (APIENTRY * PFNGL_GETOBJECTBUFFERFVATIPROC)(GLuint buffer, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETOBJECTBUFFERIVATIPROC)(GLuint buffer, GLenum pname, GLint *params);
typedef void (APIENTRY * PFNGL_FREEOBJECTBUFFERATIPROC)(GLuint buffer);
typedef void (APIENTRY * PFNGL_ARRAYOBJECTATIPROC)(GLenum array, GLint size, GLenum type, GLsizei stride, GLuint buffer, GLuint offset);
typedef void (APIENTRY * PFNGL_GETARRAYOBJECTFVATIPROC)(GLenum array, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETARRAYOBJECTIVATIPROC)(GLenum array, GLenum pname, GLint *params);
typedef void (APIENTRY * PFNGL_VARIANTARRAYOBJECTATIPROC)(GLuint id, GLenum type, GLsizei stride, GLuint buffer, GLuint offset);
typedef void (APIENTRY * PFNGL_GETVARIANTARRAYOBJECTFVATIPROC)(GLuint id, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETVARIANTARRAYOBJECTIVATIPROC)(GLuint id, GLenum pname, GLint *params);

#ifndef GL_ATI_element_array
#define GL_ATI_element_array 1

#define GL_ELEMENT_ARRAY_ATI                      0x8768
#define GL_ELEMENT_ARRAY_TYPE_ATI                 0x8769
#define GL_ELEMENT_ARRAY_POINTER_ATI              0x876A

#endif /* ATI_element_array */

typedef void (APIENTRY * PFNGL_ELEMENTPOINTERATIPROC)(GLenum type, const void *pointer);
typedef void (APIENTRY * PFNGL_DRAWELEMENTARRAYATIPROC)(GLenum mode, GLsizei count);
typedef void (APIENTRY * PFNGL_DRAWRANGEELEMENTARRAYATIPROC)(GLenum mode, GLuint start, GLuint end, GLsizei count);

#ifndef GL_ATI_vertex_attrib_array_object 
#define GL_ATI_vertex_attrib_array_object 1

#endif /* ATI_vertex_attrib_array_object */

typedef void (APIENTRY * PFNGL_VERTEXATTRIBARRAYOBJECTATIPROC) (GLuint index, GLint size, GLenum type, GLboolean normalized, GLsizei stride, GLuint buffer, GLuint offset);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBARRAYOBJECTFVATIPROC) (GLuint index, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBARRAYOBJECTIVATIPROC) (GLuint index, GLenum pname, GLint *params);

#ifndef GL_EXT_blend_color
#define GL_EXT_blend_color 1

#define GL_CONSTANT_COLOR_EXT                     0x8001
#define GL_ONE_MINUS_CONSTANT_COLOR_EXT           0x8002
#define GL_CONSTANT_ALPHA_EXT                     0x8003
#define GL_ONE_MINUS_CONSTANT_ALPHA_EXT           0x8004
#define GL_BLEND_COLOR_EXT                        0x8005

#endif /* EXT_blend_color */

typedef void (APIENTRY * PFNGL_BLENDCOLOREXTPROC)(GLclampf red, GLclampf green, GLclampf blue, GLclampf alpha);

   
#if !defined(GL_EXT_blend_minmax) && !defined(GL_EXT_blend_subtract) && !defined(GL_EXT_blend_logic_op)
#define GL_BLEND_EQUATION_EXT                     0x8009
#define GL_FUNC_ADD_EXT                           0x8006
#endif


#ifndef GL_EXT_blend_minmax
#define GL_EXT_blend_minmax 1

#define GL_MIN_EXT                                0x8007
#define GL_MAX_EXT                                0x8008

#endif /* EXT_blend_minmax */


#ifndef GL_EXT_blend_subtract
#define GL_EXT_blend_subtract 1

#define GL_FUNC_SUBTRACT_EXT                      0x800A
#define GL_FUNC_REVERSE_SUBTRACT_EXT              0x800B

#endif /* EXT_blend_subtract */


#ifndef GL_EXT_blend_logic_op
#define GL_EXT_blend_logic_op 1
#endif /* EXT_blend_logic_op */

typedef void (APIENTRY * PFNGL_BLENDEQUATIONEXTPROC)(GLenum mode);

#ifndef GL_ARB_texture_compression
#define GL_ARB_texture_compression 1

#define GL_COMPRESSED_ALPHA_ARB                   0x84E9
#define GL_COMPRESSED_LUMINANCE_ARB               0x84EA
#define GL_COMPRESSED_LUMINANCE_ALPHA_ARB         0x84EB
#define GL_COMPRESSED_INTENSITY_ARB               0x84EC
#define GL_COMPRESSED_RGB_ARB                     0x84ED
#define GL_COMPRESSED_RGBA_ARB                    0x84EE
#define GL_TEXTURE_COMPRESSION_HINT_ARB           0x84EF
#define GL_TEXTURE_COMPRESSED_IMAGE_SIZE_ARB      0x86A0
#define GL_TEXTURE_COMPRESSED_ARB                 0x86A1
#define GL_NUM_COMPRESSED_TEXTURE_FORMATS_ARB     0x86A2
#define GL_COMPRESSED_TEXTURE_FORMATS_ARB         0x86A3

#endif /* GL_ARB_texture_compression */

typedef void (APIENTRY * PFNGL_COMPRESSEDTEXIMAGE3DARBPROC) (GLenum target, GLint level, GLenum internalFormat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_COMPRESSEDTEXIMAGE2DARBPROC) (GLenum target, GLint level, GLenum internalFormat, GLsizei width, GLsizei height, GLint border, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_COMPRESSEDTEXIMAGE1DARBPROC) (GLenum target, GLint level, GLenum internalFormat, GLsizei width, GLint border, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_COMPRESSEDTEXSUBIMAGE3DARBPROC) (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_COMPRESSEDTEXSUBIMAGE2DARBPROC) (GLenum target, GLint level, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_COMPRESSEDTEXSUBIMAGE1DARBPROC) (GLenum target, GLint level, GLint xoffset, GLsizei width, GLenum format, GLsizei imageSize, const void *data);
typedef void (APIENTRY * PFNGL_GETCOMPRESSEDTEXIMAGEARBPROC) (GLenum target, GLint lod, void *img);

#ifndef GL_EXT_texture_compression_s3tc
#define GL_EXT_texture_compression_s3tc 1

#define GL_COMPRESSED_RGB_S3TC_DXT1_EXT           0x83F0
#define GL_COMPRESSED_RGBA_S3TC_DXT1_EXT          0x83F1
#define GL_COMPRESSED_RGBA_S3TC_DXT3_EXT          0x83F2
#define GL_COMPRESSED_RGBA_S3TC_DXT5_EXT          0x83F3

#endif /* GL_EXT_texture_compression_s3tc */

#ifndef GL_ARB_vertex_buffer_object
#define GL_ARB_vertex_buffer_object 1

#ifndef WIN32
#if defined(N64) || defined(__ia64__)
typedef int64_t INT_PTR;
#else
typedef long INT_PTR;
#endif
#endif

typedef INT_PTR GLintptrARB;
typedef INT_PTR GLsizeiptrARB;

#define GL_ARRAY_BUFFER_ARB                       0x8892
#define GL_ELEMENT_ARRAY_BUFFER_ARB               0x8893

#define GL_ARRAY_BUFFER_BINDING_ARB               0x8894
#define GL_ELEMENT_ARRAY_BUFFER_BINDING_ARB       0x8895
#define GL_VERTEX_ARRAY_BUFFER_BINDING_ARB        0x8896
#define GL_NORMAL_ARRAY_BUFFER_BINDING_ARB        0x8897
#define GL_COLOR_ARRAY_BUFFER_BINDING_ARB         0x8898
#define GL_INDEX_ARRAY_BUFFER_BINDING_ARB         0x8899
#define GL_TEXTURE_COORD_ARRAY_BUFFER_BINDING_ARB 0x889A
#define GL_EDGE_FLAG_ARRAY_BUFFER_BINDING_ARB     0x889B
#define GL_SECONDARY_COLOR_ARRAY_BUFFER_BINDING_ARB 0x889C
#define GL_FOG_COORDINATE_ARRAY_BUFFER_BINDING_ARB 0x889D
#define GL_WEIGHT_ARRAY_BUFFER_BINDING_ARB        0x889E

#define GL_VERTEX_ATTRIB_ARRAY_BUFFER_BINDING_ARB 0x889F

#define GL_STREAM_DRAW_ARB                        0x88E0
#define GL_STREAM_READ_ARB                        0x88E1
#define GL_STREAM_COPY_ARB                        0x88E2
#define GL_STATIC_DRAW_ARB                        0x88E4
#define GL_STATIC_READ_ARB                        0x88E5
#define GL_STATIC_COPY_ARB                        0x88E6
#define GL_DYNAMIC_DRAW_ARB                       0x88E8
#define GL_DYNAMIC_READ_ARB                       0x88E9
#define GL_DYNAMIC_COPY_ARB                       0x88EA

#define GL_READ_ONLY_ARB                          0x88B8
#define GL_WRITE_ONLY_ARB                         0x88B9
#define GL_READ_WRITE_ARB                         0x88BA

#define GL_BUFFER_SIZE_ARB                        0x8764
#define GL_BUFFER_USAGE_ARB                       0x8765
#define GL_BUFFER_ACCESS_ARB                      0x88BB
#define GL_BUFFER_MAPPED_ARB                      0x88BC

#define GL_BUFFER_MAP_POINTER_ARB                 0x88BD

#endif /* ARB_vertex_buffer_object */

typedef void (APIENTRY * PFNGL_BINDBUFFERARBPROC)(GLenum target, GLuint buffer);
typedef void (APIENTRY * PFNGL_DELETEBUFFERSARBPROC)(GLsizei n, const GLuint *buffers);
typedef void (APIENTRY * PFNGL_GENBUFFERSARBPROC)(GLsizei n, GLuint *buffers);
typedef GLboolean (APIENTRY * PFNGL_ISBUFFERARBPROC)(GLuint buffer);
typedef void (APIENTRY * PFNGL_BUFFERDATAARBPROC)(GLenum target, GLsizeiptrARB size, const void *data, GLenum usage);
typedef void (APIENTRY * PFNGL_BUFFERSUBDATAARBPROC)(GLenum target, GLintptrARB offset, GLsizeiptrARB size, const void *data);
typedef void (APIENTRY * PFNGL_GETBUFFERSUBDATAARBPROC)(GLenum target, GLintptrARB offset, GLsizeiptrARB size, void *data);
typedef void * (APIENTRY * PFNGL_MAPBUFFERARBPROC)(GLenum target, GLenum access);
typedef GLboolean (APIENTRY * PFNGL_UNMAPBUFFERARBPROC)(GLenum target);
typedef void (APIENTRY * PFNGL_GETBUFFERPARAMETERIVARBPROC)(GLenum target, GLenum pname, GLint *params);
typedef void (APIENTRY * PFNGL_GETBUFFERPOINTERVARBPROC)(GLenum target, GLenum pname, void **params);

/* IMPROVE - do we want these token definitions here? */
#ifndef GL_ATI_uber_buffers
#define GL_ATI_uber_buffers 1

typedef GLuint GLmem;
typedef char GLcharARB;

/* TEMPORARY VALUES */
#define GL_COLOR_BUFFER_ATI                       0x00010000  
#define GL_DEPTH_BUFFER_ATI                       0x00020000
#define GL_STENCIL_BUFFER_ATI                     0x00030000
#define GL_GENERIC_ARRAY_ATI                      0x00040000
#define GL_ACCUMULATION_BUFFER_ATI                0x00050000
#define GL_MIPMAP_ATI                             0x00060000
#define GL_BORDER_ATI                             0x00070000
#define GL_USAGE_ATI                              0x00080000
#define GL_PROXY_ATI                              0x001f0000 
#define GL_MATCH_SIZE_ATI                         0x00090000
#define GL_MATCH_COMPONENT_SET_ATI                0x000a0000
#define GL_MATCH_COMPONENT_SIZE_ATI               0x000b0000
#define GL_MATCH_SAMPLES_ATI                      0x000c0000
#define GL_ATTACH_COMPATIBILITY_ATI               0x000d0000
#define GL_VALIDATE_ONLY_ATI                      0x000e0000
#define GL_MEMORY_DIMENSIONS_ATI                  0x000f0000
#define GL_MEMORY_WIDTH_ATI                       0x00100000
#define GL_MEMORY_HEIGHT_ATI                      0x00110000
#define GL_MEMORY_DEPTH_ATI                       0x00120000
#define GL_MEMORY_LEVELS_ATI                      0x00130000
#define GL_MEMORY_FORMAT_ATI                      0x00140000
#define GL_SUB_MEM_ATI                            0x00150000
#define GL_WS_ALLOCATED_ATI                       0x00160000
#define GL_EXACT_ATI                              0x00170000
#define GL_MIN_ATI                                0x00180000
#define GL_MAX_ATI                                0x00190000
#define GL_MIN_ELEMENTS_ATI                       0x001a0000
#define GL_MEMORY_3D_ATI                          0x001b0000
#define GL_FRAMEBUFFER_ATI                        0x001c0000
#define GL_STENCIL_COMPONENT_ATI                  0x001d0000
#define GL_STENCIL_COMPONENT8_ATI                 0x001e0000

#endif /* ATI_uber_buffers */

typedef GLmem (APIENTRY *PFNGL_ALLOCMEM3DATIPROC)(GLenum format, GLsizei width, GLsizei height, GLsizei depth, GLsizei np, const GLint *properties);
typedef GLmem (APIENTRY *PFNGL_ALLOCMEM2DATIPROC)(GLenum format, GLsizei width, GLsizei height, GLsizei np, const GLint *properties);
typedef GLmem (APIENTRY *PFNGL_ALLOCMEM1DATIPROC)(GLenum format, GLsizei width, GLsizei np, const GLint *properties);
typedef const GLcharARB * (APIENTRY *PFNGL_GETMEMINFOLOGATIPROC)(GLmem mem);
typedef GLmem (APIENTRY *PFNGL_CLONEMEMATIPROC)(GLmem mem);
typedef void (APIENTRY *PFNGL_DELETEMEMATIPROC)(GLmem mem);
typedef GLboolean (APIENTRY *PFNGL_ISMEMMARKEDFORDELETIONATIPROC)(GLmem mem);
typedef GLint (APIENTRY *PFNGL_GETMEMPROPERTYATIPROC)(GLmem mem, GLenum property);
typedef GLmem (APIENTRY *PFNGL_GETSUBMEMATIPROC)(GLmem mem, GLenum type, GLuint child);
typedef GLmem (APIENTRY *PFNGL_GETBASEMEMATIPROC)(GLmem mem);
typedef GLmem (APIENTRY *PFNGL_GETMEMATIPROC)(GLenum target);
typedef GLboolean (APIENTRY *PFNGL_ISMEMATIPROC)(GLmem mem);
typedef void (APIENTRY *PFNGL_MEMIMAGEATIPROC)(GLmem mem, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_COPYMEMIMAGE2DATIPROC)(GLmem mem, GLint x, GLint y);
typedef void (APIENTRY *PFNGL_COPYMEMIMAGE1DATIPROC)(GLmem mem, GLint x, GLint y);
typedef void (APIENTRY *PFNGL_MEMSUBIMAGE3DATIPROC)(GLmem mem, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_MEMSUBIMAGE2DATIPROC)(GLmem mem, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_MEMSUBIMAGE1DATIPROC)(GLmem mem, GLint xoffset, GLsizei width, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_COPYMEMSUBIMAGE2DATIPROC)(GLmem mem, GLint xoffset, GLint yoffset, GLint x, GLint y, GLsizei width, GLsizei height);
typedef void (APIENTRY *PFNGL_COPYMEMSUBIMAGE1DATIPROC)(GLmem mem, GLint xoffset, GLint x, GLint y, GLsizei width);
typedef void (APIENTRY *PFNGL_MEMCOPY3DATIPROC)(GLmem src, GLint xsrc, GLint ysrc, GLint zsrc, GLmem dst, GLint xdst, GLint ydst, GLint zdst, GLsizei width, GLsizei height, GLsizei depth);
typedef void (APIENTRY *PFNGL_MEMCOPY2DATIPROC)(GLmem src, GLint xsrc, GLint ysrc, GLmem dst, GLint xdst, GLint ydst, GLsizei width, GLsizei height);
typedef void (APIENTRY *PFNGL_MEMCOPY1DATIPROC)(GLmem src, GLint xsrc, GLmem dst, GLint xdst, GLsizei width);
typedef void (APIENTRY *PFNGL_GETMEMIMAGEATIPROC)(GLmem mem, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_GETMEMSUBIMAGE3DATIPROC)(GLmem mem, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_GETMEMSUBIMAGE2DATIPROC)(GLmem mem, GLint xoffset, GLint yoffset, GLsizei width, GLsizei height, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_GETMEMSUBIMAGE1DATIPROC)(GLmem mem, GLint xoffset, GLsizei width, GLenum format, GLenum type, void *data);
typedef void (APIENTRY *PFNGL_INVALIDATEMEMATIPROC)(GLmem mem);
typedef void (APIENTRY *PFNGL_ATTACHMEMATIPROC)(GLenum target, GLmem mem);
typedef GLboolean (APIENTRY *PFNGL_DETACHMEMATIPROC)(GLmem mem);
typedef GLuint (APIENTRY *PFNGL_NEWFRAMEBUFFERATIPROC)(void);
typedef void (APIENTRY *PFNGL_DELETEFRAMEBUFFERATIPROC)(GLuint framebuffer);
typedef void (APIENTRY *PFNGL_BINDFRAMEBUFFERATIPROC)(GLenum target, GLuint framebuffer);
typedef GLuint (APIENTRY *PFNGL_GETFRAMEBUFFERATIPROC)(GLenum target);
typedef GLboolean (APIENTRY *PFNGL_ISFRAMEBUFFERATIPROC)(GLuint framebuffer);
typedef GLboolean (APIENTRY *PFNGL_SWAPBUFFERSATIPROC)(GLenum preserve);
typedef void (APIENTRY *PFNGL_VERTEXARRAYMEMATIPROC)(GLenum array, GLint size, GLmem mem, GLuint offset);
typedef void (APIENTRY *PFNGL_VERTEXATTRIBMEMATIPROC)(GLuint index, GLint size, GLboolean normalized, GLmem mem, GLuint offset);
typedef void (APIENTRY *PFNGL_DRAWMEMELEMENTSATIPROC)(GLenum mode, GLsizei count, GLmem mem, GLuint offset);
typedef void (APIENTRY *PFNGL_MULTIDRAWMEMELEMENTSATIPROC)(GLenum mode, GLsizei *count, GLmem *mems, GLuint *offsets, GLsizei primcount);

typedef void (APIENTRY * PFNGL_DRAWBUFFERSATIPROC)(GLsizei n, const GLenum *bufs);

#ifndef GL_ARB_shader_objects
#define GL_ARB_shader_objects 1

typedef unsigned int GLhandleARB;

#define GL_PROGRAM_OBJECT_ARB	                  0x8B40
#define GL_OBJECT_TYPE_ARB                        0x8B4E
#define GL_OBJECT_SUBTYPE_ARB                     0x8B4F

#define GL_SHADER_OBJECT_ARB		          0x8B48
#define GL_FLOAT_VEC2_ARB                         0x8B50
#define GL_FLOAT_VEC3_ARB                         0x8B51   
#define GL_FLOAT_VEC4_ARB                         0x8B52   
#define GL_INT_VEC2_ARB                           0x8B53   
#define GL_INT_VEC3_ARB                           0x8B54   
#define GL_INT_VEC4_ARB                           0x8B55   
#define GL_BOOL_ARB                               0x8B56   
#define GL_BOOL_VEC2_ARB                          0x8B57   
#define GL_BOOL_VEC3_ARB                          0x8B58   
#define GL_BOOL_VEC4_ARB                          0x8B59   
#define GL_FLOAT_MAT2_ARB                         0x8B5A   
#define GL_FLOAT_MAT3_ARB                         0x8B5B   
#define GL_FLOAT_MAT4_ARB                         0x8B5C 

#define GL_VERTEX_SHADER_ARB		          0x8B31  
#define GL_MAX_VERTEX_UNIFORM_COMPONENTS_ARB      0x8B4A
#define GL_MAX_VERTEX_ATTRIBS_ARB                 0x8869
#define GL_MAX_TEXTURE_IMAGE_UNITS_ARB            0x8872
#define GL_MAX_VERTEX_TEXTURE_IMAGE_UNITS_ARB     0x8B4C 
#define GL_MAX_COMBINED_TEXTURE_IMAGE_UNITS_ARB   0x8B4D
#define GL_MAX_TEXTURE_COORDS_ARB                 0x8871

#define GL_VERTEX_ATTRIB_ARRAY_ENABLED_ARB        0x8622
#define GL_VERTEX_ATTRIB_ARRAY_SIZE_ARB           0x8623
#define GL_VERTEX_ATTRIB_ARRAY_STRIDE_ARB         0x8624
#define GL_VERTEX_ATTRIB_ARRAY_TYPE_ARB           0x8625
#define GL_VERTEX_ATTRIB_ARRAY_NORMALIZED_ARB     0x886A
#define GL_CURRENT_VERTEX_ATTRIB_ARB              0x8626
#define GL_VERTEX_ATTRIB_ARRAY_POINTER_ARB        0x8645

#define GL_FRAGMENT_SHADER_ARB                    0x8B30
#define GL_MAX_FRAGMENT_UNIFORM_COMPONENTS_ARB    0x8B49

#define GL_MAX_VARYING_FLOATS_ARB                 0x8B4B

#define GL_VERTEX_PROGRAM_POINT_SIZE_ARB          0x8642
#define GL_VERTEX_PROGRAM_TWO_SIDE_ARB            0x8643

#define GL_OBJECT_DELETE_STATUS_ARB               0x8B80
#define GL_OBJECT_COMPILE_STATUS_ARB              0x8B81
#define GL_OBJECT_LINK_STATUS_ARB                 0x8B82
#define GL_OBJECT_VALIDATE_STATUS_ARB             0x8B83
#define GL_OBJECT_INFO_LOG_LENGTH_ARB             0x8B84
#define GL_OBJECT_ATTACHED_OBJECTS_ARB            0x8B85
#define GL_OBJECT_ACTIVE_UNIFORMS_ARB             0x8B86
#define GL_OBJECT_ACTIVE_UNIFORM_MAX_LENGTH_ARB   0x8B87
#define GL_OBJECT_SHADER_SOURCE_LENGTH_ARB        0x8B88
#define GL_OBJECT_ACTIVE_ATTRIBUTE_MAX_LENGTH_ARB 0x8B8A
#define GL_OBJECT_ACTIVE_ATTRIBUTES_ARB           0x8B89

#endif /* GL_ARB_shader_objects */

typedef void (APIENTRY * PFNGL_VERTEXATTRIB4FVARBPROC)(GLuint index, const GLfloat *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3FVARBPROC)(GLuint index, const GLfloat *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2FVARBPROC)(GLuint index, const GLfloat *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1FVARBPROC)(GLuint index, const GLfloat *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4FARBPROC)(GLuint index, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3FARBPROC)(GLuint index, GLfloat v0, GLfloat v1, GLfloat v2);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2FARBPROC)(GLuint index, GLfloat v0, GLfloat v1);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1FARBPROC)(GLuint index, GLfloat v0);

typedef void (APIENTRY * PFNGL_VERTEXATTRIB4DVARBPROC)(GLuint index, const GLdouble *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3DVARBPROC)(GLuint index, const GLdouble *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2DVARBPROC)(GLuint index, const GLdouble *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1DVARBPROC)(GLuint index, const GLdouble *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4DARBPROC)(GLuint index, GLdouble v0, GLdouble v1, GLdouble v2, GLdouble v3);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3DARBPROC)(GLuint index, GLdouble v0, GLdouble v1, GLdouble v2);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2DARBPROC)(GLuint index, GLdouble v0, GLdouble v1);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1DARBPROC)(GLuint index, GLdouble v0);

typedef void (APIENTRY * PFNGL_VERTEXATTRIB4SVARBPROC)(GLuint index, const GLshort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3SVARBPROC)(GLuint index, const GLshort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2SVARBPROC)(GLuint index, const GLshort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1SVARBPROC)(GLuint index, const GLshort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4SARBPROC)(GLuint index, GLshort v0, GLshort v1, GLshort v2, GLshort v3);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB3SARBPROC)(GLuint index, GLshort v0, GLshort v1, GLshort v2);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB2SARBPROC)(GLuint index, GLshort v0, GLshort v1);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB1SARBPROC)(GLuint index, GLshort v0);

typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NUBARBPROC)(GLuint index, GLubyte x, GLubyte y, GLubyte z, GLubyte w);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4UBVARBPROC)(GLuint index, const GLubyte *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4USVARBPROC)(GLuint index, const GLushort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4UIVARBPROC)(GLuint index, const GLuint *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4IVARBPROC)(GLuint index, const GLint *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4BVARBPROC)(GLuint index, const GLbyte *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NBVARBPROC)(GLuint index, const GLbyte *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NSVARBPROC)(GLuint index, const GLshort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NIVARBPROC)(GLuint index, const GLint *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NUBVARBPROC)(GLuint index, const GLubyte *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NUSVARBPROC)(GLuint index, const GLushort *v);
typedef void (APIENTRY * PFNGL_VERTEXATTRIB4NUIVARBPROC)(GLuint index, const GLuint *v);

typedef void (APIENTRY * PFNGL_BINDATTRIBLOCATIONARBPROC)(GLhandleARB programObj, GLuint index, const GLcharARB *name);
typedef void (APIENTRY * PFNGL_BINDARRAYGL2PROC)(GLhandleARB shaderObject, GLenum array, const GLcharARB *name, GLint length);
typedef GLhandleARB (APIENTRY * PFNGL_CREATESHADEROBJECTARBPROC)(GLenum shaderType);
typedef GLhandleARB (APIENTRY * PFNGL_CREATEPROGRAMOBJECTARBPROC)();
typedef void (APIENTRY * PFNGL_DELETEOBJECTARBPROC)(GLhandleARB obj);

typedef void (APIENTRY * PFNGL_SHADERSOURCEARBPROC)(GLhandleARB shaderObj, GLsizei count, const GLcharARB **string, const GLint *length);
typedef void (APIENTRY * PFNGL_GETSHADERSOURCEARBPROC)(GLhandleARB obj, GLsizei maxLength, GLsizei *length, GLcharARB *source);

typedef void (APIENTRY * PFNGL_COMPILESHADERARBPROC)(GLhandleARB shaderObj);
typedef void (APIENTRY * PFNGL_DETACHOBJECTARBPROC)(GLhandleARB containerObj, GLhandleARB attachedObj);
typedef void (APIENTRY * PFNGL_ATTACHOBJECTARBPROC)(GLhandleARB containerObject, GLhandleARB obj);
typedef void (APIENTRY * PFNGL_USEPROGRAMOBJECTARBPROC)(GLhandleARB programObj);
typedef void (APIENTRY * PFNGL_GETINFOLOGARBPROC)(GLhandleARB obj,GLsizei maxLength, GLsizei *length, GLcharARB *infoLog);
typedef void (APIENTRY * PFNGL_GETATTACHEDOBJECTSARBPROC)(GLhandleARB containerObj, GLsizei maxCount, GLsizei *count, GLhandleARB *obj);
typedef void (APIENTRY * PFNGL_LINKPROGRAMARBPROC)(GLhandleARB programObj);

typedef void (APIENTRY * PFNGL_UNIFORM1FARBPROC)(GLint location, GLfloat v0);
typedef void (APIENTRY * PFNGL_UNIFORM2FARBPROC)(GLint location, GLfloat v0, GLfloat v1);
typedef void (APIENTRY * PFNGL_UNIFORM3FARBPROC)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2);
typedef void (APIENTRY * PFNGL_UNIFORM4FARBPROC)(GLint location, GLfloat v0, GLfloat v1, GLfloat v2, GLfloat v3);

typedef void (APIENTRY * PFNGL_UNIFORM1IARBPROC)(GLint location, GLint v0);
typedef void (APIENTRY * PFNGL_UNIFORM2IARBPROC)(GLint location, GLint v0, GLint v1);
typedef void (APIENTRY * PFNGL_UNIFORM3IARBPROC)(GLint location, GLint v0, GLint v1, GLint v2);
typedef void (APIENTRY * PFNGL_UNIFORM4IARBPROC)(GLint location, GLint v0, GLint v1, GLint v2, GLint v3);

typedef void (APIENTRY * PFNGL_UNIFORM1FVARBPROC)(GLint location, GLsizei count, GLfloat *value);
typedef void (APIENTRY * PFNGL_UNIFORM2FVARBPROC)(GLint location, GLsizei count, GLfloat *value);
typedef void (APIENTRY * PFNGL_UNIFORM3FVARBPROC)(GLint location, GLsizei count, GLfloat *value);
typedef void (APIENTRY * PFNGL_UNIFORM4FVARBPROC)(GLint location, GLsizei count, GLfloat *value);

typedef void (APIENTRY * PFNGL_UNIFORM1IVARBPROC)(GLint location, GLsizei count, GLint *value);
typedef void (APIENTRY * PFNGL_UNIFORM2IVARBPROC)(GLint location, GLsizei count, GLint *value);
typedef void (APIENTRY * PFNGL_UNIFORM3IVARBPROC)(GLint location, GLsizei count, GLint *value);
typedef void (APIENTRY * PFNGL_UNIFORM4IVARBPROC)(GLint location, GLsizei count, GLint *value);

typedef void (APIENTRY * PFNGL_UNIFORMMATRIX2FVARBPROC)(GLint location, GLuint count, GLboolean transpose, const GLfloat *value);
typedef void (APIENTRY * PFNGL_UNIFORMMATRIX3FVARBPROC)(GLint location, GLuint count, GLboolean transpose, const GLfloat *value);
typedef void (APIENTRY * PFNGL_UNIFORMMATRIX4FVARBPROC)(GLint location, GLuint count, GLboolean transpose, const GLfloat *value);
typedef GLint (APIENTRY * PFNGL_GETUNIFORMLOCATIONARBPROC)(GLhandleARB programObj, const GLcharARB *name);
typedef void (APIENTRY * PFNGL_GETACTIVEATTRIBARBPROC)(GLhandleARB programObj, GLuint index, GLsizei maxLength, GLsizei *length, GLint *size, 
													   GLenum *type, GLcharARB *name);
typedef void (APIENTRY * PFNGL_GETACTIVEUNIFORMARBPROC)(GLhandleARB programObj, GLuint index, GLsizei maxLength,
														GLsizei *length, GLint *size, GLenum *type, GLcharARB *name);
typedef void (APIENTRY * PFNGL_GETUNIFORMFVARBPROC)(GLhandleARB programObj, GLint location, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETUNIFORMIVARBPROC)(GLhandleARB programObj, GLint location, GLint *params);
typedef GLint (APIENTRY * PFNGL_GETATTRIBLOCATIONARBPROC)(GLhandleARB programObj, const GLcharARB *name);
typedef void (APIENTRY * PFNGL_VALIDATEPROGRAMARBPROC)(GLhandleARB programObj);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBPOINTERVARBPROC)(GLuint index, GLenum pname, void **pointer);
typedef void (APIENTRY * PFNGL_GETOBJECTPARAMETERFVARBPROC)(GLhandleARB obj, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETOBJECTPARAMETERIVARBPROC)(GLhandleARB obj, GLenum pname, GLint *params);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBDVARBPROC)(GLuint index, GLenum pname, GLdouble *params);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBFVARBPROC)(GLuint index, GLenum pname, GLfloat *params);
typedef void (APIENTRY * PFNGL_GETVERTEXATTRIBIVARBPROC)(GLuint index, GLenum pname, GLint *params);

#ifndef GL_VERSION_2_0
#define GL_VERSION_2_0 1

#define GL_PRESERVE_GL2				  0x10100
#define GL_DISCARD_GL2				  0x10200
#define GL_VERTEX_ARRAY_OBJECT_GL2		  0x40004
#define GL_VERTEX_ARRAY_FORMAT_OBJECT_GL2	  0x40008
#define GL_PAD_ARRAY_GL2			  0x80000
#define GL_ALL_INDEX_ARRAY_GL2			  0x80001
#define GL_TEXTURE_COORD0_ARRAY_GL2		  0x80002
#define GL_TEXTURE_COORD1_ARRAY_GL2		  0x80003
#define GL_TEXTURE_COORD2_ARRAY_GL2		  0x80004
#define GL_TEXTURE_COORD3_ARRAY_GL2		  0x80005
#define GL_TEXTURE_COORD4_ARRAY_GL2		  0x80006
#define GL_TEXTURE_COORD5_ARRAY_GL2		  0x80007
#define GL_TEXTURE_COORD6_ARRAY_GL2		  0x80008
#define GL_TEXTURE_COORD7_ARRAY_GL2		  0x80009
#define GL_USER_ATTRIBUTE_ARRAY0_GL2		  0x8000A
#define GL_USER_ATTRIBUTE_ARRAY1_GL2		  0x8000B
#define GL_USER_ATTRIBUTE_ARRAY2_GL2		  0x8000C
#define GL_USER_ATTRIBUTE_ARRAY3_GL2		  0x8000D
#define GL_USER_ATTRIBUTE_ARRAY4_GL2		  0x8000E
#define GL_USER_ATTRIBUTE_ARRAY5_GL2		  0x8000F
#define GL_USER_ATTRIBUTE_ARRAY6_GL2		  0x80010
#define GL_USER_ATTRIBUTE_ARRAY7_GL2		  0x80011
#define GL_USER_ATTRIBUTE_ARRAY8_GL2		  0x80012
#define GL_USER_ATTRIBUTE_ARRAY9_GL2		  0x80013
#define GL_USER_ATTRIBUTE_ARRAY10_GL2	 	  0x80014
#define GL_USER_ATTRIBUTE_ARRAY11_GL2		  0x80015
#define GL_USER_ATTRIBUTE_ARRAY12_GL2		  0x80016
#define GL_USER_ATTRIBUTE_ARRAY13_GL2		  0x80017
#define GL_USER_ATTRIBUTE_ARRAY14_GL2		  0x80018
#define GL_USER_ATTRIBUTE_ARRAY15_GL2		  0x80019

#endif /* VERSION_2_0 */

typedef GLhandleARB (APIENTRY * PFNGL_GETHANDLEARBPROC)(GLenum pname);
typedef GLhandleARB (APIENTRY * PFNGL_CREATEVERTEXARRAYOBJECTGL2PROC)(GLhandleARB formatObject, GLsizei count);
typedef void (APIENTRY * PFNGL_LOADVERTEXARRAYDATAGL2PROC)(GLhandleARB object, GLuint start, GLsizei count, void *data, GLenum preserve);
typedef GLhandleARB (APIENTRY * PFNGL_STARTVERTEXARRAYFORMATGL2PROC)();
typedef void (APIENTRY * PFNGL_ADDELEMENTGL2PROC)(GLhandleARB formatObject, GLenum array, GLsizei size, GLenum type);
typedef void (APIENTRY * PFNGL_ENABLEVERTEXARRAYOBJECTGL2PROC)(GLhandleARB object);
typedef void (APIENTRY * PFNGL_DISABLEVERTEXARRAYOBJECTGL2PROC)(GLhandleARB object);
typedef void (APIENTRY * PFNGL_DRAWINDEXEDARRAYSGL2PROC)(GLenum mode, GLuint first, GLsizei count);

/*************************************************************/

#ifndef GL_SGIS_multisample
#define GL_SGIS_multisample 1

#define GL_MULTISAMPLE_SGIS                       0x809D
#define GL_SAMPLE_ALPHA_TO_MASK_SGIS              0x809E
#define GL_SAMPLE_ALPHA_TO_ONE_SGIS               0x809F
#define GL_SAMPLE_MASK_SGIS                       0x80A0
#define GL_1PASS_SGIS                             0x80A1
#define GL_2PASS_0_SGIS                           0x80A2
#define GL_2PASS_1_SGIS                           0x80A3
#define GL_4PASS_0_SGIS                           0x80A4
#define GL_4PASS_1_SGIS                           0x80A5
#define GL_4PASS_2_SGIS                           0x80A6
#define GL_4PASS_3_SGIS                           0x80A7
#define GL_SAMPLE_BUFFERS_SGIS                    0x80A8
#define GL_SAMPLES_SGIS                           0x80A9
#define GL_SAMPLE_MASK_VALUE_SGIS                 0x80AA
#define GL_SAMPLE_MASK_INVERT_SGIS                0x80AB
#define GL_SAMPLE_PATTERN_SGIS                    0x80AC

#endif /* GL_SGIS_multisample */

typedef void (APIENTRY * PFNGL_SAMPLEMASKSGISPROC)(GLclampf value, GLboolean invert);
typedef void (APIENTRY * PFNGL_SAMPLECOVERAGEARBPROC)(GLclampf value, GLboolean invert);
typedef void (APIENTRY * PFNGL_TAGSAMPLEBUFFERSGIXPROC)(void);

#ifndef GL_NV_register_combiners
#define GL_NV_register_combiners 1

#define GL_REGISTER_COMBINERS_NV                  0x8522
#define GL_COMBINER0_NV                           0x8550
#define GL_COMBINER1_NV                           0x8551
#define GL_COMBINER2_NV                           0x8552
#define GL_COMBINER3_NV                           0x8553
#define GL_COMBINER4_NV                           0x8554
#define GL_COMBINER5_NV                           0x8555
#define GL_COMBINER6_NV                           0x8556
#define GL_COMBINER7_NV                           0x8557
#define GL_VARIABLE_A_NV                          0x8523
#define GL_VARIABLE_B_NV                          0x8524
#define GL_VARIABLE_C_NV                          0x8525
#define GL_VARIABLE_D_NV                          0x8526
#define GL_VARIABLE_E_NV                          0x8527
#define GL_VARIABLE_F_NV                          0x8528
#define GL_VARIABLE_G_NV                          0x8529
#define GL_CONSTANT_COLOR0_NV                     0x852A
#define GL_CONSTANT_COLOR1_NV                     0x852B
#define GL_PRIMARY_COLOR_NV                       0x852C
#define GL_SECONDARY_COLOR_NV                     0x852D
#define GL_SPARE0_NV                              0x852E
#define GL_SPARE1_NV                              0x852F
#define GL_UNSIGNED_IDENTITY_NV                   0x8536
#define GL_UNSIGNED_INVERT_NV                     0x8537
#define GL_EXPAND_NORMAL_NV                       0x8538
#define GL_EXPAND_NEGATE_NV                       0x8539
#define GL_HALF_BIAS_NORMAL_NV                    0x853A
#define GL_HALF_BIAS_NEGATE_NV                    0x853B
#define GL_SIGNED_IDENTITY_NV                     0x853C
#define GL_SIGNED_NEGATE_NV                       0x853D
#define GL_E_TIMES_F_NV                           0x8531
#define GL_SPARE0_PLUS_SECONDARY_COLOR_NV         0x8532
#define GL_SCALE_BY_TWO_NV                        0x853E
#define GL_SCALE_BY_FOUR_NV                       0x853F
#define GL_SCALE_BY_ONE_HALF_NV                   0x8540
#define GL_BIAS_BY_NEGATIVE_ONE_HALF_NV           0x8541
#define GL_DISCARD_NV                             0x8530
#define GL_COMBINER_INPUT_NV                      0x8542
#define GL_COMBINER_MAPPING_NV                    0x8543
#define GL_COMBINER_COMPONENT_USAGE_NV            0x8544
#define GL_COMBINER_AB_DOT_PRODUCT_NV             0x8545
#define GL_COMBINER_CD_DOT_PRODUCT_NV             0x8546
#define GL_COMBINER_MUX_SUM_NV                    0x8547
#define GL_COMBINER_SCALE_NV                      0x8548
#define GL_COMBINER_BIAS_NV                       0x8549
#define GL_COMBINER_AB_OUTPUT_NV                  0x854A
#define GL_COMBINER_CD_OUTPUT_NV                  0x854B
#define GL_COMBINER_SUM_OUTPUT_NV                 0x854C
#define GL_NUM_GENERAL_COMBINERS_NV               0x854E
#define GL_COLOR_SUM_CLAMP_NV                     0x854F
#define GL_MAX_GENERAL_COMBINERS_NV               0x854D

#endif /* NV_register_combiners */

typedef void (APIENTRY *PFNGL_COMBINERPARAMETERFVNVPROC)(GLenum pname, const GLfloat *params);
typedef void (APIENTRY *PFNGL_COMBINERPARAMETERFNVPROC)(GLenum pname, GLfloat param);
typedef void (APIENTRY *PFNGL_COMBINERPARAMETERIVNVPROC)(GLenum pname, const GLint *params);
typedef void (APIENTRY *PFNGL_COMBINERPARAMETERINVPROC)(GLenum pname, GLint param);
typedef void (APIENTRY *PFNGL_COMBINERINPUTNVPROC)(GLenum stage, GLenum portion, GLenum variable, GLenum input, GLenum mapping, GLenum componentUsage);
typedef void (APIENTRY *PFNGL_COMBINEROUTPUTNVPROC)(GLenum stage, GLenum portion, GLenum abOutput, GLenum cdOutput, GLenum sumOutput, GLenum scale, GLenum bias, GLboolean abDotProduct, GLboolean cdDotProduct, GLboolean muxSum);
typedef void (APIENTRY *PFNGL_FINALCOMBINERINPUTNVPROC)(GLenum variable, GLenum input, GLenum mapping, GLenum componentUsage);
typedef void (APIENTRY *PFNGL_GETCOMBINERINPUTPARAMETERFVNVPROC)(GLenum stage, GLenum portion, GLenum variable, GLenum pname, GLfloat *params);
typedef void (APIENTRY *PFNGL_GETCOMBINERINPUTPARAMETERIVNVPROC)(GLenum stage, GLenum portion, GLenum variable, GLenum pname, GLint *params);
typedef void (APIENTRY *PFNGL_GETCOMBINEROUTPUTPARAMETERFVNVPROC)(GLenum stage, GLenum portion, GLenum pname, GLfloat *params);
typedef void (APIENTRY *PFNGL_GETCOMBINEROUTPUTPARAMETERIVNVPROC)(GLenum stage, GLenum portion, GLenum pname, GLint *params);
typedef void (APIENTRY *PFNGL_GETFINALCOMBINERINPUTPARAMETERFVNVPROC)(GLenum variable, GLenum pname, GLfloat *params);
typedef void (APIENTRY *PFNGL_GETFINALCOMBINERINPUTPARAMETERIVNVPROC)(GLenum variable, GLenum pname, GLint *params);

#ifndef GL_ARB_multitexture
#define GL_ARB_multitexture 1

#define GL_TEXTURE0_ARB                           0x84C0
#define GL_TEXTURE1_ARB                           0x84C1
#define GL_TEXTURE2_ARB                           0x84C2
#define GL_TEXTURE3_ARB                           0x84C3
#define GL_TEXTURE4_ARB                           0x84C4
#define GL_TEXTURE5_ARB                           0x84C5
#define GL_TEXTURE6_ARB                           0x84C6
#define GL_TEXTURE7_ARB                           0x84C7
#define GL_TEXTURE8_ARB                           0x84C8
#define GL_TEXTURE9_ARB                           0x84C9
#define GL_TEXTURE10_ARB                          0x84CA
#define GL_TEXTURE11_ARB                          0x84CB
#define GL_TEXTURE12_ARB                          0x84CC
#define GL_TEXTURE13_ARB                          0x84CD
#define GL_TEXTURE14_ARB                          0x84CE
#define GL_TEXTURE15_ARB                          0x84CF
#define GL_TEXTURE16_ARB                          0x84D0
#define GL_TEXTURE17_ARB                          0x84D1
#define GL_TEXTURE18_ARB                          0x84D2
#define GL_TEXTURE19_ARB                          0x84D3
#define GL_TEXTURE20_ARB                          0x84D4
#define GL_TEXTURE21_ARB                          0x84D5
#define GL_TEXTURE22_ARB                          0x84D6
#define GL_TEXTURE23_ARB                          0x84D7
#define GL_TEXTURE24_ARB                          0x84D8
#define GL_TEXTURE25_ARB                          0x84D9
#define GL_TEXTURE26_ARB                          0x84DA
#define GL_TEXTURE27_ARB                          0x84DB
#define GL_TEXTURE28_ARB                          0x84DC
#define GL_TEXTURE29_ARB                          0x84DD
#define GL_TEXTURE30_ARB                          0x84DE
#define GL_TEXTURE31_ARB                          0x84DF
#define GL_ACTIVE_TEXTURE_ARB                     0x84E0
#define GL_CLIENT_ACTIVE_TEXTURE_ARB              0x84E1
#define GL_MAX_TEXTURE_UNITS_ARB                  0x84E2

#endif /* GL_ARB_multitexture */

typedef void (APIENTRY * PFNGL_ACTIVETEXTUREARBPROC)(GLenum texture);
typedef void (APIENTRY * PFNGL_CLIENTACTIVETEXTUREARBPROC)(GLenum texture);
typedef void (APIENTRY * PFNGL_MULTITEXCOORD2FARBPROC)(GLenum target, GLfloat s, GLfloat t);
typedef void (APIENTRY * PFNGL_MULTITEXCOORD2FVARBPROC)(GLenum target, const GLfloat *v);

#ifndef GL_EXT_texture
#define GL_EXT_texture 1

#define GL_ALPHA4_EXT                             0x803B
#define GL_ALPHA8_EXT                             0x803C
#define GL_ALPHA12_EXT                            0x803D
#define GL_ALPHA16_EXT                            0x803E
#define GL_LUMINANCE4_EXT                         0x803F
#define GL_LUMINANCE8_EXT                         0x8040
#define GL_LUMINANCE12_EXT                        0x8041
#define GL_LUMINANCE16_EXT                        0x8042
#define GL_LUMINANCE4_ALPHA4_EXT                  0x8043
#define GL_LUMINANCE6_ALPHA2_EXT                  0x8044
#define GL_LUMINANCE8_ALPHA8_EXT                  0x8045
#define GL_LUMINANCE12_ALPHA4_EXT                 0x8046
#define GL_LUMINANCE12_ALPHA12_EXT                0x8047
#define GL_LUMINANCE16_ALPHA16_EXT                0x8048
#define GL_INTENSITY_EXT                          0x8049
#define GL_INTENSITY4_EXT                         0x804A
#define GL_INTENSITY8_EXT                         0x804B
#define GL_INTENSITY12_EXT                        0x804C
#define GL_INTENSITY16_EXT                        0x804D
#define GL_RGB2_EXT                               0x804E
#define GL_RGB4_EXT                               0x804F
#define GL_RGB5_EXT                               0x8050
#define GL_RGB8_EXT                               0x8051
#define GL_RGB10_EXT                              0x8052
#define GL_RGB12_EXT                              0x8053
#define GL_RGB16_EXT                              0x8054
#define GL_RGBA2_EXT                              0x8055
#define GL_RGBA4_EXT                              0x8056
#define GL_RGB5_A1_EXT                            0x8057
#define GL_RGBA8_EXT                              0x8058
#define GL_RGB10_A2_EXT                           0x8059
#define GL_RGBA12_EXT                             0x805A
#define GL_RGBA16_EXT                             0x805B

#endif /* ext_texture */

#ifndef GL_EXT_texture3D
#define GL_EXT_texture3D 1

#endif /* EXT_texture3D */

typedef void (APIENTRY * PFNGL_TEXIMAGE3DEXTPROC)(GLenum target, GLint level, GLenum internalformat, GLsizei width, GLsizei height, GLsizei depth, GLint border, GLenum format, GLenum type, const void *pixels);

#ifndef GL_EXT_subtexture
#define GL_EXT_subtexture 1

#endif /* EXT_subtexture */

typedef void (APIENTRY * PFNGL_TEXSUBIMAGE3DEXTPROC)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLsizei width, GLsizei height, GLsizei depth, GLenum format, GLenum type, const void *pixels);

#ifndef GL_EXT_copy_texture 
#define GL_EXT_copy_texture 1

#endif /* EXT_copy_texture */

typedef void (APIENTRY * PFNGL_COPYTEXSUBIMAGE3DEXTPROC)(GLenum target, GLint level, GLint xoffset, GLint yoffset, GLint zoffset, GLint x, GLint y, GLsizei width, GLsizei height);

#ifndef GL_SGIS_detail_texture
#define GL_SGIS_detail_texture 1

#endif /* SGIS_detail_texture */

typedef void (APIENTRY * PFNGL_DETAILTEXFUNCSGISPROC)(GLenum target, GLsizei n, const GLfloat *points);

#ifndef GL_SGIS_sharpen_texture
#define GL_SGIS_sharpen_texture 1

#endif /* SGIS_sharpen_texture */

typedef void (APIENTRY * PFNGL_SHARPENTEXFUNCSGISPROC)(GLenum target, GLsizei n, const GLfloat *points);

#ifndef GL_ATI_texture_float
#define GL_ATI_texture_float 1

#define GL_RGBA_FLOAT32_ATI                       0x8814
#define GL_RGB_FLOAT32_ATI                        0x8815
#define GL_ALPHA_FLOAT32_ATI                      0x8816
#define GL_INTENSITY_FLOAT32_ATI                  0x8817
#define GL_LUMINANCE_FLOAT32_ATI                  0x8818
#define GL_LUMINANCE_ALPHA_FLOAT32_ATI            0x8819
#define GL_RGBA_FLOAT16_ATI                       0x881A
#define GL_RGB_FLOAT16_ATI                        0x881B
#define GL_ALPHA_FLOAT16_ATI                      0x881C
#define GL_INTENSITY_FLOAT16_ATI                  0x881D
#define GL_LUMINANCE_FLOAT16_ATI                  0x881E
#define GL_LUMINANCE_ALPHA_FLOAT16_ATI            0x881F

#endif  /* GL_ATI_texture_float */

#ifndef GL_ARB_texture_cube_map
#define GL_ARB_texture_cube_map 1

#define GL_NORMAL_MAP_ARB                         0x8511
#define GL_REFLECTION_MAP_ARB                     0x8512
#define GL_TEXTURE_CUBE_MAP_ARB                   0x8513
#define GL_TEXTURE_BINDING_CUBE_MAP_ARB           0x8514
#define GL_TEXTURE_CUBE_MAP_POSITIVE_X_ARB        0x8515
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_X_ARB        0x8516
#define GL_TEXTURE_CUBE_MAP_POSITIVE_Y_ARB        0x8517
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_Y_ARB        0x8518
#define GL_TEXTURE_CUBE_MAP_POSITIVE_Z_ARB        0x8519
#define GL_TEXTURE_CUBE_MAP_NEGATIVE_Z_ARB        0x851A
#define GL_PROXY_TEXTURE_CUBE_MAP_ARB             0x851B
#define GL_MAX_CUBE_MAP_TEXTURE_SIZE_ARB          0x851C

#endif /* GL_ARB_texture_cube_map */

#ifndef GL_EXT_secondary_color
#define GL_EXT_secondary_color 1

#define GL_COLOR_SUM_EXT                          0x8458
#define GL_CURRENT_SECONDARY_COLOR_EXT            0x8459
#define GL_SECONDARY_COLOR_ARRAY_SIZE_EXT         0x845A
#define GL_SECONDARY_COLOR_ARRAY_TYPE_EXT         0x845B
#define GL_SECONDARY_COLOR_ARRAY_STRIDE_EXT       0x845C
#define GL_SECONDARY_COLOR_ARRAY_POINTER_EXT      0x845D
#define GL_SECONDARY_COLOR_ARRAY_EXT              0x845E

#endif /* GL_EXT_secondary_color */

typedef void (APIENTRY * PFNGL_SECONDARYCOLORPOINTEREXTPROC)(GLint size, GLenum type, GLsizei stride, void *pointer);

#ifndef GL_EXT_fog_coord
#define GL_EXT_fog_coord 1

#define GL_FOG_COORDINATE_SOURCE_EXT              0x8450
#define GL_FOG_COORDINATE_EXT                     0x8451
#define GL_FRAGMENT_DEPTH_EXT                     0x8452
#define GL_CURRENT_FOG_COORDINATE_EXT             0x8453
#define GL_FOG_COORDINATE_ARRAY_TYPE_EXT          0x8454
#define GL_FOG_COORDINATE_ARRAY_STRIDE_EXT        0x8455
#define GL_FOG_COORDINATE_ARRAY_POINTER_EXT       0x8456
#define GL_FOG_COORDINATE_ARRAY_EXT               0x8457

#endif /* GL_EXT_fog_coord */

typedef void (APIENTRY * PFNGL_FOGCOORDPOINTEREXTPROC)(GLenum type, GLsizei stride, void *pointer);

#ifndef GL_ARB_vertex_blend
#define GL_ARB_vertex_blend 1

#define GL_MODELVIEW0_ARB                         0x1700
#define GL_MODELVIEW1_ARB                         0x850a
#define GL_MODELVIEW2_ARB                         0x8722
#define GL_MODELVIEW3_ARB                         0x8723
#define GL_MODELVIEW4_ARB                         0x8724
#define GL_MODELVIEW5_ARB                         0x8725
#define GL_MODELVIEW6_ARB                         0x8726
#define GL_MODELVIEW7_ARB                         0x8727
#define GL_MODELVIEW8_ARB                         0x8728
#define GL_MODELVIEW9_ARB                         0x8729
#define GL_MODELVIEW10_ARB                        0x872A
#define GL_MODELVIEW11_ARB                        0x872B
#define GL_MODELVIEW12_ARB                        0x872C
#define GL_MODELVIEW13_ARB                        0x872D
#define GL_MODELVIEW14_ARB                        0x872E
#define GL_MODELVIEW15_ARB                        0x872F
#define GL_MODELVIEW16_ARB                        0x8730
#define GL_MODELVIEW17_ARB                        0x8731
#define GL_MODELVIEW18_ARB                        0x8732
#define GL_MODELVIEW19_ARB                        0x8733
#define GL_MODELVIEW20_ARB                        0x8734
#define GL_MODELVIEW21_ARB                        0x8735
#define GL_MODELVIEW22_ARB                        0x8736
#define GL_MODELVIEW23_ARB                        0x8737
#define GL_MODELVIEW24_ARB                        0x8738
#define GL_MODELVIEW25_ARB                        0x8739
#define GL_MODELVIEW26_ARB                        0x873A
#define GL_MODELVIEW27_ARB                        0x873B
#define GL_MODELVIEW28_ARB                        0x873C
#define GL_MODELVIEW29_ARB                        0x873D
#define GL_MODELVIEW30_ARB                        0x873E
#define GL_MODELVIEW31_ARB                        0x873F    
#define GL_CURRENT_WEIGHT_ARB                     0x86A8
#define GL_WEIGHT_ARRAY_TYPE_ARB                  0x86A9
#define GL_WEIGHT_ARRAY_STRIDE_ARB                0x86AA
#define GL_WEIGHT_ARRAY_SIZE_ARB                  0x86AB
#define GL_WEIGHT_ARRAY_POINTER_ARB               0x86AC
#define GL_WEIGHT_ARRAY_ARB                       0x86AD

#endif /* GL_ARB_vertex_blend */

typedef void (APIENTRY * PFNGL_WEIGHTPOINTERARBPROC)(GLint size, GLenum type, GLsizei stride, void *pointer);
typedef void (APIENTRY * PFNGL_VERTEXBLENDARBPROC)(GLint count);

#ifndef GL_SGIX_reference_plane
#define GL_SGIX_reference_plane 1

#endif /* SGIX_reference_plane */

typedef void (APIENTRY * PFNGL_REFERENCEPLANESGIXPROC)(const GLdouble *equation);

#ifndef GL_EXT_point_parameters
#define GL_EXT_point_parameters 1

#endif /* EXT_point_parameters */

typedef void (APIENTRY * PFNGL_POINTPARAMETERFEXTPROC)(GLenum pname, GLfloat param);

#ifndef GL_SGI_color_table
#define GL_SGI_color_table 1

#endif /* SGI_color_table */

typedef void (APIENTRY * PFNGL_COLORTABLESGIPROC)(GLenum target, GLenum internalformat, GLsizei width, GLenum format, GLenum type, const void *table);

#ifndef GL_ATI_separate_stencil
#define GL_ATI_separate_stencil 1

#endif  /* ATI_separate_stencil */

typedef void (APIENTRY * PFNGL_STENCILFUNCSEPARATEATIPROC)(GLenum frontFunc, GLenum backFunc, int ref, GLuint mask);
typedef void (APIENTRY * PFNGL_STENCILOPSEPARATEATIPROC)(GLenum face, GLenum sfail, GLenum dpfail, GLenum dppass);

/* GLX extension functions */
#if defined(__using_X11__)

#ifndef GLX_ARB_get_proc_address
#define GLX_ARB_get_proc_address 1

#endif /* ARB_get_proc_address */

typedef int (APIENTRY * PFNGLX_GETPROCADDRESSARBPROC) (const GLubyte *procName);

#ifndef GLX_SGI_swap_control
#define GLX_SGI_swap_control 1

#endif /* SGI_swap_control */

typedef int (APIENTRY *PFNGLX_SWAPINTERVALSGIPROC)(int);

#ifndef GLX_SGI_video_sync
#define GLX_SGI_video_sync 1

#endif /* SGI_video_sync */

typedef int (APIENTRY *PFNGLX_GETVIDEOSYNCSGIPROC)(unsigned int *);
typedef int (APIENTRY *PFNGLX_WAITVIDEOSYNCSGIPROC)(int, int, unsigned int *);

#ifndef GLX_SGIX_fbconfig 
#define GLX_SGIX_fbconfig 1

/* Do we need this? */
typedef GLXFBConfig GLXFBConfigSGIX;

#endif /* SGIX_fbconfig */

typedef GLXContext (APIENTRY *PFNGLX_CREATECONTEXTWITHCONFIGSGIXPROC)(Display *, GLXFBConfigSGIX , int , GLXContext , Bool);
typedef XVisualInfo *(APIENTRY *PFNGLX_GETVISUALFROMFBCONFIGSGIXPROC)(Display *, GLXFBConfigSGIX);

#ifndef GLX_SGIX_pbuffer 
#define GLX_SGIX_pbuffer 1

#endif /* SGIX_pbuffer */

typedef void (APIENTRY *PFNGLX_QUERYGLXPBUFFERSGIXPROC)(Display *, GLXPbuffer , int , unsigned int *);
typedef GLXPbuffer (APIENTRY *PFNGLX_CREATEGLXPBUFFERSGIXPROC)(Display *, GLXFBConfig , unsigned int , unsigned int , int *);

#ifndef GLX_SGIX_swap_barrier
#define GLX_SGIX_swap_barrier 1

#endif /* SGIX_swap_barrier */

typedef void (APIENTRY *PFNGLX_BINDSWAPBARRIERSGIXPROC)(Display *, Window w, int barrier);
typedef Bool (APIENTRY *PFNGLX_QUERYMAXSWAPBARRIERSSGIXPROC)(Display *, int screen, int *max);

#ifndef GLX_SGIX_swap_group
#define GLX_SGIX_swap_group 1

#endif /* SGIX_swap_group */

typedef void (APIENTRY *PFNGLX_JOINSWAPGROUPSGIXPROC)(Display *, Window w, Window group);

#if !defined(GLX_SGIX_hyperpipe) && !defined(GLX_SGIX_hyperpipe_group)
#define GLX_SGIX_hyperpipe 1

/* Mesa glext.h uses hyperpipe_group instead */
#ifndef GLX_SGIX_hyperpipe_group
#define GLX_SGIX_hyperpipe_group 1

#define GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX       80
#define GLX_BAD_HYPERPIPE_CONFIG_SGIX             91
#define GLX_BAD_HYPERPIPE_SGIX                    92
#define GLX_HYPERPIPE_DISPLAY_PIPE_SGIX           0x00000001
#define GLX_HYPERPIPE_RENDER_PIPE_SGIX            0x00000002
#define GLX_PIPE_RECT_SGIX                        0x00000001
#define GLX_PIPE_RECT_LIMITS_SGIX                 0x00000002
#define GLX_HYPERPIPE_STEREO_SGIX                 0x00000003
#define GLX_HYPERPIPE_PIXEL_AVERAGE_SGIX          0x00000004
#define GLX_HYPERPIPE_ID_SGIX                     0x8030

typedef struct {
    char pipeName[GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX];
    int channel;
    unsigned int participationType;
    int timeSlice;
} GLXHyperpipeConfigSGIX;

typedef struct {
    char pipeName[GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX];
    int networkId;
} GLXHyperpipeNetworkSGIX;

typedef struct {
  char pipeName[GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX];
                   /* Which pipe, in the form ":display.screen"
                    */
  int srcXOrigin;  /* source is specified in managed area */
  int srcYOrigin;  /* coordinates (pixels) */
  int srcWidth;
  int srcHeight;

  int destXOrigin; /* destination is specified in output */
  int destYOrigin; /* channel display coordinates */
  int destWidth;
  int destHeight;

} GLXPipeRect;

typedef struct {
  char pipeName[GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX];
  int XOrigin; /* pixels in managed area */
  int YOrigin;
  int maxHeight;
  int maxWidth;
} GLXPipeRectLimits;

#endif /* SGIX_hyperpipe_group */

#endif /* SGIX_hyperpipe */

typedef int (APIENTRY * PFNGLX_BINDHYPERPIPESGIXPROC)( Display *dpy, int hpId );
typedef int (APIENTRY * PFNGLX_DESTROYHYPERPIPECONFIGSGIXPROC)( Display *dpy, int hpId );
typedef int (APIENTRY * PFNGLX_HYPERPIPECONFIGSGIXPROC)( Display *dpy, int networkId, int npipes, GLXHyperpipeConfigSGIX *cfg, int *hpId );
typedef GLXHyperpipeNetworkSGIX * (APIENTRY * PFNGLX_QUERYHYPERPIPENETWORKSGIXPROC)( Display * dpy, int *npipes );
typedef int (APIENTRY * PFNGLX_QUERYHYPERPIPEATTRIBSGIXPROC)(Display *dpy, int timeSlice, int attrib, int size, void *returnAttribList);
typedef int (APIENTRY * PFNGLX_HYPERPIPEATTRIBSGIXPROC)(Display *dpy, int timeSlice, int attrib, int size, void *attribList);

#ifndef GLX_EXT_import_context 
#define GLX_EXT_import_context 1

#endif /* EXT_import_context */

typedef int (APIENTRY * PFNGLX_QUERYCONTEXTINFOEXTPROC)( Display *dpy, GLXContext ctx, int attribute, int *value );

#elif defined(WIN32)

#ifndef GLX_SGIX_hyperpipe
#define GLX_SGIX_hyperpipe 1

#define GLX_HYPERPIPE_PIPE_NAME_LENGTH_SGIX       80
#define GLX_HYPERPIPE_PIXEL_AVERAGE_SGIX          0x00000004

#endif /* SGIX_hyperpipe */

#endif /* wgl specific extensions */


#ifdef __cplusplus
}
#endif

#endif /* __PF_GLEXT_H__ */


