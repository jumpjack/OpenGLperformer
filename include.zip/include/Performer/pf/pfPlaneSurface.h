 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.7 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfPlaneSurface_h_
#define _pfPlaneSurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>


#define PFPLANESURFACE ((pfPlaneSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFPLANESURFACEBUFFER ((pfPlaneSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfPlaneSurface : public pfParaSurface
{
public:

    inline void setPoint1(pfReal x1,pfReal y1,pfReal z1,pfReal u1,pfReal v1)  {
        PFPLANESURFACE->nb_setPoint1(x1, y1, z1, u1, v1);
    }

    inline void setPoint2(pfReal x2,pfReal y2,pfReal z2,pfReal u2)  {
        PFPLANESURFACE->nb_setPoint2(x2, y2, z2, u2);
    }

    inline void setPoint3(pfReal x3,pfReal y3,pfReal z3,pfReal v3)  {
        PFPLANESURFACE->nb_setPoint3(x3, y3, z3, v3);
    }

    inline void getPoint1(pfReal *x1,pfReal *y1,pfReal *z1,pfReal *u1,pfReal *v1)  {
        PFPLANESURFACE->nb_getPoint1(x1, y1, z1, u1, v1);
    }

    inline void getPoint2(pfReal *x2,pfReal *y2,pfReal *z2,pfReal *u2)  {
        PFPLANESURFACE->nb_getPoint2(x2, y2, z2, u2);
    }

    inline void getPoint3(pfReal *x3,pfReal *y3,pfReal *z3,pfReal *v3)  {
        PFPLANESURFACE->nb_getPoint3(x3, y3, z3, v3);
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFPLANESURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalDu(pfReal u,pfReal v,pfRVec3 &Du)  {
        PFPLANESURFACE->nb_evalDu(u, v, Du);
    }

    inline void evalDv(pfReal u,pfReal v,pfRVec3 &Dv)  {
        PFPLANESURFACE->nb_evalDv(u, v, Dv);
    }

    inline void evalNorm(pfReal u,pfReal v,pfRVec3 &norm)  {
        PFPLANESURFACE->nb_evalNorm(u, v, norm);
    }
public:
  //CAPI:basename PlaneSurface
  //CAPI:updatable
  //CAPI:newargs
   pfPlaneSurface();
  //CAPI:verb NewPlaneSurfaceWithArgs
   pfPlaneSurface(pfReal x1,pfReal y1,pfReal z1,pfReal u1,pfReal v1,pfReal x2,pfReal y2,pfReal z2,pfReal u2,pfReal x3,pfReal y3,pfReal z3,pfReal v3);
   virtual ~pfPlaneSurface();
protected:
   pfPlaneSurface(pfBuffer *buf);
   pfPlaneSurface(const pfPlaneSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

 public:

   // <subsection Accessor functions>
   void nb_setPoint1(pfReal x1,pfReal y1,pfReal z1,pfReal u1,pfReal v1);
   void nb_setPoint2(pfReal x2,pfReal y2,pfReal z2,pfReal u2);
   void nb_setPoint3(pfReal x3,pfReal y3,pfReal z3,pfReal v3);
   void nb_getPoint1(pfReal *x1,pfReal *y1,pfReal *z1,pfReal *u1,pfReal *v1);
   void nb_getPoint2(pfReal *x2,pfReal *y2,pfReal *z2,pfReal *u2);
   void nb_getPoint3(pfReal *x3,pfReal *y3,pfReal *z3,pfReal *v3);

   //CAPI:virtual
   void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
   //CAPI:virtual
   void nb_evalDu(pfReal u,pfReal v,pfRVec3 &Du);
   //CAPI:virtual
   void nb_evalDv(pfReal u,pfReal v,pfRVec3 &Dv);
   //CAPI:virtual
   void nb_evalNorm(pfReal u,pfReal v,pfRVec3 &norm);

protected:
   pfRVec3 orig, pu, pv;
   /*
      The three points that define the plane.
      These three points form an affine coordinate system
      on the plane and provide a parameterization.
      pu-orig and pv-orig are the directions of the two axes, and
      orig is the origin.
   */
      
   pfRVec3 uDirection;
   // Cached value that is equal to pu - orig.

   pfRVec3 vDirection;
   // Cached value that is equal to pv - orig.

   pfRVec3 normal;
   // The normal of the plane computed from uDirection and vDirection

   pfReal uScale, uBias;
   // u is shifted and scaled by these two numbers.

   pfReal vScale, vBias;
   // v is shifted and scaled by these two numbers.


 private:
   static pfType *classType;

};
#endif

