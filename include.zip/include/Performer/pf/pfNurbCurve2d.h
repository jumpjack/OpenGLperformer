 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 // ####################################################################



#ifndef _PF_NURBCURVE2D_H_
#define _PF_NURBCURVE2D_H_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve2d.h>
#include <Performer/pf/pfDVector.h>

class pfParaSurface;

#define PFNURBCURVE2D ((pfNurbCurve2d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFNURBCURVE2DBUFFER ((pfNurbCurve2d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfNurbCurve2d : public pfCurve2d
{
public:

    inline void setControlHull(int i,const pfRVec3 &p)  {
        PFNURBCURVE2D->nb_setControlHull(i, p);
    }

    inline void setWeight(int i,pfReal w)  {
        PFNURBCURVE2D->nb_setWeight(i, w);
    }

    inline void setKnot(int i,pfReal t)  {
        PFNURBCURVE2D->nb_setKnot(i, t);
    }

    inline void setControlHullSize(int s)  {
        PFNURBCURVE2D->nb_setControlHullSize(s);
    }

    inline pfRVec2* getControlHull(int i)  {
        return PFNURBCURVE2D->nb_getControlHull(i);
    }

    inline pfReal getWeight(int i)  {
        return PFNURBCURVE2D->nb_getWeight(i);
    }

    inline int getControlHullSize()  {
        return PFNURBCURVE2D->nb_getControlHullSize();
    }

    inline int getKnotCount()  {
        return PFNURBCURVE2D->nb_getKnotCount();
    }

    inline pfReal getKnot(int i)  {
        return PFNURBCURVE2D->nb_getKnot(i);
    }

    inline int getOrder()  {
        return PFNURBCURVE2D->nb_getOrder();
    }

    inline void removeControlHullPnt(int i)  {
        PFNURBCURVE2D->nb_removeControlHullPnt(i);
    }

    inline void removeKnot(int i)  {
        PFNURBCURVE2D->nb_removeKnot(i);
    }

    inline void evalPt(pfReal t, pfRVec2 &pnt)  {
        PFNURBCURVE2D->nb_evalPt(t, pnt);
    }

    inline void evalBreakPoints(pfParaSurface *sur)  {
        PFNURBCURVE2D->nb_evalBreakPoints(sur);
    }

    inline void setControlHull(int i,const pfRVec2 &p)  {
        PFNURBCURVE2D->nb_setControlHull(i, p);
    }
public:
  //CAPI:basename NurbCurve2d
  //CAPI:updatable
  //CAPI:newargs
  pfNurbCurve2d();
  //CAPI:verb NewNurbCurve2dWithArgs
  pfNurbCurve2d(pfReal tBegin,pfReal tEnd);
  virtual ~pfNurbCurve2d();

protected:
   pfNurbCurve2d(pfBuffer* buf);
   pfNurbCurve2d(const pfNurbCurve2d* prev, pfBuffer* buf);
public:
   // per class functions
   static pfType* getClassType() { return classType; }
   static void init();

public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);

PFINTERNAL:     // class specific sets and gets
public: // Accessor functions

  void nb_setControlHull(int i,const pfRVec3 &p);
  void nb_setWeight(int i,pfReal w);
  void nb_setKnot(int i,pfReal t);
  void nb_setControlHullSize(int s);
  pfRVec2* nb_getControlHull(int i) { return &controlHull[i]; }
  pfReal nb_getWeight(int i) { return weight[i]; }
  int nb_getControlHullSize() { return controlHull.getLen(); }
  int nb_getKnotCount() { return knot.getLen(); }
  pfReal nb_getKnot(int i) { return knot[i]; }
  int nb_getOrder() { return order; }
  void nb_removeControlHullPnt(int i);
  void nb_removeKnot(int i);

  // Evaluator
  //CAPI:virtual
  virtual void nb_evalPt(pfReal t, pfRVec2 &pnt);

  // Internal functions for topology building -- treated as private
  //CAPI:private 
  virtual void nb_evalBreakPoints(pfParaSurface *sur);

  // Internal functions for debugging purpose -- treated as private
  void pf_print();
  void pf_correctDecreasingKnots();
  void pf_reverse();

  //CAPI:public
  //CAPI:verb NurbCurve2dControlHull2
  void nb_setControlHull(int i,const pfRVec2 &p);


protected:
  void updateParameters();
 
private:
  void setBoxBound(const pfBox &newBox);

  //  -- sample points are used internally
  pfDVector<pfRVec2>    controlHull;
  pfDVector<pfReal> knot;
  pfDVector<pfReal> weight;
  int                     order;

private:
   static pfType *classType;
};

#endif
