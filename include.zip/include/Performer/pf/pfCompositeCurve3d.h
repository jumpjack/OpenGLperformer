 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.10 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfCompositeCurve3d_h_
#define _pfCompositeCurve3d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfCurve2d.h>
#include <Performer/pf/pfCurve3d.h>

// Composite curve is the trim curve in three space.  It is a
// composite of the 2D curve evaluated "continuously" on the
// surface.

#define PFCOMPOSITECURVE3D ((pfCompositeCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCOMPOSITECURVE3DBUFFER ((pfCompositeCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCompositeCurve3d : public pfCurve3d
{
public:

    inline void set(pfParaSurface *sur,pfCurve2d *cur)  {
        PFCOMPOSITECURVE3D->nb_set(sur, cur);
    }

    inline pfParaSurface* getParaSurface() const  {
        return PFCOMPOSITECURVE3D->nb_getParaSurface();
    }

    inline pfCurve2d* getCurve2d() const  {
        return PFCOMPOSITECURVE3D->nb_getCurve2d();
    }

    inline void evalPt(pfReal t,pfRVec3 &pnt)  {
        PFCOMPOSITECURVE3D->nb_evalPt(t, pnt);
    }
public:
   //CAPI:basename CompCurve3d
   //CAPI:updatable
   //CAPI:newargs
   pfCompositeCurve3d();
   //CAPI:verb NewCompositeCurve3dWithArgs
   pfCompositeCurve3d(pfParaSurface *sur,pfCurve2d *cur);
   virtual ~pfCompositeCurve3d( );

protected:
   pfCompositeCurve3d(pfBuffer* buf);
   pfCompositeCurve3d(const pfCompositeCurve3d* prev, pfBuffer* buf);

public:
   // per class functions
   static void init();
   static pfType* getClassType() { return classType; }

public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);


public:
   void nb_set(pfParaSurface *sur,pfCurve2d *cur);
   pfParaSurface* nb_getParaSurface() const {return s;}
   pfCurve2d* nb_getCurve2d() const {return c;}
   void nb_evalPt(pfReal t,pfRVec3 &pnt);

protected:
   pfParaSurface *s;
   pfCurve2d     *c;

private:
   static pfType*      classType;
};
#endif
