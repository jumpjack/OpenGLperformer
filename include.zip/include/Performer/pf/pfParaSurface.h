 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################




#ifndef _pfParaSurface_h_
#define _pfParaSurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfLinMath.h>
#include <Performer/pf/pfRep.h>
#include <Performer/pf/pfEdge.h>
#include <Performer/pr/pfGeoState.h>

#ifdef WIN32
#ifdef __BUILDPF__// for forward class declarations of pfCurve2d on _WIN32
#include <pfCurve2d.h>
#else
#include <Performer/pf/pfCurve2d.h>
#endif
#endif

class pfDisCurve2d;
class pfDisCurve3d;
class pfTopo;

#define PFPARASURFACE ((pfParaSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFPARASURFACEBUFFER ((pfParaSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfParaSurface : public pfRep
{
public:

    inline void setBeginU( pfReal u)  {
        PFPARASURFACE->nb_setBeginU(u);
    }

    inline void setEndU(   pfReal u)  {
        PFPARASURFACE->nb_setEndU(u);
    }

    inline void setBeginV( pfReal v)  {
        PFPARASURFACE->nb_setBeginV(v);
    }

    inline void setEndV(   pfReal v)  {
        PFPARASURFACE->nb_setEndV(v);
    }

    inline void setSolidId( int solidId)  {
        PFPARASURFACE->nb_setSolidId(solidId);
    }

    inline void setTopoId( int topoId)  {
        PFPARASURFACE->nb_setTopoId(topoId);
    }

    inline void setSurfaceId( int surfaceId)  {
        PFPARASURFACE->nb_setSurfaceId(surfaceId);
    }

    inline pfReal getBeginU() const  {
        return PFPARASURFACE->nb_getBeginU();
    }

    inline pfReal getEndU() const  {
        return PFPARASURFACE->nb_getEndU();
    }

    inline pfReal getBeginV() const  {
        return PFPARASURFACE->nb_getBeginV();
    }

    inline pfReal getEndV() const  {
        return PFPARASURFACE->nb_getEndV();
    }

    inline int getTrimLoopCount()  {
        return PFPARASURFACE->nb_getTrimLoopCount();
    }

    inline pfLoop getTrimLoopClosed(int loopNum)  {
        return PFPARASURFACE->nb_getTrimLoopClosed(loopNum);
    }

    inline int getTrimCurveCount(int loopNum)  {
        return PFPARASURFACE->nb_getTrimCurveCount(loopNum);
    }

    inline pfEdge* getTrimCurve(      int loopNum, int curveNum)  {
        return PFPARASURFACE->nb_getTrimCurve(loopNum, curveNum);
    }

    inline pfTopo* getTopo()  {
        return PFPARASURFACE->nb_getTopo();
    }

    inline int getTopoId()  {
        return PFPARASURFACE->nb_getTopoId();
    }

    inline int getSolidId() const  {
        return PFPARASURFACE->nb_getSolidId();
    }

    inline int getSurfaceId()  {
        return PFPARASURFACE->nb_getSurfaceId();
    }

    inline void setHandednessHint(pfBool _clockWise)  {
        PFPARASURFACE->nb_setHandednessHint(_clockWise);
    }

    inline pfBool getHandednessHint() const  {
        return PFPARASURFACE->nb_getHandednessHint();
    }

    inline void insertTrimCurve( int loopNum, pfCurve2d *c, pfDisCurve2d *d)  {
        PFPARASURFACE->nb_insertTrimCurve(loopNum, c, d);
    }

    inline void addTrimCurve(       int loopNum, pfCurve2d *c, pfDisCurve2d *d)  {
        PFPARASURFACE->nb_addTrimCurve(loopNum, c, d);
    }

    inline void setTrimLoopClosed(  int loopNum, pfLoop closed)  {
        PFPARASURFACE->nb_setTrimLoopClosed(loopNum, closed);
    }

    inline void evalPt(   pfReal u, pfReal v, pfRVec3 &pnt)  {
        PFPARASURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalDu(   pfReal u, pfReal v, pfRVec3 &Du)  {
        PFPARASURFACE->nb_evalDu(u, v, Du);
    }

    inline void evalDv(   pfReal u, pfReal v, pfRVec3 &Dv)  {
        PFPARASURFACE->nb_evalDv(u, v, Dv);
    }

    inline void evalDuu(  pfReal u, pfReal v, pfRVec3 &Duu)  {
        PFPARASURFACE->nb_evalDuu(u, v, Duu);
    }

    inline void evalDvv(  pfReal u, pfReal v, pfRVec3 &Dvv)  {
        PFPARASURFACE->nb_evalDvv(u, v, Dvv);
    }

    inline void evalDuv(  pfReal u, pfReal v, pfRVec3 &Duv)  {
        PFPARASURFACE->nb_evalDuv(u, v, Duv);
    }

    inline void evalNorm( pfReal u, pfReal v, pfRVec3 &norm)  {
        PFPARASURFACE->nb_evalNorm(u, v, norm);
    }

    inline void evalD(    pfReal u, pfReal v, pfReal theta, pfRVec3 &D)  {
        PFPARASURFACE->nb_evalD(u, v, theta, D);
    }

    inline void evalDD(   pfReal u, pfReal v, pfReal theta, pfRVec3 &DD)  {
        PFPARASURFACE->nb_evalDD(u, v, theta, DD);
    }

    inline int setGState(pfGeoState *gState)  {
        return PFPARASURFACE->nb_setGState(gState);
    }

    inline pfGeoState* getGState() const  {
        return PFPARASURFACE->nb_getGState();
    }

    inline void clearTessellation()  {
        PFPARASURFACE->nb_clearTessellation();
    }
  //CAPI:basename ParaSurface
  //CAPI:updatable
  //CAPI:newargs
 protected:
   pfParaSurface( pfReal beginU = 0, pfReal endU = 1, 
		  pfReal beginV = 0, pfReal endV = 1,
		  int    topoId = 0, int    solid_id = -1 );
 public:

   virtual ~pfParaSurface();

   void nb_setBeginU( pfReal u);
   void nb_setEndU(   pfReal u);
   void nb_setBeginV( pfReal v);
   void nb_setEndV(   pfReal v);
   void     nb_setSolidId( int solidId);
   void     nb_setTopoId( int topoId);
   void    nb_setSurfaceId( int surfaceId);
   
   // inline XXX Alex
   pfReal nb_getBeginU() const { return beginU; }
   //inline XXX Alex
   pfReal nb_getEndU() const { return endU; }
   //inline XXX Alex
   pfReal nb_getBeginV() const { return beginV; }
   //inline XXX Alex
   pfReal nb_getEndV() const { return endV; }
   int     nb_getTrimLoopCount(); // returns the # of trim loops

   // returns the closedness (PFLOOP_OPEN, PFLOOP_CLOSED, PFLOOP_PERIODIC,
   // PFLOOP_UNRESOLVED) of the loop.
   pfLoop  nb_getTrimLoopClosed(int loopNum);

   // returns the # of trim curves of the loop.
   int     nb_getTrimCurveCount(int loopNum); 

   // returns the trim curve indexed by loopNum and curveNum
   pfEdge* nb_getTrimCurve(      int loopNum, int curveNum);
   pfTopo *nb_getTopo(); // returns the topology of the surface
   int     nb_getTopoId(); // returns the topoId
   int     nb_getSolidId() const {return solidId;} // returns the solidId
   int     nb_getSurfaceId(); // returns the surfaceId
  
   // sets a handedness hint about the surface. 
   // False means counter-clockwise (right-handed)
   //inline  XXX Alex
   void nb_setHandednessHint(pfBool _clockWise) { clockWise = _clockWise; }
     
   // returns true if clockwise, false otherwise
   // inline XXX Alex
   pfBool nb_getHandednessHint() const { return clockWise; }
  
   void nb_insertTrimCurve( int loopNum, pfCurve2d *c, pfDisCurve2d *d);
   //  Takes an input trim curve as specified by (c, d), 
   //  and linearly searches all the 
   //  trim curves in the loop (specified by loopNum) 
   //  to find any existing trim curve whose end point
   //  matches one or both the input curve's end point.
     
   //  If no matches are found, it is appended to at the end of the loop.
  
  // Explicit add a trim curve to a trim loop
   void nb_addTrimCurve(       int loopNum, pfCurve2d *c, pfDisCurve2d *d);
   //  Takes an input trim curve as specified by (c, d),
   //  and stick it to the end of the trim loop as indexed by loopNum.
   //  It is an error if the loop is already closed before adding this curve.

   // Set trimLoopClosed[loopNum] to be closed.
   void nb_setTrimLoopClosed(  int loopNum, pfLoop closed);

   //CAPI:virtual
   virtual void nb_evalPt(   pfReal u, pfReal v, pfRVec3 &pnt) = 0;

   //CAPI:virtual
   virtual void nb_evalDu(   pfReal u, pfReal v, pfRVec3 &Du);
  
   //CAPI:virtual 
   virtual void nb_evalDv(   pfReal u, pfReal v, pfRVec3 &Dv);
     
   //CAPI:virtual
   virtual void nb_evalDuu(  pfReal u, pfReal v, pfRVec3 &Duu);

   //CAPI:virtual
   virtual void nb_evalDvv(  pfReal u, pfReal v, pfRVec3 &Dvv);

   //CAPI:virtual
   virtual void nb_evalDuv(  pfReal u, pfReal v, pfRVec3 &Duv);

   //CAPI:virtual
   virtual void nb_evalNorm( pfReal u, pfReal v, pfRVec3 &norm);
  
   // Directional derivative evaluators

   //CAPI:virtual
   virtual void nb_evalD(    pfReal u, pfReal v, pfReal theta, pfRVec3 &D);
     
   //CAPI:virtual
   virtual void nb_evalDD(   pfReal u, pfReal v, pfReal theta, pfRVec3 &DD);
  
   //CAPI:virtual
   //CAPI:private
   virtual void nb_eval( pfReal u, pfReal v,
		      pfRVec3 &p,            // The point
		      pfRVec3 &Du,           // The derivative in the u direction
		      pfRVec3 &Dv,           // The derivative in the v direction
		      pfRVec3 &Duu,          // The 2nd derivative in the u direction
		      pfRVec3 &Dvv,          // The 2nd derivative in the v direction
		      pfRVec3 &Duv,          // The cross derivative
		      pfReal &s,            // Texture coordinates
		      pfReal &t);

  //CAPI:public
  int nb_setGState(pfGeoState *gState);
  pfGeoState* nb_getGState() const;

       
   void nb_clearTessellation();
   //  Removes all the data resulted from previous tessellation. This
   //  allows this surface to be retessellated with a different tolerance.
   //  For each trim curve, the disCurve is deleted if the contCurve is not NULL.
   //  The xyzBoundary in its boundary structure (pfBoundary) is deleted.
   //  Also the tessellated triangles (pfGeoSets) are removed.
   
   int pf_splitTrimCurve(int loopNum, int curveNum, pfReal t,  
		       pfDisCurve3d* &xyz,
		       pfEdge* &newEdge1, pfEdge*  &newEdge2,
		       pfDisCurve3d*& newxyz1, pfDisCurve3d*& newxyz2);
#if 0  /* ZZZ Alex -- messes up our hfile preprocessor */
   /* 

     Splits a trim curve (indexed by loopNum, curveNum) 
     into at most two trim curves, and accordingly update 
     the trim curve array (Replacing the original trim curve by two new
     trim curves). The address of these new trim curves are returned.
     newEdge1 is the sub section in [beginT, t], and 
     newEdge2 is the sub section in [t, endT].
     newEdge1 is NULL is t <= beginT. 
     newEdge2 is NULL is t >= endT.

     If xyz is not NULL, it should be the 3D discrete curve of this trim curve
     and it is split into two 3D discrete curves accordingly. The two resulting
     3D discrete curves are stored in newxyz1 and newxyz2.
     If xyz is NULL, both newxyz1 and newxyz2 are set to NULL. 
     if xyz is unref()ed in this subroutine, its value is set to NULL.
     So the whoever calls this function should check xyz and sets the
     proper variable to NULL to no longer use xyz. 
     
     The continuous curve of this origial trim curve is split into two
     by making two copies of this curve and resetting the beginT and endT.
     The 2D discrete curve, if exists, is also split accordingly.

     It returns 1 if the trim curve is splitted, otherwise 0.
     
     */
#endif

    void pf_cloneTrimCurve(); // Clone the trimCurve to shadowTrimCurve
/* XXX Alex -- this should be internal but is used by pfdTessellate.c */
    void copyBackShadowTrimCurve(); // copy shadowTrimCurve to trimCurve


   void pf_connAdjTrimCurves();
   //  Two ajacent trim curves may have different
   //  end points in xyzBoundary due to topology building.
   //  This program forces them to be the same by using the
   //  the end points of those trim curves, which ovelap with
   //  some previously loaded trim curves, to replace all the
   //  end points of their neightboring trim curves.
  
   void pf_createUVboundaries();
   //  Creates a trim loop which is the boundary of the
   //  domain rectange [beginU, endU] X [beginV, endV].
  
   void pf_partitionTrimCurves();
   //  Partitions a 'long' trim curve into some number of 'shorter'
   //  trim curves. The purpose is to make it easier (faster and more robust)
   //  to determine whether a point is on a curve or not (in 3D) (this operation
   //  is used for topology construction). If a trim curve is too long it is 
   //  partitioned into some number of sub sections so that each sub section 
   //  is smoother. Current implementation only partitions order=2 
   //  (piecewise linear) nurb curves which is itself closed. 

   //  A piecewise linear NURB curve is partitioned along those vertices where
   //  the angles between the two adjacent line segments are smaller than 110 
   //  degree.                
  
   void pf_checkIfClosed(int loopNum);
   //  Use internally only. The algorithm no longer checks closeness after
   //  adding one trim curve to avoid short cutting the trim loop. So 
   //  checkIfClosed() is called inside getTrimLoopClosed(). It can only
   //  be called once when the closeness status is opUnresolved.

   void pf_printTrimCurves(); // for dbg purposes only. Prints out the members.
   
   void pf_print();
 
private:    
   pfRVec3* pf_getEndXYZ(pfEdge *e);
   pfRVec3* pf_getBeginXYZ(pfEdge *e);
   void pf_setEndXYZ(pfEdge *e, const pfRVec3& p);
   void pf_setBeginXYZ(pfEdge *e, const pfRVec3& p);
   // LLL: in opTopo build, the trim curve might be splitted
   // So we use a shadow to save the original during splitting.
   pfDVector<pfDVector<pfEdge *> >  shadowTrimCurve;
   int trimCurveCloned;
  
protected:
   pfDVector<pfDVector<pfEdge *> >  trimCurve;
   // Each surface rep can have zero or more trim loops, each consisting
   // of some number of pfCurve2d trim curves.
  
   // set to true per trim loop if the loop is indeed closed
   pfDVector<pfLoop>            trimLoopClosed;
  
   // topology to which this surface belongs. See also pfTopo.
   int        topoId;
  
   // solid to which this surface belongs
   int        solidId;
  
   // index of this surface in the surface list of the topology.
   int        surfaceId;
  
   // the domain rectangle in the parametric plane.
   pfReal     beginU, endU, beginV, endV;

   // parametric delta step size used in central difference calculations.
   pfReal     du, dv;         
  
   pfBool  clockWise; // Ordering hint
  
   // Cached surface values
   pfRVec3                    lastPt; 
   pfReal                    lastU, lastV;

   // used to apply to individual geosets created when tessellating geometry 
   pfGeoState *gState;
  
   void insertAfter(  int i, int j, pfCurve2d *c, pfDisCurve2d *d );
   //  Inserts the trim curve (c, d) at the position j+1 in
   //  the i'th loop. A pfBoundary data structure is created 
   //  for this trim curve and is added into the boundary list of the topology.
   //  It is an error if the loop is already closed before the insertion.
     
   void insertBefore( int i, int j, pfCurve2d *c, pfDisCurve2d *d );
   //  Inserts the trim curve (c, d) at position j in
   //  the i'th loop. A pfBoundary data structure is created 
   //  for this trim curve and is added into the boundary list of the topology.
   //  It is an error if the loop is already closed before the insertion.

   void insertBeforeNoBoundary( int i, int j, pfCurve2d *c, pfDisCurve2d *d);
   //  The same as insertBefore except that it does not create
   //  pfBoundary data structure for this trim curve.
  
   void insertBeforeNoBoundaryClosed(int i,int j,pfCurve2d *c,pfDisCurve2d *d);
   //  The same as insertBeforeNoBoundary except that it doesn't 
   //  check the closedness of the loop. This function is used only for topology 
   //  building where it is assumed that this loop is closed but one may need to 
   //  split a trim curve into two and insert them into the closed loop.

 protected:
   pfParaSurface(pfBuffer *buf);
   pfParaSurface(const pfParaSurface* prev,pfBuffer *buf);


 public:
   static pfType *getClassType() { return classType; }
   static void init();

 PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual void nb_write(pfTraverser *trav, uint which, uint verbose);   

 PFINTERNAL:
   virtual int nb_flatten(pfTraverser* );

 private:
   static pfType *classType;
};
#endif
