 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################


// $Revision: 1.11 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfFrenetSweptSurface_H
#define _pfFrenetSweptSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfSweptSurface.h>
#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfScalar.h>

#define PFFRENETSWEPTSURFACE ((pfFrenetSweptSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFFRENETSWEPTSURFACEBUFFER ((pfFrenetSweptSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfFrenetSweptSurface : public pfSweptSurface
{
public:

    inline void set(pfCurve3d *crossSection,pfCurve3d *path,pfScalar *profile)  {
        PFFRENETSWEPTSURFACE->nb_set(crossSection, path, profile);
    }
public:
   //CAPI:basename FrenetSweptSurface
   //CAPI:updatable
   //CAPI:newargs
   pfFrenetSweptSurface();
   //CAPI:verb NewFrenetSweptSurfaceWithArgs
   pfFrenetSweptSurface(pfCurve3d *crossSection,pfCurve3d *path,pfScalar *profile);
   virtual ~pfFrenetSweptSurface();
            
   //CAPI:verb FrenetSweptSurfaceSet
   void nb_set(pfCurve3d *crossSection,pfCurve3d *path,pfScalar *profile);

protected:
   pfFrenetSweptSurface(pfBuffer *buf);
   pfFrenetSweptSurface(const pfFrenetSweptSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();


 private:
   static pfType *classType;
};
#endif
