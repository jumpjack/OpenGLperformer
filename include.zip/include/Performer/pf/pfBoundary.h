 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.10 $
// $Date : $ 

#ifndef _pfBoundary_h_
#define _pfBoundary_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfDisCurve3d.h>

class pfParaSurface;

// Boundary handedness
typedef enum
{
   pfLeftHanded,
   pfRightHanded
} pfHandedness;

class pfParaSurface;

#define PFBOUNDARY ((pfBoundary*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFBOUNDARYBUFFER ((pfBoundary*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfBoundary : public pfObject
{
  //CAPI:basename Boundary
public:
   pfBoundary( );
   virtual ~pfBoundary( );
   void addEdge( int i, pfParaSurface *sur, int trimLoop, int trimCurve );
   int getSurface( int i ) const;
   void setSurface( int i, int surfaceId);
   int getLoop( int i ) const;
   void setLoop( int i, int loopNum );
   void setTrimCurve( int i , int curveNum);
   int getTrimCurve(int i) const;
  int getWingCount() const;
  int getBoundaryId() const;
  void setBoundaryId( int boundaryId );

  static void init();
  static pfType *getClassType() { return classType; }

  virtual int copy(const pfMemory *src);

  void pf_print();


protected:
   // Winged data structure
   typedef struct 
   {
      int surface;    // Surface index into the surface list
      int trimLoop;   // Trim loop index
      int trimCurve;  // Trim curve index with the trim loop
   } boundary;
  
   // A list of wings is a triplet of the surface, the trim loop, 
   // and the trim curve.
   pfDVector<boundary> wing;

   // The discrete representation of boundary.
   pfDisCurve3d     *xyzBoundary;

   // The index of this boundary in the topology boundary list.
   int              boundaryId;

 private:
   static pfType *classType;
};
#endif
