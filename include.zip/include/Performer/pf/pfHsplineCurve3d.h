 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.22
// $Date: 1996/11/03 02:51:09

#ifndef _pfHsplineCurve3d_H
#define _pfHsplineCurve3d_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfDVector.h>

#define PFHSPLINECURVE3D ((pfHsplineCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFHSPLINECURVE3DBUFFER ((pfHsplineCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfHsplineCurve3d : public pfCurve3d
{
public:

    inline int getKnotCount() const  {
        return PFHSPLINECURVE3D->nb_getKnotCount();
    }

    inline void setPoint(int i,const pfRVec3 &p)  {
        PFHSPLINECURVE3D->nb_setPoint(i, p);
    }

    inline void setTangent(int i,const pfRVec3 &tng)  {
        PFHSPLINECURVE3D->nb_setTangent(i, tng);
    }

    inline void setKnot(int i,pfReal t)  {
        PFHSPLINECURVE3D->nb_setKnot(i, t);
    }

    inline pfRVec3* getPoint(int i)  {
        return PFHSPLINECURVE3D->nb_getPoint(i);
    }

    inline pfRVec3* getTangent(int i)  {
        return PFHSPLINECURVE3D->nb_getTangent(i);
    }

    inline pfReal getKnot(int i)  {
        return PFHSPLINECURVE3D->nb_getKnot(i);
    }
public:
  //CAPI:basename HsplineCurve3d
  //CAPI:updatable
  //CAPI:newargs
  pfHsplineCurve3d();
  virtual ~pfHsplineCurve3d( );

protected:
   pfHsplineCurve3d(pfBuffer *buf);
   pfHsplineCurve3d(const pfHsplineCurve3d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:
   int nb_getKnotCount() const {return knot.len;}
   void nb_setPoint(int i,const pfRVec3 &p);
   void nb_setTangent(int i,const pfRVec3 &tng);
   void nb_setKnot(int i,pfReal t);
   pfRVec3* nb_getPoint(int i) { return &p[i]; }
   pfRVec3* nb_getTangent(int i) { return &t[i]; }
   pfReal  nb_getKnot(int i) { return knot[i]; }
   virtual void nb_evalPt(pfReal t,pfRVec3 &pnt);

private:
   pfDVector<pfRVec3>  p; // The points of the curve at the knot values
   pfDVector<pfRVec3>  t; // The tangents of the curve at the knot values
   pfDVector<pfReal>  knot; // Knot values


private:
  static pfType* classType;
};

#endif
