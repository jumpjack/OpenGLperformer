//
//
// Copyright 1995, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfFCS.h		Flux Coordinate Systems include file
//
// $Revision: 1.10 $
// $Date: 2004/06/14 17:23:33 $
//

#ifndef __PF_FCS_H__
#define __PF_FCS_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfSCS.h>
#include <Performer/pr/pfFlux.h>


class pfBuffer;

extern "C" {     // EXPORT to CAPI

/* ----------------------- pfFCS Tokens ----------------------- */

#define PFFCS_MATRIX_TYPE	1
#define PFFCS_UNCONSTRAINED	0xffffffff
} // extern "C" END of C include export


#define PFFCS ((pfFCS*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFFCSBUFFER ((pfFCS*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfFCS : public pfSCS
{
public:

    inline void getMat(pfMatrix& m)  {
        PFFCS->nb_getMat(m);
    }

    inline const pfMatrix* getMatPtr()  {
        return PFFCS->nb_getMatPtr();
    }

    inline void setMatType(uint val)  {
        PFFCS->nb_setMatType(val);
    }

    inline uint getMatType() const  {
        return PFFCS->nb_getMatType();
    }

    inline void setFlux(pfFlux *_flux)  {
        PFFCS->nb_setFlux(_flux);
    }

    inline pfFlux* getFlux()  {
        return PFFCS->nb_getFlux();
    }
public:		// Constructors/Destructors
    //CAPI:updatable
    //CAPI:newargs
    pfFCS(pfFlux *_flux);
    virtual ~pfFCS();

protected:
    pfFCS(pfBuffer *buf, pfFlux *_flux);
    pfFCS(const pfFCS *prev, pfBuffer *buf);

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }

public:		// pfMemory virtual functions

PFINTERNAL:		// pfUpdatable virtual functions
    virtual void	    pf_applyUpdate(const pfUpdatable *prev, int upId);
    virtual pfUpdatable*    pf_bufferClone(pfBuffer *buf);

PFINTERNAL:		// pfNode virtual traversals
    virtual void	nb_clean(uint64_t cleanBits, pfNodeCounts *counts);
    virtual pfNode*	nb_clone();
    virtual int		nb_cull(int mode, int cullResult, _pfCuller *trav);
    virtual int		nb_cullProgram(int mode, int cullResult, _pfCullPgInfo *cullPgInfo, _pfCuller *trav);
    virtual int 	nb_flatten(pfTraverser *trav);
    virtual int 	nb_intersect(_pfIsector *isector);
    virtual void 	nb_write(pfTraverser *trav, uint which, uint verbose);

PFINTERNAL:		// pfSCS virtual traversals
    //CAPI:virtual
    virtual void 	    nb_getMat(pfMatrix& m);
    virtual const pfMatrix* nb_getMatPtr();

PFINTERNAL:		// class specific sets and gets
    //CAPI:backdoor
    void	nb_setMatType(uint val);
    uint 	nb_getMatType() const;

    void	nb_setFlux(pfFlux *_flux);
    pfFlux*	nb_getFlux(void);


protected:
    int 	fcsFlags;
    uint 	matType;
    pfSphere	childBSphere;
    pfMatrix	xformInv;
    pfFlux	*flux;

private:
    static pfType *classType;
};

#endif // !__PF_FCS_H__
