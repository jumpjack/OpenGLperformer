 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################




#ifndef _pfSubdivSurface_h_
#define _pfSubdivSurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfRep.h>
#include <Performer/pf/pfMesh.h>

/* Export to C API. */
extern "C" {
#define PFSB_MAX_SUBDIVISION_LEVEL 5

/* value identifiers (used in setVal/getVal) */
#define PFSB_SUBDIVISION_METHOD    0
#define PFSB_SUBDIVISION_LEVEL     1
#define PFSB_MAX_DATA_HEIGHT_SW    2
#define PFSB_MAX_PBUFFER_HEIGHT    3
#define PFSB_PBUFFER_WIDTH         4

/* values */
#define PFSB_CATMULL_CLARK         0
#define PFSB_LOOP                  1

/* flags */
#define PFSB_GPU_SUBDIVISION            (1<<0)                 
#define PFSB_CONTROL_VERTICES_DYNAMIC   (1<<1)
#define PFSB_USE_GEO_ARRAYS             (1<<2) /* in case of sw subdivision */
#define PFSB_INDEXED_GEOARRAYS          (1<<3) /* geoarrays are indexed (default */
#define PFSB_FLIP_NORMALS               (1<<4) /* in case of a negative scale matrix above the node */
#define PFSB_SUBDIVIDE_TEXCOORDS        (1<<5) /* do not interpolate texcoords,
						  but use subdivision rules
						  for them */
#define PFSB_TEXCOORDS_KEEP_BOUNDARY    (1<<6) /* when using subdivision rules
						  for texcoords, keep original
						  texcords along boundaries
						  (may look skewed, but 
						  textures do not look cut) */
}

/* data we need to store on display list for GPU drawing, otherwise we would
   have to flux these parameters */
typedef struct _pfSubdivSurfDrawData 
{
    unsigned short  subdivLevel;
    unsigned short  method;
    unsigned int    numVerts, numFaces;
} pfSubdivSurfDrawData;

/* vertex data needed to update the texture containg surface paramaters */
typedef struct _pfSubdivSurfVertexData 
{
    float           *data;
    unsigned int    dataHeight, dataWidth;  /* input data size */
    //unsigned short  minFace, maxFace;   /* subload range */
    //unsigned short  minVert, maxVert;   /* subload range */
} pfSubdivSurfVertexData;

struct pfSubdivSurfPipeData;
    
#define MAX_PROGRAMS_PARAMS 20

typedef struct phaseType
{
    char *string;
    float params[MAX_PROGRAMS_PARAMS][4];
    int   numParams;
    GLuint pgmName[2];
} pfSubdivSurfacePhaseType;

typedef struct faceVert
{
    int face, vertex;
} _pfFaceVertex;

typedef struct faceVert2
{
    int face, vertex;
    unsigned short verts[4]; // verticesof a given face
} _pfFaceVertex2;

#define PFSUBDIVSURFACE ((pfSubdivSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSUBDIVSURFACEBUFFER ((pfSubdivSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfSubdivSurface : public pfRep
{
public:

    inline void setFlags(int which, int value)  {
        PFSUBDIVSURFACE->nb_setFlags(which, value);
    }

    inline int getFlags(int which)  {
        return PFSUBDIVSURFACE->nb_getFlags(which);
    }

    inline void setMesh(pfMesh *mesh)  {
        PFSUBDIVSURFACE->nb_setMesh(mesh);
    }

    inline pfMesh* getMesh()  {
        return PFSUBDIVSURFACE->nb_getMesh();
    }

    inline void updateControlMesh()  {
        PFSUBDIVSURFACE->nb_updateControlMesh();
    }
    //CAPI:basename SubdivSurface
    //CAPI:updatable
    //CAPI:newargs

    /* <summary> A subdivision surface surface</summary>
       <description>
      
       </description> */
public:

    pfSubdivSurface();

    virtual ~pfSubdivSurface();

    void nb_setFlags(int which, int value);
    int  nb_getFlags(int which);

    void setVal(int which, float  val);
    void getVal(int which, float *val);
    
    void nb_setMesh(pfMesh *mesh);
    pfMesh *nb_getMesh(void) { return mesh; }

    void nb_updateControlMesh(void); /* called from app, only vertices 
					can change*/

  
 protected:
    pfMesh    *mesh;   /* stores the control mesh */
    int       flags;

    pfSubdivSurfDrawData   drawParam;
    pfSubdivSurfVertexData vertexParam;
    float     levelRange[PFSB_MAX_SUBDIVISION_LEVEL];

    /* internal */
    pfMesh    *meshStep1; /* used in case first step of Catmull-Clark 
			     subdivision is done in sw */
    
    /* Pbuffers and stuff (pointer to a structure not visible to the user?) */
    float     *data[2];
    int       current;    /* which of data[0] and data[1] contain vertices */
    int       texHeight, texWidth;  /* texture size (used in sw version) */
    int       PbufferHeight, PbufferWidth;  /* P-buffer size */
    int       SbufferHeight, SbufferWidth;  /* S-buffer size */
    float     invTexHeight, invTexWidth;  /* 1.0 / Pbuffer/texture size */
    int       maxPbufferHeight, maxTexHeight;

    _pfFaceVertex2 *texGroups;    /* of size numGroups*texHeight */
    _pfFaceVertex *numInGroup;   /* of size numGroups */
    int       numTexGroups;
    int       *verticesInGroup;  /* location of each vertex in the current 
				     group */
    int       gsetindex;
    pfGeoState *lastGstate;

    int       maxValence;
    
    unsigned short  vertexWidth; /* size and start of data fields */
    unsigned short  triWidthOut, triWidthIn, triStart;
    unsigned short  paramWidth, paramStart;
    unsigned short  nparamWidth, nparamStart;
    unsigned short  linksWidth, linksStart;

    pfTexture *inputTex;         //XXX later remove
    unsigned int inputTexName; 
    unsigned int LoopIndicesTexName;

    float    texT, maxt, maxtexT;
    float    invDataHeight, invDataWidth; 
    int      numLayers;
    int      firstHWstep, subdivType; // used by draw only
    int      numVerts, numFaces;      // used by draw only
    pfSubdivSurfPipeData *pipeData;
    void     *extraData;              // for future binary compatibility

 public:
    static int PbufTexName[2];  /* two textures for Pbuffers - common for
				   all classes */

 public:
   static pfType *getClassType() { return classType; }
   static void init();

 PFINTERNAL:	/* pfGeoSet virtual functions */
    virtual int 	    nb_addGSet(pfGeoSet *gset);
    virtual int 	    nb_insertGSet(int index, pfGeoSet *gset);
    virtual int 	    nb_replaceGSet(pfGeoSet *oldgs, pfGeoSet *newgs);
    virtual int 	    nb_removeGSet(pfGeoSet *gset);
    virtual int             nb_countShadedGSets() {return 0;}

PFINTERNAL:
    virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
    virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);
    
    
 PFINTERNAL:
    virtual pfNode *nb_clone();
    virtual void nb_clean(uint64_t cleanBits, pfNodeCounts *counts);
    virtual int 	nb_cull(int mode, int cullResult, _pfCuller *trav);
    virtual int 	nb_cullProgram(int mode, int cullResult, _pfCullPgInfo *cullPgInfo, _pfCuller *trav);
    virtual int nb_flatten(pfTraverser* trav);
    
    void draw(void);
    void pr_draw(pfDispList *dl, pfGeomStats *gstats);


 private:
   static pfType *classType;
};
#endif
