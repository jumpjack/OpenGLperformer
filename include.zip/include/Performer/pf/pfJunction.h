 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################

// $Revision: 1.11 $
// $Date: 2005/05/13 01:09:00 $

#ifndef _pfJunction_h_
#define _pfJunction_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfLinMath.h>
#include <Performer/pf/pfDVector.h>

// End point indentifier
#define PFEND_POINT_BEGIN 0
#define PFEND_POINT_END   1

class pfParaSurface;

#define PFJUNCTION ((pfJunction*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFJUNCTIONBUFFER ((pfJunction*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfJunction : public pfObject
{
  //CAPI:basename Junction
public:
   pfJunction( );
   virtual ~pfJunction( );

   static void init();
   static pfType* getClassType() { return classType; }

   //  Adds a new spoke to the junction.
   //   surface : Surface index to the surface list
   //   trimLoop :   Trim loop index to <arg surface>
   //   trimCurve :  Trim curve index with the trim loop
   //   which :      Which end (PFEND_POINT_BEGIN or PFEND_POINT_END) 
   //                      of the curve is the junction
   void addEndPt( int i, pfParaSurface *sur,  int trimLoop, int trimCurve,int which );

   // Returns the number of surfaces that meet at this junction.
   int getSpokeCount();
    
   // Returns information associated with the i'th spoke.
   int getSurface( int i );

   // Returns the loop number of i'th spoke.
   int getLoop( int i );

   // Gets the trim curve number of the i'th spoke.
   int getTrimCurve( int i );

   // Gets the information on which end point of the i'th spoke.
   // Will be either PFEND_POINT_BEGIN or PFEND_POINT_END
   int getWhichEndPt( int i );

   //CAPI:private

protected:
   typedef struct
   {
      int      surface;    // Surface index into the surface list
      int      trimLoop;   // Trim loop index
      int      trimCurve;  // Trim curve index with the trim loop
      int      which;      // Which end of the curve is the junction:
                           // PFEND_POINT_BEGIN or PFEND_POINT_END
   } junction;

   // List of boundaries meeting at this junction, i.e. the spokes.
   pfDVector<junction> spoke;

   // The discrete point representing this junction.
   pfRVec3  *xyzJunction;

   // The index of this junction in the topology junction list.
   int             junctionId;

 private:
   static pfType* classType;
};
#endif

