 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.8 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfTorusSurface_H
#define _pfTorusSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>

#define PFTORUSSURFACE ((pfTorusSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFTORUSSURFACEBUFFER ((pfTorusSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfTorusSurface : public pfParaSurface
{
public:

    inline void setMajorRadius(pfReal majorRadiusVal)  {
        PFTORUSSURFACE->nb_setMajorRadius(majorRadiusVal);
    }

    inline void setMinorRadius(pfReal minorRadiusVal)  {
        PFTORUSSURFACE->nb_setMinorRadius(minorRadiusVal);
    }

    inline pfReal getMajorRadius( ) const  {
        return PFTORUSSURFACE->nb_getMajorRadius();
    }

    inline pfReal getMinorRadius( ) const  {
        return PFTORUSSURFACE->nb_getMinorRadius();
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFTORUSSURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalNorm(pfReal u,pfReal v,pfRVec3 &norm)  {
        PFTORUSSURFACE->nb_evalNorm(u, v, norm);
    }

    inline pfNode* clone()  {
        return PFTORUSSURFACE->nb_clone();
    }
public:
  //CAPI:basename TorusSurface
  //CAPI:updatable
  //CAPI:newargs
  pfTorusSurface();
  //CAPI:verb NewTorusSurfaceWithArgs
  pfTorusSurface(pfReal majorRadius,pfReal minorRadius);

protected:
   pfTorusSurface(pfBuffer *buf);
   pfTorusSurface(const pfTorusSurface* prev,pfBuffer *buf);
public:
   virtual ~pfTorusSurface();

   static pfType *getClassType() { return classType; }
   static void init();
      
   virtual int compare(const pfMemory *_mem) const;

   void nb_setMajorRadius(pfReal majorRadiusVal) { majorRadius = majorRadiusVal; }

   void nb_setMinorRadius(pfReal minorRadiusVal) { minorRadius = minorRadiusVal; }

   pfReal nb_getMajorRadius( ) const { return majorRadius; }
   pfReal nb_getMinorRadius( ) const { return minorRadius; }
   //CAPI:virtual
   virtual void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
   //CAPI:virtual
   virtual void nb_evalNorm(pfReal u,pfReal v,pfRVec3 &norm);
PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);
   
   virtual pfNode *nb_clone();

protected:
   pfReal   majorRadius, minorRadius;

   // Last values of sin(u) and cos(u) created by the last 
   // evalPt call.  Initially these values are undefined.

   pfReal sin_u, cos_u;
   // Last values of sin(v) and cos(v) created by the last 
   // evalPt call.  Initially these values are undefined.
   pfReal sin_v, cos_v;

private:
	static pfType *classType;
};
#endif
