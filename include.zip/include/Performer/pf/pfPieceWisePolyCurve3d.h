 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################

#ifndef _pfPieceWisePolyCurve3d_h_
#define _pfPieceWisePolyCurve3d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfDVector.h>

#define PFPIECEWISEPOLYCURVE3D ((pfPieceWisePolyCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFPIECEWISEPOLYCURVE3DBUFFER ((pfPieceWisePolyCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfPieceWisePolyCurve3d : public pfCurve3d
{
public:

    inline void setControlHull(int piece,int i,const pfRVec3& p)  {
        PFPIECEWISEPOLYCURVE3D->nb_setControlHull(piece, i, p);
    }

    inline pfRVec3 getControlHull(int piece,int i)  {
        return PFPIECEWISEPOLYCURVE3D->nb_getControlHull(piece, i);
    }

    inline void setLimitParas(int piece,pfReal w1,pfReal w2)  {
        PFPIECEWISEPOLYCURVE3D->nb_setLimitParas(piece, w1, w2);
    }

    inline void setReverse(int _reverse)  {
        PFPIECEWISEPOLYCURVE3D->nb_setReverse(_reverse);
    }

    inline pfRVec2 getLimitParas(int piece)  {
        return PFPIECEWISEPOLYCURVE3D->nb_getLimitParas(piece);
    }

    inline int getReverse() const  {
        return PFPIECEWISEPOLYCURVE3D->nb_getReverse();
    }

    inline int getPatchCount()  {
        return PFPIECEWISEPOLYCURVE3D->nb_getPatchCount();
    }

    inline int getOrder(int piece)  {
        return PFPIECEWISEPOLYCURVE3D->nb_getOrder(piece);
    }

    inline void evalPt(pfReal t,pfRVec3& pnt)  {
        PFPIECEWISEPOLYCURVE3D->nb_evalPt(t, pnt);
    }
public:
  //CAPI:basename PieceWisePolyCurve3d
  //CAPI:updatable
  //CAPI:newargs
   pfPieceWisePolyCurve3d();
   virtual ~pfPieceWisePolyCurve3d();

protected:
   pfPieceWisePolyCurve3d(pfBuffer *buf);
   pfPieceWisePolyCurve3d(const pfPieceWisePolyCurve3d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:

   void nb_setControlHull(int piece,int i,const pfRVec3& p);

   //CAPI:private
   pfRVec3& nb_getControlHull(int piece,int i);
   //CAPI:public
   void nb_setLimitParas(int piece,pfReal w1,pfReal w2);
   void nb_setReverse(int _reverse) {reverse = _reverse;}
   //CAPI:private
   pfRVec2& nb_getLimitParas(int piece) {return limitParas[piece];}
   //CAPI:public
   int nb_getReverse() const {return reverse;}
   int nb_getPatchCount();
   int nb_getOrder(int piece);
   //CAPI:virtual
   virtual void nb_evalPt(pfReal t,pfRVec3& pnt);

protected:
   // The control hull of the curve. It is indexed as [piece][i].
   // Here, i is the i'th coefficient of the piece polynomial.
   pfDVector<pfDVector<pfRVec3> >  controlHull;

   // Piece i has domain: [limitParas[i][0], [i][1]] which is a
   // subinterval of [0.0, 1.0]
   pfDVector<pfRVec2> limitParas; 

   int reverse; //1: reverse; 0 no


private:
  static pfType *classType;
};
#endif


