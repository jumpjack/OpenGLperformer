 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.9 $
// $Date: 2004/06/14 17:23:33 $


#ifndef _pfEdge_h_
#define _pfEdge_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfObject.h>
#include <Performer/pf/pfCurve2d.h>
#include <Performer/pf/pfDisCurve2d.h>
#include <Performer/pf/pfBoundary.h>

class pfCurve2d;
class pfDisCurve2d;

// Trim curve is either a discrete or continuous curve in UV space
#define PFEDGE ((pfEdge*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFEDGEBUFFER ((pfEdge*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfEdge : public pfObject
{
  //CAPI:basename Edge
public:
   pfEdge();
   virtual ~pfEdge();

   static void init();
   static pfType* getClassType() { return classType; }

   // XXX Alex -- in order to get the compare method to work
   // we need to implement compare for pfDisCurve2d and pfCurve2d.
   virtual int compare(const pfMemory *_mem) const;
   virtual int copy(const pfMemory *_src);

   pfCurve2d *getContCurve() const;
   void setContCurve(pfCurve2d *c);
   pfDisCurve2d *getDisCurve() const;
   void setDisCurve( pfDisCurve2d *d);
   int getBoundary() const;
   void setBoundary( int boundaryId);
   void setBoundaryDir( int dir );
   int getBoundaryDir() const;
   void pf_print();

protected:

protected:
   pfCurve2d     *contCurve;       //The continous curve
   pfDisCurve2d  *disCurve;        // The discrete version

   /* The index into the boundary list of the class pfTopo.
      A boundary is a shared winged XYZ boundary. */
   int            boundary;        // Shared winged XYZ boundary

   // Handedness of the boundary relative to the model, XYZ, space
   // representation of this edge and requisite boundary.
   int            boundaryDir;     //1:same (as xyzBoundary) or -1:reverse

   // The begining point of the correponding boundary.
   int            beginJunction;   // Shared end point XYZ junctions
   // The end point of the correponding boundary.
   int            endJunction;

private:
   static pfType *classType;

};
#endif
