 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.9 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfNurbCurve3d_H
#define _pfNurbCurve3d_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfDVector.h>


#define PFNURBCURVE3D ((pfNurbCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFNURBCURVE3DBUFFER ((pfNurbCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfNurbCurve3d : public pfCurve3d
{
public:

    inline void setControlHull(int i,const pfRVec3 &p)  {
        PFNURBCURVE3D->nb_setControlHull(i, p);
    }

    inline void setControlHull(int i,const pfRVec4 &p)  {
        PFNURBCURVE3D->nb_setControlHull(i, p);
    }

    inline void setWeight(int i,pfReal w)  {
        PFNURBCURVE3D->nb_setWeight(i, w);
    }

    inline void setKnot(int i,pfReal t)  {
        PFNURBCURVE3D->nb_setKnot(i, t);
    }

    inline void setControlHullSize(int s)  {
        PFNURBCURVE3D->nb_setControlHullSize(s);
    }

    inline pfRVec3* getControlHull(int i)  {
        return PFNURBCURVE3D->nb_getControlHull(i);
    }

    inline pfReal getWeight(int i)  {
        return PFNURBCURVE3D->nb_getWeight(i);
    }

    inline int getControlHullSize()  {
        return PFNURBCURVE3D->nb_getControlHullSize();
    }

    inline int getKnotCount() const  {
        return PFNURBCURVE3D->nb_getKnotCount();
    }

    inline pfReal getKnot(int i)  {
        return PFNURBCURVE3D->nb_getKnot(i);
    }

    inline pfReal getOrder() const  {
        return PFNURBCURVE3D->nb_getOrder();
    }

    inline void removeControlHullPnt(int i)  {
        PFNURBCURVE3D->nb_removeControlHullPnt(i);
    }

    inline void removeKnot(int i)  {
        PFNURBCURVE3D->nb_removeKnot(i);
    }

    inline void evalPt(pfReal u,pfRVec3 &pnt)  {
        PFNURBCURVE3D->nb_evalPt(u, pnt);
    }
public:
  //CAPI:basename NurbCurve3d
  //CAPI:updatable
  //CAPI:newargs
   pfNurbCurve3d();
  //CAPI:verb NewNurbCurve3dWithArgs
   pfNurbCurve3d(pfReal tBegin,pfReal tEnd);

   virtual ~pfNurbCurve3d();

protected:
  pfNurbCurve3d(pfBuffer *buf);
  pfNurbCurve3d(const pfNurbCurve3d* prev,pfBuffer *buf);
public:
  static pfType* getClassType() { return classType; }
  static void init();
public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);

PFINTERNAL:     // class specific sets and gets
public: // Accessor functions

   //CAPI:verb NurbCurve3dControlHull3
   void nb_setControlHull(int i,const pfRVec3 &p);
   //CAPI:verb NurbCurve3dControlHull
   void nb_setControlHull(int i,const pfRVec4 &p);
   //CAPI:verb NurbCurve3dWeight
   void nb_setWeight(int i,pfReal w);
   //CAPI:verb NurbCurve3dKnot
   void nb_setKnot(int i,pfReal t);
   //CAPI:verb NurbCurve3dControlHullSize
   void nb_setControlHullSize(int s);
   //CAPI:verb GetNurbCurve3dControlHull
   pfRVec3* nb_getControlHull(int i) { return &controlHull[i];}
   //CAPI:verb GetNurbCurve3dWeight
   pfReal nb_getWeight(int i) { return weight[i];}
   //CAPI:verb GetNurbCurve3dControlHullSize
   int nb_getControlHullSize() { return controlHull.getLen();}
   //CAPI:verb GetNurbCurve3dKnotCount
   int nb_getKnotCount() const { return knot.getLen();}
   //CAPI:verb GetNurbCurve3dKnot
   pfReal nb_getKnot(int i) { return knot[i];}
   //CAPI:verb GetNurbCurve3dOrder
   pfReal  nb_getOrder() const { return order;}
   //CAPI:verb NurbCurve3dRemoveControlHullPnt
   void nb_removeControlHullPnt(int i);
   //CAPI:verb NurbCurve3dRemoveKnot
   void nb_removeKnot(int i);
   //CAPI:verb NurbCurve3dEvalPt
   //CAPI:virtual
   virtual void nb_evalPt(pfReal u,pfRVec3 &pnt);

protected:
   void updateParameters();
   // Updates the order, beginT and endT of the curve so that they are
   // consistent with the control hull and knot data.


private:
  pfDVector<pfRVec3>  controlHull; // the control hull points
  pfDVector<pfReal>  knot;        // knot values
  pfDVector<pfReal>  weight;      // the weights for rational splines
  int              order;       // the order (degree+1) of the BSpline

private:
  static pfType *classType;
};

#endif
