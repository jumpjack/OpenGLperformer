 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.13 $
// $Date: 2005/06/22 20:36:04 $

#ifndef __PFDVECTOR_H__
#define __PFDVECTOR_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr.h>
#include <Performer/pr/pfMemory.h>
#include <Performer/pf.h>

#include <stdlib.h>
#ifdef WIN32
typedef long ssize_t;
#include <string.h>
#endif

// An unique placement operator
class DLLEXPORT pfUniqType
{
public:
    pfUniqType() {};

    int foo;
};

inline DLLEXPORT void* operator new(size_t , void *t, pfUniqType *) { return t; }


template <class DLLEXPORT T> class pfDVector
{
   /* Template class for dynamic arrays

      pfDVector is a template class for dynamically growing,
      contiguous arrays. pfDVectors syntactically and semantically
      treat an pfDVector as you would any one dimensional array in 
      C or C++.
      
      Whenever a write access is performed on a pfDVector, the
      indexing variable is checked against the current bounds for the array.
      If the index is out of bounds, the array is extended in the direction
      of the out of bounds.  The amount of growth is governed by the location of
      the index plus an extension factor which by default is 32.  A declared
      pfDVector is of size zero and has no bounds. A 
      pfDVector upon its first access will grow a region about the
      first index.
      
      pfDVectors always extend the array so that the actual data
      portion of the pfDVector is stored contiguously in memory.
      This allows an application to pass a pointer to an element in a
      pfDVector to a routine that is expecting the
      address of a template-type array.
      
      pfDVectors also maintain the maximum index ever written,
      called len.  Applications use len when 
      the sequentially fill an array at one point of execution and
      then need to read it at another.  This mechanism, in combination
      with contiguous storage,enables efficient pointer-based array traversals.

      --- Caveats --- 
      Nested dvectors do not create a single
      multidimensional array of the template argument. That is, a
      pfDVector<pfDVector< int > > is not one
      big chunk of two dimensional integer memory. Rather 
      pfDVectors, when nested, create arrays of
      pfDVectors that eventually contain one-dimensional arrays of the
      pfDVectors each of which is a list of integers.  Each dimension
      is independently dynamic and, since it is a pfDVector onto
      itself, has its own bounds and extension value.
      */

public:
   T    *data; // Data block.

   ssize_t minIndex; // Min index of the pfDVector range.
   ssize_t maxIndex; // Max index of the pfDVector range.
   ssize_t len; // Current length of the vector.
   ssize_t size; // Amount of the current extent
   ssize_t extension; // The amount over the range the vector grows by.
   pfBool doFree; // If true, delete the array upon destruction.

   typedef void* MallocFunc(size_t size);
   MallocFunc* dvectorMalloc; // Pointer to user defineable malloc function.

   typedef void FreeFunc(void* ptr);
   FreeFunc* dvectorFree; // Pointer to user defineable free function.

public:
   // Creates an instance of pfDVector. Sets the size, length 
   // and extension to zero.
   inline  pfDVector()
   {               
      data          = (T *)0;
      minIndex      = INT_MIN/2;
      maxIndex      = INT_MIN/2;
      len           = 0;
      size          = 0;
      extension     = 32;
      doFree        = 1;
      dvectorMalloc = NULL;
      dvectorFree   = NULL;
   }

   // Creates an instance of pfDVector. Sets the size and length to zero,
   // and the extension to e.
   inline  pfDVector( ssize_t e )
   {
      data       = (T *)0;
      minIndex   = INT_MIN/2;
      maxIndex   = INT_MIN/2;
      len        = 0;
      size       = 0;
      extension  = e;
      doFree     = 1;
      dvectorMalloc = NULL;
      dvectorFree   = NULL;
   }

   // Destructor. Frees the data store.
   ~pfDVector( void )
   {
      if (data && doFree)
      {
	 T *d, *e;

	 for ( d = data, e = &data[size];
	       d < e;
	       d++ )
	 {
	    d->~T();
	 }

         if(dvectorFree == NULL) dvectorFree = pfMemory::free;
	 (*dvectorFree)( data );
      }
   }

   // Sets the amount by which an array is extended beyond the faulting index e.
   inline void setExtension( ssize_t e ) { extension = e;}

   // Sets a flag that instructs the pfDVector whether or not to
   // free the pfDVector after destruction. By default this value is set to true
   inline void setDoFree(pfBool df) { doFree = df;}

   // returns the range bounds of the pfDVector. The range bounds are the
   // bounds of the array currently allocated. 
   inline void getIndexRange( ssize_t *min, ssize_t *max ) { *min = minIndex; *max = maxIndex;}

   // returns a pointer to the base of the data array.
   inline T  *getDataPtr() { return &data[-minIndex];}

   inline void setLen(ssize_t newLen) { len = newLen; }
   inline ssize_t getExtension() const { return extension; }

   // returns the maximum index written into the array. This value is
   // initialized to zero.
   inline ssize_t getLen() const { return len;}

   // returns true if this pfDVector frees memory upon destruction.
   // The default value is true.
   inline pfBool getDoFree() { return doFree;}

   // Overrides pfDVector's default malloc() method to be newMalloc.
   // The function supplied must have the prototype:
   //     void* malloc(size_t size);
   inline void setMalloc(MallocFunc* newMalloc) { dvectorMalloc = newMalloc; }

   // returns the address of the malloc() function being used by pfDVector.
   inline void* getMalloc() { return dvectorMalloc; }

   // Overrides the pfDVector's default free() method with newFree.
   // The function supplied must have the prototype:
   //     void free(void* ptr);
   inline void setFree(FreeFunc* newFree) { dvectorFree = newFree; }

   // returns the address of the free() routine being used by pfDVector.
   inline FreeFunc* getFree() { 
 	if(dvectorFree == NULL)  dvectorFree = pfMemory::free;
 	return dvectorFree; 
   }

   inline void removeElm( ssize_t index );
        /* 
        Removes element index from this pfDVector.  Elements
	index+1, index+2, ... are shifted left by one.  The length of this
        pfDVector decreases by one, while its allocate space remains unchanged.
         */

private:
   // Array extension routine
   void extend( ssize_t index, pfDVector<T> *dv ) {
     ssize_t   newMinIndex, newMaxIndex;
     ssize_t   newSize;
     ssize_t   beginRange, endRange;
     T    *tmp;

     // Deal with the initial zero range case
     if ( dv->size == 0 )
       {
#ifdef OP_GENERAL_DVECTOR
	 dv->minIndex = index;
	 dv->maxIndex = index;
#else
	 dv->minIndex = 0;
	 dv->maxIndex = index;
#endif
       }

     // Set up the new bounds around index. If this is the first
     // time through and the index is small and positive
     // assume that the index will never be less than zero.
     if ( 0 <= index && index <= dv->extension && dv->size == 0 )
       {
	 beginRange = 0;
       }
     else
       {
	 beginRange = index - dv->extension;
       }

     endRange   = index + dv->extension;

     // Extend the overall range of the indices
     // based on the min/max of the old range
     // plus the range about the index
     if ( beginRange < dv->minIndex )
       {
	 newMinIndex = beginRange;
       }
     else
       {
	 newMinIndex = dv->minIndex;
       }

     if ( endRange > dv->maxIndex )
       {
	 newMaxIndex = endRange - 1;
       }
     else
       {
	 newMaxIndex = dv->maxIndex;
       }

     // Make the new length the range of the new Max
     newSize = newMaxIndex - newMinIndex + 1;

     // Create a new vector size of the new length
     if(dvectorMalloc == NULL) dvectorMalloc = &(pfMemory::malloc);
     tmp = (T*) (*dvectorMalloc)( sizeof(T)*newSize );

     // ACP: Need this when data is pointers!
#ifndef WIN32
     bzero( tmp, sizeof(T)*newSize);
#else
     memset(tmp, 0, sizeof(T)*newSize);
#endif

     // Create, copy and create elements of the new array
     {
       T *d, *e, *t;

       // Construct the beginning part of the newly allocated space
       for ( t = tmp, e = &tmp[dv->minIndex - newMinIndex];
	     t < e;
	     t++ )
	 {
	   ::new(t, (pfUniqType*) NULL ) T;
	 }

       // Copy the data from old to new
       for ( d = dv->data, t = &tmp[dv->minIndex - newMinIndex], e = &tmp[dv->minIndex - newMinIndex + dv->size];
	     t < e;
	     d++, t++ )
	 {
	   *t = *d;
	 }

       // Finish constructing the left over newly allocated stuff
       for ( t = &tmp[dv->minIndex - newMinIndex + dv->size], e = &tmp[newSize];
	     t < e;
	     t++ )
	 {
	   ::new(t, (pfUniqType*) NULL ) T;
	 }
     }

     // Give back the old data
     if (dv->data) {
       if(dvectorFree == NULL) dvectorFree = pfMemory::free;
       (*dvectorFree)(dv->data);
     }

     // Remember the new range values
     dv->minIndex = newMinIndex;
     dv->maxIndex = newMaxIndex;
     dv->size     = newSize;

     // Save the pointer to the vector
     dv->data = tmp;
   }

public:
   inline T&  operator []( ssize_t index )
   {
      ssize_t j = maxIndex - index;

#ifdef OP_GENERAL_DVECTOR
      ssize_t i = index - minIndex;

      if ( (i | j) < 0)
      {
	 extend(index, this);
	 // Reset the index
	 i = index - minIndex;
      }
      if ( len < i + 1 ) len = i + 1;
      return data[i];
#else
      if ( j < 0 )
      {
	 extend(index, this);
      }
      if ( len < index + 1 ) len = index + 1;
      return data[index];
#endif
   }
	/*
	Classic array accessor allowing you to perform a "foo[5]" or a
	"&foo[10]" as an argument to a routine. Returns the lvalue of the
	contents of the subscripted array. Extends the array if necessary.
	*/

   inline T&  operator ()( ssize_t index ) const
   {
#ifdef OP_GENERAL_DVECTOR
      return( data[index - minIndex] );
#else
      return data[index];
#endif
   }
	/* 
	Works like the "[]" operator except that it never extends the array,
	and it performs a read only access.
	Access is faster since no bounds checks are performed.
	*/
 
};

template <class DLLEXPORT T>
void pfDVector<T>::removeElm( ssize_t index )
{
#ifdef OP_GENERAL_DVECTOR
   ssize_t startInd = index - minIndex;
#else
   ssize_t startInd = index; 
#endif

   if (startInd >= len)
      return;

   ssize_t i;
   T *dataPtr;
   for (i = startInd, dataPtr = data+startInd; i < len-1; i++, dataPtr++)
   {
      *dataPtr = *(dataPtr+1);
   }
   len--;
}

#endif  // #ifndef __PFDVECTOR_H__
