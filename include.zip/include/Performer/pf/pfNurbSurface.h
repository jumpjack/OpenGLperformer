 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.14 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfNurbSurface_h_
#define _pfNurbSurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfDVector.h>
#include <Performer/pf/pfParaSurface.h>
#include <Performer/pr/pfLinMath.h>

// The classic Non-uniform Rational B-spline (NURB) surface. 
#define PFNURBSURFACE ((pfNurbSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFNURBSURFACEBUFFER ((pfNurbSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfNurbSurface : public pfParaSurface
{
public:

    inline void setControlHull(int iu,int iv,const pfRVec3& p)  {
        PFNURBSURFACE->nb_setControlHull(iu, iv, p);
    }

    inline void setControlHull(int iu,int iv,const pfRVec4& p)  {
        PFNURBSURFACE->nb_setControlHull(iu, iv, p);
    }

    inline void setWeight(int iu,int iv,pfReal w)  {
        PFNURBSURFACE->nb_setWeight(iu, iv, w);
    }

    inline void setUknot(int iu,pfReal u)  {
        PFNURBSURFACE->nb_setUknot(iu, u);
    }

    inline void setVknot(int iv,pfReal v)  {
        PFNURBSURFACE->nb_setVknot(iv, v);
    }

    inline void setControlHullUSize(int s)  {
        PFNURBSURFACE->nb_setControlHullUSize(s);
    }

    inline void setControlHullVSize(int s)  {
        PFNURBSURFACE->nb_setControlHullVSize(s);
    }

    inline const pfRVec3* getControlHull(int iu,int iv)  {
        return PFNURBSURFACE->nb_getControlHull(iu, iv);
    }

    inline int getControlHullUSize()  {
        return PFNURBSURFACE->nb_getControlHullUSize();
    }

    inline int getControlHullVSize()  {
        return PFNURBSURFACE->nb_getControlHullVSize();
    }

    inline pfReal getWeight(int iu,int iv)  {
        return PFNURBSURFACE->nb_getWeight(iu, iv);
    }

    inline pfReal getUknot(int iu)  {
        return PFNURBSURFACE->nb_getUknot(iu);
    }

    inline pfReal getVknot(int iv)  {
        return PFNURBSURFACE->nb_getVknot(iv);
    }

    inline int getUknotCount()  {
        return PFNURBSURFACE->nb_getUknotCount();
    }

    inline int getVknotCount()  {
        return PFNURBSURFACE->nb_getVknotCount();
    }

    inline int getUorder()  {
        return PFNURBSURFACE->nb_getUorder();
    }

    inline int getVorder()  {
        return PFNURBSURFACE->nb_getVorder();
    }

    inline void removeControlHullElm(int iu,int iv)  {
        PFNURBSURFACE->nb_removeControlHullElm(iu, iv);
    }

    inline void removeUknot(int iu)  {
        PFNURBSURFACE->nb_removeUknot(iu);
    }

    inline void removeVknot(int iv)  {
        PFNURBSURFACE->nb_removeVknot(iv);
    }

    inline void flipUV()  {
        PFNURBSURFACE->nb_flipUV();
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFNURBSURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalDu(pfReal u,pfReal v,pfRVec3 &Du)  {
        PFNURBSURFACE->nb_evalDu(u, v, Du);
    }

    inline void evalDv(pfReal u,pfReal v,pfRVec3 &Du)  {
        PFNURBSURFACE->nb_evalDv(u, v, Du);
    }

    inline void evalNorm(pfReal u,pfReal v,pfRVec3 &norm)  {
        PFNURBSURFACE->nb_evalNorm(u, v, norm);
    }

    inline void write(pfTraverser *trav, uint which, uint verbose)  {
        PFNURBSURFACE->nb_write(trav, which, verbose);
    }

    inline pfNode* clone()  {
        return PFNURBSURFACE->nb_clone();
    }

    inline int flatten(pfTraverser* trav)  {
        return PFNURBSURFACE->nb_flatten(trav);
    }
public:
  //CAPI:basename NurbSurface
  //CAPI:updatable
  //CAPI:newargs
  pfNurbSurface();
  virtual ~pfNurbSurface();

 protected:
  pfNurbSurface(pfBuffer *buf);
  pfNurbSurface(const pfNurbSurface* prev,pfBuffer *buf);
 public:

   static pfType *getClassType() { return classType; }
   static void init();

 PFINTERNAL:
   //CAPI:verb NurbSurfaceControlHull
   void nb_setControlHull(int iu,int iv,const pfRVec3& p) {pf_setControlHullInternal(iv,iu,p);}

   //CAPI:verb NurbSurfaceControlHull4
   void nb_setControlHull(int iu,int iv,const pfRVec4& p) {pf_setControlHullInternal(iv, iu, p);}

  //CAPI:verb NurbSurfaceWeight
   void nb_setWeight(int iu,int iv,pfReal w) {pf_setWeightInternal(iv,iu,w);}
   
  //CAPI:verb NurbSurfaceUknot
   void nb_setUknot(int iu,pfReal u);

  //CAPI:verb NurbSurfaceVknot
   void nb_setVknot(int iv,pfReal v);

  //CAPI:verb NurbSurfaceControlHullUSize
   void nb_setControlHullUSize(int s);

  //CAPI:verb NurbSurfaceControlHullVSize
   void nb_setControlHullVSize(int s);

  //CAPI:verb GetNurbSurfaceControlHull
   const pfRVec3* nb_getControlHull(int iu,int iv) { return &(pf_getControlHullInternal(iv, iu)); }

  //CAPI:verb GetNurbSurfaceControlHullUSize
  int nb_getControlHullUSize()   { return controlHull[0].getLen(); }

  //CAPI:verb GetNurbSurfaceControlHullVSize
  int nb_getControlHullVSize()    { return controlHull.getLen(); }

  //CAPI:verb GetNurbSurfaceWeight
  pfReal  nb_getWeight(int iu,int iv)      { return pf_getWeightInternal(iv, iu); }

  //CAPI:verb GetNurbSurfaceUknot
 pfReal& nb_getUknot(int iu)              { return uKnot[iu]; }

  //CAPI:verb GetNurbSurfaceVknot
 pfReal& nb_getVknot(int iv)              { return vKnot[iv]; }

  //CAPI:verb GetNurbSurfaceUknotCount
   int nb_getUknotCount()          { return uKnot.getLen(); }

  //CAPI:verb GetNurbSurfaceVknotCount
   int     nb_getVknotCount()          { return vKnot.getLen(); }

  //CAPI:verb GetNurbSurfaceUorder
   int     nb_getUorder()              { return uOrder; }

  //CAPI:verb GetNurbSurfaceVorder
   int     nb_getVorder()              { return vOrder; }

   void nb_removeControlHullElm(int iu,int iv);
   void nb_removeUknot(int iu);
   void nb_removeVknot(int iv);
   void nb_flipUV();
   //CAPI:virtual
   virtual void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
   //CAPI:virtual
   virtual void nb_evalDu(pfReal u,pfReal v,pfRVec3 &Du);
   //CAPI:virtual
   virtual void nb_evalDv(pfReal u,pfReal v,pfRVec3 &Du);
   //CAPI:virtual
   virtual void nb_evalNorm(pfReal u,pfReal v,pfRVec3 &norm);

 PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);
   virtual void            nb_write(pfTraverser *trav, uint which, uint verbose);

   virtual pfNode* nb_clone();
   virtual int nb_flatten(pfTraverser* trav);


protected:

   void pf_updateParameters(const pfDVector<pfReal> &knots, int controlHullLen,
                         int &order, pfReal &begin, pfReal &end);
   /* 
      Updates order, begin and end of the surface so that they
      are consistent with controlHullLen and knots.  To update the
      u-related data all the arguments should be the appropriate kind 
      for u (e.g. setUknot). Similarly for v.
      */ 

private:
   //functions which are used internally
   pfReal  pf_getWeightInternal( int iv, int iu )      { return weight[iv][iu]; }
   pfRVec3& pf_getControlHullInternal( int iv, int iu ) { return controlHull[iv][iu]; }   
   void pf_setWeightInternal(           int iv, int iu, pfReal w );
   void pf_setControlHullInternal(      int iv, int iu, const pfRVec4 &p );
   void pf_setControlHullInternal(      int iv, int iu, const pfRVec3 &p );


private:
   pfDVector<pfDVector<pfRVec3> > controlHull;
   /* 

      The control hull points. These points are arranged in a
      2-dimensional array. To figure out the order of these control
      points, notice that the point evaluation formula can be expressed
      as  P(u,v) = sum_(i,j) B_i(u) B_j(v) C[j][i], where B_i and B_j are
      basis functions, and C is the control hull. Notice that in the formula,
      we use C[j][i] instead of C[i][j].

      */      
      
   pfDVector<pfReal>           uKnot; // U direction knot values 
   pfDVector<pfReal>           vKnot; // V direction knot values
   pfDVector<pfDVector<pfReal> > weight; // Shape control weights 
   int uOrder; // the order (degree+1) of u directional basis. 
   int vOrder; // the order (degree+1) of v directional basis.

   pfRVec3 lastPt; // caches the previously evaluated 3d point
   pfReal lastU, lastV; // caches the previously evaluated u and v.

   //Caches the location relative to the knots of previously evaluated u and v.
   int refU, refV;

   // Caches the previously evaluated u or v directional basis.
   pfDVector<pfReal>           basisU, basisV; 

   pfBool                      cachedForDers;
   /* If true, and if the input u,v equals lastU, lastV resp., then
      the following cached values are correct: last4dPt, last4dPtW,
      basisDU, basisDV, uBuSum, wBuSum.
     
      If false, these cached values might be wrong.
   */
 
   // Caches the 3D component of the previously evaluated 4D point.
   pfRVec3                    last4dPt;

   // Caches the weight of the previously evaluated 4D point.
   pfReal                    last4dPtW;

   // Caches the previously evaluated derivative of the u directional basis.
   pfDVector<pfReal>           basisDU;
   // Caches the previously evaluated derivative of the v directional basis.
   pfDVector<pfReal>           basisDV;

   pfDVector<pfRVec3>           uBuSum;
   /*
      Caches the previously evaluated sum sum_j B_j(u) C[i][j].
      Where B_j are basis functions and C is the control hull.
   */

   pfDVector<pfReal>           wBuSum;
   /*
      Caches the previously evaluated sum sum_j B_j(u) W[i][j].
      Where B_j are basis functions and and W is the weights.
   */

   void pf_computeCachedForDers( pfReal u, pfReal v );
   /*
      Computes all the cached values needed for computing the first order
      derivatives for (u, v).
   */

   int                       vSize; // Estimate of the control hull v size

   int normalCodeBeginU;
   /*
       1: u=beginU  is degenerated into a point
       0: u=beginU  is not degenerated into a point  
   */

   int normalCodeEndU;
   /*
       1: u=endU  is degenerated into a point
       0: u=endU  is not degenerated into a point  
   */
   
   int normalCodeBeginV;
   /*
       1: v=beginV  is degenerated into a point
       0: v=beginV  is not degenerated into a point  
   */
   
   int normalCodeEndV;
   /*
       1: v=endV  is degenerated into a point
       0: v=endV  is not degenerated into a point  
   */
   
   pfRVec3 normalBeginU; // The correct normal for u=beginU
   pfRVec3 normalEndU; // The correct normal for u=endU
   pfRVec3 normalBeginV; // The correct normal for v=beginV
   pfRVec3 normalEndV; // The correct normal for v=endV

   int normalCodeUpdated;
   /* 
      1: degenerate normal information has been updated;
      0: not
   */

   // Computes degenerate normal information: normalCode* and normal*.
   void pf_computeDegenerateNormalInfo();

   static pfType *classType;
};
#endif
