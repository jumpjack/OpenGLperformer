//
//
// Copyright 1995, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfRep.h		pfRep include file
//
#ifndef __PF_REP_H__
#define __PF_REP_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfGeode.h>
#include <Performer/pf/pfLists.h>
#include <Performer/pf/pfCuller.h>

class pfTessellateAction;

#define PFREP ((pfRep*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFREPBUFFER ((pfRep*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfRep : public pfGeode
{
public:

    inline void setOrigin( const pfRVec3&  org)  {
        PFREP->nb_setOrigin(org);
    }

    inline void setOrient( const pfRMatrix& mat)  {
        PFREP->nb_setOrient(mat);
    }

    inline void getOrigin( pfRVec3& org) const  {
        PFREP->nb_getOrigin(org);
    }

    inline void getOrient( pfRMatrix& mat) const  {
        PFREP->nb_getOrient(mat);
    }
public:		// Constructors/Destructors
    //CAPI:private
    //CAPI:basename Rep
    //CAPI:updatable
    //CAPI:newargs
    pfRep();
    //CAPI:public
    virtual ~pfRep();

protected:
    pfRep(pfBuffer* buf);
    pfRep(const pfRep* prev, pfBuffer* buf);

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }

public:			// pfMemory virtual functions

PFINTERNAL:		// pfUpdatable virtual functions
    virtual void	  pf_applyUpdate(const pfUpdatable *prev, int  upId);
    virtual pfUpdatable*  pf_bufferClone(pfBuffer *buf);
    virtual void          nb_write(pfTraverser *trav, uint which, uint verbose);

PFINTERNAL:		// pfNode virtual traversals
    virtual pfNode*	nb_clone();
    virtual int  	nb_flatten(pfTraverser *trav);

PFINTERNAL:		// class specific sets and gets

public:
    // pfRep Accessor functions
    void nb_setOrigin( const pfRVec3&  org) { origin = org; }
    void nb_setOrient( const pfRMatrix& mat) { orientation = mat; }
    void nb_getOrigin( pfRVec3& org) const { org = origin; }
    void nb_getOrient( pfRMatrix& mat) const { mat = orientation; }


protected:

    // pfRep Data members
    pfRVec3  origin;
// XXX Alex -- orientation should be a 3x3 matrix
    pfRMatrix orientation;
    static pfReal eps;
    static pfReal subtractiveTol;
    static pfReal functionTol;
    static int precision;

private:
    static pfType*      classType;
};

#endif // !__PF_REP_H___
