 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.25 $
// $Date: 2005/05/13 01:09:00 $

#ifndef _pfTopo_h_
#define _pfTopo_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#ifdef _WIN32 // need to include headers
#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfBoundary.h>
#include <Performer/pf/pfSolid.h>
#include <Performer/pf/pfJunction.h>
#endif // _WIN32

// Include dynamic array template class
#include <Performer/pf/pfDVector.h>

// Forward declarations
class pfGeode;
class pfGeoState;
class pfParaSurface;
class pfBoundary;
class pfJunction;
class pfSolid;
class pfCurve2d;
class pfEdge;

#define PFTOPO ((pfTopo*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFTOPOBUFFER ((pfTopo*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfTopo : public pfObject
{
public:
  pfTopo();
  virtual ~pfTopo();

  static void init();
  static pfType* getClassType() { return classType; }

  void setDistanceTol( pfReal tol, pfLengthUnits u );

  // inline 
  pfReal getDistanceTol( ) const { return tolerance;}

  pfLengthUnits getLengthUnits() const { return units; }

  // hidden: only used internally for now. 
  // We may need it for topo editing later
  // Sets the i'th element of the surface array.
  void           setSurface(  int i, pfParaSurface *sur );

  // Returns the i'th element of the surface array.
  pfParaSurface* getSurface(  int i );  

  // Returns the number of surfaces.
  int     getSurfaceCount( );  

  // Returns the i'th element of the boundary list.
  pfBoundary*    getBoundary( int i );

  // Returns the number of boundaries.
  int    getBoundaryCount(  );
  
	
  // Returns the number of solids. (see ::buildSolids()).
  int getSolidCount() {return solid.getLen();}

  // Returns the i'th solid. (see ::buildSolids()).
  pfSolid* getSolid( int i ) {return solid[i];}

  // returns index of solid in topo if successful and -1 otherwise
  int addSolid(pfSolid *solid);

  // hidden
  // Returns the index of this topo in the global topology list.
  int getTopoId();

  // Adds a surface onto the surface list.
  // Returns 0 if sur was already in the list.
  pfBool addSurface(  pfParaSurface *sur );
     
  // Adds a boundary onto the boundary list.
  int addBoundary( pfBoundary    *bnd ); 


  //  Given a list of surfaces ( surface), computes the
  //  shared boundaries and junctions of these surfaces. The
  //  shared boundaries are put into boundary, and
  //  the junctions are put into junction.
  //  The previously existing boundaries and junctions, if any, are deleted.
  //  In the current implementation, the junctions, which can be
  //  computed from the boundaries, are not computed.
  //  Also notice that the cache space for samplePoints is
  //  deallocated at the end of this function.

  //  It assumes that the surfaces have been added to the topology data structure
  //  (addSurface) by the user. If the surface list is
  //  empty, the method  prints
  //  a warning message and returns.
  
  void buildTopology();

  //  Creates solids (pfSolid) from the list of all surfaces 
  //  in this topology, and return the number of solids that have been created.
  //  Each solid is a list of connected surfaces.
  //  These solids can be accessed using ::getSolidCount and ::getSolid

  int buildSolids();

PFINTERNAL:
  // Global pointer to all topologies created.
  //CAPI:private
  static pfDVector<pfTopo*> *topology;

public:
  static pfTopo *getGlobalTopo(int n);
  static int getNumTopos();

  int getBeginRange() const { return beginRange; }
  int getEndRange() const { return endRange; }
  
  //  Compares the edges of the current surface currentSur against
  //  all the edges of the previously loaded surfaces and computes the
  //  overlap information.
  void buildTopologyCurSur(pfParaSurface *currentSur);


private:

protected:
  void pf_construct(); 

  // Tolerance for determining whether two curves overlap or not.
  pfReal                   tolerance;
  // Measurement unit in object space.
  pfLengthUnits            units;
  
  pfDVector<pfParaSurface*>  surface; // Surface list
    
  // Boundary list. A boundary is a set of completely overlapped trim curves.
  pfDVector<pfBoundary*>     boundary;  
      
  // A junction is the end point of a boundary.
  pfDVector<pfJunction*>     junction;

  // Boundaries that have no junctions as endpoints and no surfaces 
  // on either side of their winged data structures are called orphaned.
  int                      orphanedBoundaries;

  // Boundaries that have one surface on a side but the other null
  // are called open. Every time a border is added to the list, both the
  // orphaned and open boundary counters are incremented. Whenever
  // one side or both sides of a winged data structure is completed
  // or closed, the repsective counter is decremented.
  int                      openBoundaries;

  // All surfaces belong to some solid even if the solid is not
  // closed or if the solid only contains a single surface.
  pfDVector<pfSolid*>        solid;
     
  // The index of this topology in the list of all topologies.
  int                      topoId;

  //  Indicates which algorithm to use when building topology.
  //   0: simple approach, 
  //   1: moderate approach.
  //  It is set by environment variable PF_TOPO_ALGORITHM.
  //  This member should go away eventually. moderate appraoch should be
  //  the offical approach, and it is the default.
  //  XXX Alex -- we ignore PF_TOPO_ALGORITHM ... always use moderate search
  int topoAlgorithm; 
     
  double      cumTime; // Total time so far. For statistics.
  int         counter; // Count the surfaces. For statistics.
  int         beginRange; // For dbg use. Topo const. starts from this suface
  int         endRange; // For dbg use. Topo const ends at this surface
  
private:

  int hBoxGroupSize; // a bounding box of every GROUP_SIZE many boundaries.
  pfDVector<pfBox*> hierarchBoxes;

  //  A bit indicating the parity of the draw visit so that the
  //  boundaries can keep track of whether they have been visited
  //  during a given draw traversal.
  int visitParity;
   
  // a bounding box of every GROUP_SIZE many boundaries.
  void updateHierarchBoxes(); 


  //  Given two trim curves, find s1, s2 and t1, t2 so that 
  //  old_c[s1,s2] matches new_c[t1,t2]. Notice that
  //  s1 < s2, but t1 may be bigger than t2.
  //  If there is no overlap, returns 0, otherwise returns 1, and s1, s2,
  //  t1, and t2 are returned in the auguments.

  int computeOverLap(pfParaSurface* oSurf, pfCurve2d *old_c, pfReal &s1, pfReal &s2,
		     pfParaSurface* nSurf, pfCurve2d *new_c, pfReal &t1, pfReal &t2);
 
  //  Given a boundary b and a trim curve specified by surf, loopNum, and 
  //  curveNum, computes the overlap of the this boundary with this trim curve 
  // (callling ::computeOverLap). If there is an overlap, it splits this trim 
  //  curve and also the trm curve(s) in the boundary b.
  //  The trim curve strctures in the corresponding surfaces are updated 
  //  accordingly.  
  int overLapBoundaryWithTrimCurve( pfBoundary* b, pfParaSurface *surf, 
				    int loopNum, int curveNum);
  
  //For each boundary in the boundary list, call overLapBoundaryWithTrimCurve()
  int overLapBoundaryListWithTrimCurve( pfParaSurface *newSurf, 
					int newLoopNum, int newCurveNum);

  // For each trim curve in the surface newSurf, call 
  // ::overLapBoundaryListWithTrimCurve().
  void overLapBoundaryListWithSurface(pfParaSurface *newSurf);
  
  // Used for debugging purpose only.
  // Computes the overlap between two surfaces.
  void computeOverLapTwoSurfaces( pfParaSurface* oSurf, pfParaSurface* nSurf );

  // this is a utility function. It splits the new trim curve (see 
  // overlapBoundaryWihtTrimCurve). There is no assumed order for t1 t2
  int splitNewTrimCurve(pfParaSurface *sur, int loopNum, int curveNum, 
			pfReal t1, pfReal t2);
      
   static pfType *classType;
};
#endif
