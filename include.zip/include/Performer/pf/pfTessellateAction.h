 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.16 $
// $Date: 2004/06/14 17:23:33 $

#ifndef  _pfTessellateAction_h_
#define  _pfTessellateAction_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfGeoSet.h>
#include <Performer/pf/pfGeode.h>
#include <Performer/pf/pfRep.h>
#include <Performer/pf/pfDVector.h>

class pfTopo;

#define PFTESSELLATEACTION ((pfTessellateAction*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFTESSELLATEACTIONBUFFER ((pfTessellateAction*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfTessellateAction : public pfObject 
{
protected:
  pfTessellateAction();
public:
  virtual ~pfTessellateAction();

  static void init();
  static pfType* getClassType() { return classType; }

  /* inline */
  int getTriangleCount() const { return triCount; }

  /*inline */
  int getTriStripCount() const { return nTriStrips; }
   
  /*inline*/
  int getTriFanCount() const {  return nTriFans; }

  /*inline */
  void setReverseTrimLoop( const pfBool enable ) { reverseTrimLoop = enable; }

   /*inline */
   pfBool getReverseTrimLoop() const { return reverseTrimLoop; }

   /*inline */
   void setBuildTopoWhileTess(const pfBool _buildTopoWhileTess) {buildTopoWhileTess = _buildTopoWhileTess;}

   /*inline*/
   pfBool getBuildTopoWhileTess() const {return buildTopoWhileTess;}

   /*inline */
   void setTopo(pfTopo * _topo) {topo = _topo;}

   /*inline*/
   pfTopo *getTopo() const { return topo; }

protected:
   int         counter;
   //  Counts range to tessellate. The surfaces are labeled in the order
   //  of loading. This is useful for debugging.
      
   int         beginRange, endRange;
   // Only tessellates surfaces with counters between beginRange and endRange.

   int getBeginRange() const { return beginRange; }
   int getEndRange() const { return endRange; }

   int                       triCount;

   int                       tsCount, tsVCount, tsTCount, tsNCount, nTriStrips;
   int			     tfCount, tfVCount, tfTCount, tfNCount, nTriFans;
   int			     tsVLen, tsTLen, tsNLen, tfVLen, tfTLen, tfNLen;

   pfBool buildTopoWhileTess;
   /*
      A flag, when set to true, indicates that we build the topology while
      tessellating. In other words, before tessellating each surface,
      the topology information (shared boundaries) of all the surfaces 
      which have been essellated so far are computed, and these
      information are used by the tessellator to avoid cracks when
      tessellating the current surface. Notice that the tessellation
      may still have cracks because for each surface, 
      the topology information which the tessellation is based on 
      is not complete since not all surfaces have been seen yet.
      For instance, there may be surfaces later which 
      share a junction with the current surface but the tessellation
      of this current surface may not pick up this junction.

      If it is set to false, there is no topology construction while 
      tessellating.
      However, if the topology information has been set (computed
      by calling the  function pfTopo::buildTopology or 
      contructed manually), the tessellator will use them to
      avoid cracks.      

      The default is false.
   */

   pfTopo *topo;
   /*
      The topology pfTopo which is used for holding the surfaces and
      the boudaries when the tessellator needs to invoke topology building (by
      calling setBuildTopoWhileTess to set buildTopoWhileTess to be true).
    */ 

   pfBool reverseTrimLoop;
   //   Trim loop reversal flag. If set to true,
   // all the trim loops will be reversed before sent to tessellator.
 
   pfBool           hasTexture;
   // Hint to generate texture coords.



 private:
   static pfType *classType;
   void pf_construct();
};
#endif
