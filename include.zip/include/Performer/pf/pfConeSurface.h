 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.8 $
// $Date: 2004/06/14 17:23:33 $


#ifndef _pfConeSurface_H
#define _pfConeSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>

#define PFCONESURFACE ((pfConeSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCONESURFACEBUFFER ((pfConeSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfConeSurface : public pfParaSurface
{
public:

    inline void setRadius(pfReal _radius)  {
        PFCONESURFACE->nb_setRadius(_radius);
    }

    inline void setHeight(pfReal _height)  {
        PFCONESURFACE->nb_setHeight(_height);
    }

    inline pfReal getRadius() const  {
        return PFCONESURFACE->nb_getRadius();
    }

    inline pfReal getHeight() const  {
        return PFCONESURFACE->nb_getHeight();
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFCONESURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalNorm(pfReal u,pfReal v,pfRVec3 &norm)  {
        PFCONESURFACE->nb_evalNorm(u, v, norm);
    }
public:
  //CAPI:basename ConeSurface
  //CAPI:updatable
  //CAPI:newargs
  pfConeSurface();
  //CAPI:verb NewConeSurfaceWithArgs
  pfConeSurface(pfReal radius,pfReal height);
  virtual ~pfConeSurface();

protected:
  pfConeSurface(pfBuffer *buf);
  pfConeSurface(const pfConeSurface* prev,pfBuffer *buf);
  
public:
  static pfType* getClassType() { return classType; }
  static void init();
  
PFINTERNAL:
  virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
  virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);
  
PFINTERNAL:
  virtual pfNode *nb_clone();
  
public:
      
   void nb_setRadius(pfReal _radius) {radius = _radius;}
   void nb_setHeight(pfReal _height);
   pfReal nb_getRadius() const { return radius; }
   pfReal nb_getHeight() const { return height; }
   //CAPI:virtual
   virtual void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
   //CAPI:virtual
   virtual void nb_evalNorm(pfReal u,pfReal v,pfRVec3 &norm);
protected:
   pfReal radius, height, halfHeight;

   // Last values of sin(u) and cos(u) created by the last evalPt call.
   // Initially these values are undefined.
   pfReal sin_u, cos_u;

 private:
   static pfType *classType;
};
#endif
