 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.22
// $Date: 1996/11/03 02:51:09

#ifndef _pfHsplineCurve2d_H
#define _pfHsplineCurve2d_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve2d.h>
#include <Performer/pf/pfDVector.h>

#define PFHSPLINECURVE2D ((pfHsplineCurve2d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFHSPLINECURVE2DBUFFER ((pfHsplineCurve2d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfHsplineCurve2d : public pfCurve2d
{
public:

    inline int getKnotCount() const  {
        return PFHSPLINECURVE2D->nb_getKnotCount();
    }

    inline void setPoint(int i,const pfRVec2 &p)  {
        PFHSPLINECURVE2D->nb_setPoint(i, p);
    }

    inline void setTangent(int i,const pfRVec2 &tng)  {
        PFHSPLINECURVE2D->nb_setTangent(i, tng);
    }

    inline void setKnot(int i,pfReal t)  {
        PFHSPLINECURVE2D->nb_setKnot(i, t);
    }

    inline pfRVec2* getPoint(int i)  {
        return PFHSPLINECURVE2D->nb_getPoint(i);
    }

    inline pfRVec2* getTangent(int i)  {
        return PFHSPLINECURVE2D->nb_getTangent(i);
    }

    inline pfReal getKnot(int i)  {
        return PFHSPLINECURVE2D->nb_getKnot(i);
    }

    inline void evalPt(pfReal t,pfRVec2 &pnt)  {
        PFHSPLINECURVE2D->nb_evalPt(t, pnt);
    }
public:
  //CAPI:basename HsplineCurve2d
  //CAPI:updatable
  //CAPI:newargs
  pfHsplineCurve2d();
   virtual ~pfHsplineCurve2d( );

protected:
   pfHsplineCurve2d(pfBuffer *buf);
   pfHsplineCurve2d(const pfHsplineCurve2d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:
   int nb_getKnotCount() const {return knot.len;}
   void nb_setPoint(int i,const pfRVec2 &p);
   void nb_setTangent(int i,const pfRVec2 &tng);
   void nb_setKnot(int i,pfReal t);
   pfRVec2* nb_getPoint(int i)          { return &p[i]; }
   pfRVec2* nb_getTangent(int i)        { return &t[i]; }
   pfReal  nb_getKnot(int i)           { return knot[i]; }
   //CAPI:virtual
   virtual void nb_evalPt(pfReal t,pfRVec2 &pnt);

protected:
   pfDVector<pfRVec2>  p; // The points of the curve at the knot values
   pfDVector<pfRVec2>  t; // The tangents of the curve at the knot values
   pfDVector<pfReal>  knot; // knot values


private:
  static pfType *classType;
};

#endif
