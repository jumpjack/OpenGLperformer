 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.9 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfSuperQuadCurve3d_h_
#define _pfSuperQuadCurve3d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>

#define PFSUPERQUADCURVE3D ((pfSuperQuadCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSUPERQUADCURVE3DBUFFER ((pfSuperQuadCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfSuperQuadCurve3d : public pfCurve3d
{
public:

    inline void setRadius(pfReal _radius)  {
        PFSUPERQUADCURVE3D->nb_setRadius(_radius);
    }

    inline pfReal getRadius() const  {
        return PFSUPERQUADCURVE3D->nb_getRadius();
    }

    inline void setExponent(pfReal _exponent)  {
        PFSUPERQUADCURVE3D->nb_setExponent(_exponent);
    }

    inline pfReal getExponent() const  {
        return PFSUPERQUADCURVE3D->nb_getExponent();
    }

    inline void evalPt(pfReal t,pfRVec3 &pnt)  {
        PFSUPERQUADCURVE3D->nb_evalPt(t, pnt);
    }
public:
  //CAPI:basename SuperQuadCurve3d
  //CAPI:updatable
  //CAPI:newargs
   pfSuperQuadCurve3d();
  //CAPI:verb NewSuperQuadCurve3dWithArgs
   pfSuperQuadCurve3d(pfReal radius,pfRVec3 *origin,pfReal exponent);
   virtual ~pfSuperQuadCurve3d();   

protected:
   pfSuperQuadCurve3d(pfBuffer *buf);
   pfSuperQuadCurve3d(const pfSuperQuadCurve3d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:

   void nb_setRadius(pfReal _radius);
   pfReal nb_getRadius() const;
   void nb_setExponent(pfReal _exponent);
   pfReal nb_getExponent() const;

   void nb_evalPt(pfReal t,pfRVec3 &pnt);

protected:
   pfReal radius; // The radius of the super quadric curve.
   pfReal exponent; // The exponent of the super quadric curve.
   pfReal lastT; // Cached value for evaluation efficiency.
   pfReal sine, cosine; // Cached values for evaluation efficiency.


private:
  static pfType *classType;
};
#endif
