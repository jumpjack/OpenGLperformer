 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.7 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfRuledSurface_H
#define _pfRuledSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfCurve3d.h>

#define PFRULEDSURFACE ((pfRuledSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFRULEDSURFACEBUFFER ((pfRuledSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfRuledSurface : public pfParaSurface
{
public:

    inline void setCurve1(pfCurve3d *_c1)  {
        PFRULEDSURFACE->nb_setCurve1(_c1);
    }

    inline void setCurve2(pfCurve3d *_c2)  {
        PFRULEDSURFACE->nb_setCurve2(_c2);
    }

    inline pfCurve3d* getCurve1() const  {
        return PFRULEDSURFACE->nb_getCurve1();
    }

    inline pfCurve3d* getCurve2() const  {
        return PFRULEDSURFACE->nb_getCurve2();
    }
public:
  //CAPI:basename RuledSurface
  //CAPI:updatable
  //CAPI:newargs
  pfRuledSurface();
  //CAPI:verb NewRuledSurfaceWithArgs
  pfRuledSurface(pfCurve3d *c1,pfCurve3d *c2);
  //CAPI:public
  virtual ~pfRuledSurface();

protected:
   pfRuledSurface(pfBuffer *buf);
   pfRuledSurface(const pfRuledSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();

public:
   void nb_setCurve1(pfCurve3d *_c1);
   void nb_setCurve2(pfCurve3d *_c2);
   pfCurve3d *nb_getCurve1() const { return c1; }
   pfCurve3d *nb_getCurve2() const { return c2; }
   virtual void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
protected:
   pfCurve3d *c1, *c2;
   // Last evaluated values of the two defining curves.
   pfRVec3  p1, p2;

   /*
      Cached ranges of the defining curves domain defined as:

      range1 = c1->getEndT() - c1->getBeginT()
      range2 = c2->getEndT() - c2->getBeginT()
      These values are cached when the curves are set by the
      constructor or with the accessor functions.
   */
   pfReal range1, range2;

   /*
      Cached domain start values of the definging curves given by:

      start1 = c1->getBeginT()
      start2 = c2->getBeginT()

      These values are cached when the curves are set by the
      constructor or with the accessor functions.
   */
   pfReal start1, start2;


private:
  static pfType *classType;

};
#endif
