 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.10 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfSweptSurface_H
#define _pfSweptSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfScalar.h>

#define PFSWEPTSURFACE ((pfSweptSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSWEPTSURFACEBUFFER ((pfSweptSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfSweptSurface : public pfParaSurface
{
public:

    inline void setCrossSection(pfCurve3d *_crossSection)  {
        PFSWEPTSURFACE->nb_setCrossSection(_crossSection);
    }

    inline void setPath(pfCurve3d *_path)  {
        PFSWEPTSURFACE->nb_setPath(_path);
    }

    inline void setT(pfCurve3d *_tng)  {
        PFSWEPTSURFACE->nb_setT(_tng);
    }

    inline void setB(pfCurve3d *_b)  {
        PFSWEPTSURFACE->nb_setB(_b);
    }

    inline void setProf(pfScalar  *_profile)  {
        PFSWEPTSURFACE->nb_setProf(_profile);
    }

    inline pfCurve3d* getCrossSection() const  {
        return PFSWEPTSURFACE->nb_getCrossSection();
    }

    inline pfCurve3d* getPath() const  {
        return PFSWEPTSURFACE->nb_getPath();
    }

    inline pfCurve3d* getT() const  {
        return PFSWEPTSURFACE->nb_getT();
    }

    inline pfCurve3d* getB() const  {
        return PFSWEPTSURFACE->nb_getB();
    }

    inline pfScalar* getProf() const  {
        return PFSWEPTSURFACE->nb_getProf();
    }
public:
   //CAPI:updatable
   //CAPI:newargs
   pfSweptSurface();
   //CAPI:verb SweptSurfaceWithArgs
   pfSweptSurface(pfCurve3d *_crossSection,pfCurve3d *_path,pfCurve3d *_t,pfCurve3d *_b,pfScalar *_profile);
   virtual ~pfSweptSurface( );

protected:
   pfSweptSurface(pfBuffer *buf);
   pfSweptSurface(const pfSweptSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();

public:

   void nb_setCrossSection(pfCurve3d *_crossSection);
   void nb_setPath(pfCurve3d *_path);
   void nb_setT(pfCurve3d *_tng);
   void nb_setB(pfCurve3d *_b);
   void nb_setProf(pfScalar  *_profile);
   pfCurve3d *nb_getCrossSection() const { return crossSection;}
   pfCurve3d *nb_getPath()         const { return path;}
   pfCurve3d *nb_getT()            const { return t;}
   pfCurve3d *nb_getB()            const { return b;}
   pfScalar  *nb_getProf()         const { return profile;}

   virtual void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);

protected:
   pfCurve3d   *crossSection;              // The points of the shape being swept
   pfCurve3d   *path;                      // Path of the sweep
   pfCurve3d   *t;                         // Crosssection's orientation 
   pfCurve3d   *b;                    
   pfScalar    *profile;                         // Scalar part of the curve 

   pfRMatrix  mat;  // The 3x3 matrix defined by the vectors t and b
   pfRVec3   pf_orient(pfRVec3 p,pfReal u);  // Orients the swept outline along the path
   /*
   Orients the swept outline along the path. It forms an orientation
   matrix mat from u, and applies mat to p.
    */
   pfReal   lastU;                         // Last u value evaluated


 private:
   static pfType *classType;
   
};
#endif
