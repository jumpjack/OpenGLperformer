 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################

#ifndef _pfPieceWisePolySurface_h_
#define _pfPieceWisePolySurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfDVector.h>
#include <Performer/pf/pfParaSurface.h>

#define PFPIECEWISEPOLYSURFACE ((pfPieceWisePolySurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFPIECEWISEPOLYSURFACEBUFFER ((pfPieceWisePolySurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfPieceWisePolySurface : public pfParaSurface
{
public:

    inline void setControlHull(int patchu, int patchv, int iu, int iv, const pfRVec3* p)  {
        PFPIECEWISEPOLYSURFACE->nb_setControlHull(patchu, patchv, iu, iv, p);
    }

    inline pfRVec3* getControlHull(int patchu, int patchv, int iu, int iv)  {
        return PFPIECEWISEPOLYSURFACE->nb_getControlHull(patchu, patchv, iu, iv);
    }

    inline int getUpatchCount()  {
        return PFPIECEWISEPOLYSURFACE->nb_getUpatchCount();
    }

    inline int getVpatchCount()  {
        return PFPIECEWISEPOLYSURFACE->nb_getVpatchCount();
    }

    inline int getUorder(int patchu, int patchv)  {
        return PFPIECEWISEPOLYSURFACE->nb_getUorder(patchu, patchv);
    }

    inline int getVorder(int patchu, int patchv)  {
        return PFPIECEWISEPOLYSURFACE->nb_getVorder(patchu, patchv);
    }
public:
  //CAPI:basename PieceWisePolySurface
  //CAPI:updatable
  //CAPI:newargs
   pfPieceWisePolySurface();
   virtual ~pfPieceWisePolySurface();

 protected:
   pfPieceWisePolySurface(pfBuffer *buf);
   pfPieceWisePolySurface(const pfPieceWisePolySurface *prev,pfBuffer *buf);


 public:
   static pfType *getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser* );

public:
   
   void nb_setControlHull(int patchu, int patchv, int iu, int iv, const pfRVec3* p);
   pfRVec3* nb_getControlHull(int patchu, int patchv, int iu, int iv);
   int nb_getUpatchCount();
   int nb_getVpatchCount();
   int nb_getUorder(int patchu, int patchv);
   int nb_getVorder(int patchu, int patchv);
   virtual void nb_evalPt (pfReal u, pfReal v, pfRVec3& pnt);
   virtual void nb_evalDu (pfReal u, pfReal v, pfRVec3 &Du );
   virtual void nb_evalDv (pfReal u, pfReal v, pfRVec3 &Dv ); 
   virtual void nb_evalDuu(pfReal u, pfReal v, pfRVec3 &Duu); 
   virtual void nb_evalDvv(pfReal u, pfReal v, pfRVec3 &Dvv); 
 
protected:
   pfDVector<pfDVector<pfDVector<pfDVector<pfRVec3> > > > controlHull;

private:
   // Find the patch that (u, v) belongs to. If u or v are outside the
   // valid ranges then they are clamped to the valid range.
   void pf_getPatch(pfReal u, pfReal v, int &patchu, int &patchv);

   static pfType *classType; 
};
#endif


