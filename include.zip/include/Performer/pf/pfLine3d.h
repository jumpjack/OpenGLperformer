 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 // ####################################################################


#ifndef _PF_LINE3D_H_
#define _PF_LINE3D_H_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>

#define PFLINE3D ((pfLine3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFLINE3DBUFFER ((pfLine3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfLine3d : public pfCurve3d
{
public:

    inline void setPoint1(pfReal x1, pfReal y1, pfReal z1, pfReal t1)  {
        PFLINE3D->nb_setPoint1(x1, y1, z1, t1);
    }

    inline void setPoint2(pfReal x2, pfReal y2, pfReal z2, pfReal t2)  {
        PFLINE3D->nb_setPoint2(x2, y2, z2, t2);
    }

    inline void getPoint1(pfReal *x1, pfReal *y1, pfReal *z1, pfReal *t1) const  {
        PFLINE3D->nb_getPoint1(x1, y1, z1, t1);
    }

    inline void getPoint2(pfReal *x2, pfReal *y2, pfReal *z2, pfReal *t2) const  {
        PFLINE3D->nb_getPoint2(x2, y2, z2, t2);
    }

    inline void evalPt(pfReal t,pfRVec3 &pnt)  {
        PFLINE3D->nb_evalPt(t, pnt);
    }
public:
  //CAPI:basename Line3d
  //CAPI:updatable
  //CAPI:newargs
   pfLine3d();
   //CAPI:verb NewLine3dWithArgs
   pfLine3d(pfReal x1,pfReal y1,pfReal z1,pfReal t1,pfReal x2,pfReal y2,pfReal z2,pfReal t2);
   //CAPI:public
   virtual ~pfLine3d();

protected:
   pfLine3d(pfBuffer* buf);
   pfLine3d(const pfLine3d* prev, pfBuffer* buf);

public:
   // per class functions
   static void init();
   static pfType* getClassType() { return classType; }

public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);

public:     // class specific sets and gets
   // Accessor functions
   void nb_setPoint1(pfReal x1, pfReal y1, pfReal z1, pfReal t1); 
   void nb_setPoint2(pfReal x2, pfReal y2, pfReal z2, pfReal t2);
   void nb_getPoint1(pfReal *x1, pfReal *y1, pfReal *z1, pfReal *t1) const;
   void nb_getPoint2(pfReal *x2, pfReal *y2, pfReal *z2, pfReal *t2) const;

   // Evaluators
   //CAPI:virtual
   virtual void nb_evalPt(pfReal t,pfRVec3 &pnt);

PFINTERNAL:


protected:
   pfRVec3 orig;
   pfRVec3 direction;
   pfReal scale, bias;

private:
   static pfType*      classType;
};

#endif
