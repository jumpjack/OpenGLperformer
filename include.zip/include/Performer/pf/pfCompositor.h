//
// Copyright 1999, 2000, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfCompositor.h

////////////////////////////////////////////////////////////////////////////////

#ifndef __PF_COMPOSITOR_H__
#define __PF_COMPOSITOR_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr.h>
#include <Performer/prmath.h>
#include <Performer/pr/pfType.h>
#include <Performer/pr/pfObject.h>
#include <Performer/pr/pfLinMath.h>
#include <Performer/pf.h>
#include <Performer/pf/pfChannel.h>
#include <Performer/pf/pfLists.h>
#include <Performer/pf/pfLoadBalance.h>
#include <Performer/pf/pfPipe.h>

#ifndef WIN32
#include <GL/glx.h>
#endif




#if 0
////////////////////////////////////////////////////////////////////////////////

                          PFCOMP_COMPMODE_HORIZ_STRIPES:
  ________________    ________________    ________________    ________________
 |                |  |                |  |                |  |       3        |
 |                |  |       1        |  |       2        |  |________________|
 |                |  |                |  |________________|  |       2        |
 |       0        |  |________________|  |       1        |  |________________|
 |                |  |                |  |________________|  |       1        |
 |                |  |       0        |  |                |  |________________|
 |                |  |                |  |       0        |  |       0        |
 |________________|  |________________|  |________________|  |________________|

                          PFCOMP_COMPMODE_VERT_STRIPES:
  ________________    ________________    ________________    ________________
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |       0        |  |   0    |   1   |  | 0  |  1  |  2  |  | 0 | 1 | 2 | 3  |
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |                |  |        |       |  |    |     |     |  |   |   |   |    |
 |________________|  |________|_______|  |____|_____|_____|  |___|___|___|____|

                          PFCOMP_COMPMODE_LEFT_TILES:
  ________________    ________________    ________________    ________________
 |                |  |        |       |  |     |          |  |       |        |
 |                |  |        |       |  |     |   2      |  |       |   3    |
 |                |  |        |       |  |     |          |  |   1   |________|
 |       0        |  |   0    |   1   |  |  0  |__________|  |       |        |
 |                |  |        |       |  |     |          |  |_______|        |
 |                |  |        |       |  |     |    1     |  |       |   2    |
 |                |  |        |       |  |     |          |  |   0   |        |
 |________________|  |________|_______|  |_____|__________|  |_______|________|

                          PFCOMP_COMPMODE_RIGHT_TILES:
  ________________    ________________    ________________    ________________
 |                |  |        |       |  |         |      |  |       |        |
 |                |  |        |       |  |    2    |      |  |       |   3    |
 |                |  |        |       |  |         |      |  |   1   |________|
 |       0        |  |  0     |   1   |  |_________|  0   |  |       |        |
 |                |  |        |       |  |         |      |  |_______|        |
 |                |  |        |       |  |    1    |      |  |       |   2    |
 |                |  |        |       |  |         |      |  |   0   |        |
 |________________|  |________|_______|  |_________|______|  |_______|________|

                          PFCOMP_COMPMODE_BOTT_TILES:
  ________________    ________________    ________________    ________________
 |                |  |                |  |        |       |  |     |          |
 |                |  |       1        |  |        |       |  |  2  |     3    |
 |                |  |                |  |   1    |   2   |  |     |          |
 |       0        |  |________________|  |        |       |  |_____|__________|
 |                |  |                |  |________|_______|  |        |       |
 |                |  |       0        |  |                |  |   0    |   1   |
 |                |  |                |  |        0       |  |        |       |
 |________________|  |________________|  |________________|  |________|_______|

                          PFCOMP_COMPMODE_TOP_TILES:
  ________________    ________________    ________________    ________________
 |                |  |                |  |                |  |     |          |
 |                |  |       1        |  |       0        |  |  2  |    3     |
 |                |  |                |  |________________|  |     |          |
 |       0        |  |________________|  |       |        |  |_____|__________|
 |                |  |                |  |       |        |  |        |       |
 |                |  |       0        |  |   1   |   2    |  |   0    |   1   |
 |                |  |                |  |       |        |  |        |       |
 |________________|  |________________|  |_______|________|  |________|_______|

////////////////////////////////////////////////////////////////////////////////
#endif

extern "C" {

/* values used in setMode */
#define PFCOMP_SOFTWARE		       -2
#define PFCOMP_COMPOSITION_MODE     	1
#define PFLOAD_BALANCE      	    	2
#define PFCOMP_CLIPPING     	    	3
#define PFCOMP_SWAPBARRIER		4

#define PFCOMP_TEMPORAL_PADDING     	5
#define PFCOMP_SPATIAL_PADDING     	6
#define PFCOMP_SPATIAL_PADSIZE	    	7


/* Composition Modes */
#define PFCOMP_COMPMODE_HORIZ_STRIPES	1
#define PFCOMP_COMPMODE_VERT_STRIPES	2
#define PFCOMP_COMPMODE_LEFT_TILES	3
#define PFCOMP_COMPMODE_RIGHT_TILES	4
#define PFCOMP_COMPMODE_BOTT_TILES	5
#define PFCOMP_COMPMODE_TOP_TILES	6
#define PFCOMP_COMPMODE_ANTIALIAS	7

/* tokens for pfChannel::setCompositorShareMask: */
#define PFCOMP_SHARE_FOV		0x1
#define PFCOMP_SHARE_VIEW		0x2
#define PFCOMP_SHARE_NEARFAR		0x4
#define PFCOMP_SHARE_SCENE		0x10
#define PFCOMP_SHARE_STRESS	    	0x20
#define PFCOMP_SHARE_STRESSFILTER       PFCOMP_SHARE_STRESS
#define PFCOMP_SHARE_LOD		0x40
#define PFCOMP_SHARE_EARTHSKY		0x80
#define PFCOMP_SHARE_SWAPBUFFERS	0x100 /* ? */
#define PFCOMP_SHARE_VIEW_OFFSETS	0x200
#define PFCOMP_SHARE_STATS_DRAWMODE	0x400 /* ? */
#define PFCOMP_SHARE_APPFUNC		0x1000
#define PFCOMP_SHARE_CULLFUNC		0x2000
#define PFCOMP_SHARE_DRAWFUNC		0x4000
#define PFCOMP_SHARE_VIEWPORT		0x8000
#define PFCOMP_SHARE_SWAPBUFFERS_HW	0x10000
#define PFCOMP_SHARE_CULL_VOLUME	0x20000 /* ? */
#define PFCOMP_SHARE_GSTATE		0x40000
#define PFCOMP_SHARE_PRICLASS_LIST	0x80000 /* ? */
#define PFCOMP_SHARE_LPOINTFUNC     	0x100000 /* ? */
#define PFCOMP_SHARE_POSTLPOINTFUNC 	0x200000 /* ? */
#define PFCOMP_SHARE_BIN_ORDER	    	0x400000
#define PFCOMP_SHARE_TRAV_MODE	    	0x800000
#define PFCOMP_SHARE_CHAN_DATA          0x1000000

#define PFCOMP_MAX_INPUTS   	    	32
#define PFCOMP_MAX_CHANNELS 	    	32

#define PFCOMP_INPUTTYPE_PIPE	    	1
#define PFCOMP_INPUTTYPE_COMPOSITOR 	2

}

////////////////////////////////////////////////////////////////////////////////

class pfPipe;
class pfCompositor;

////////////////////////////////////////////////////////////////////////////////

typedef struct
{
    float left, right, bottom, top;
} _pfScreenArea;

typedef struct __pfCompositorChild _pfCompositorChild;
typedef struct _pfHWCompositor pfHWCompositor;

////////////////////////////////////////////////////////////////////////////////

#define PFCOMPOSITOR ((pfCompositor*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCOMPOSITORBUFFER ((pfCompositor*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCompositor : public pfObject {

    //class type
    static pfType  *classType;

public:

    //CAPI:newargs
    pfCompositor( int netID );
    virtual ~pfCompositor();
    
    //// type checking functions
    static void init();
    static pfType* getClassType() 
    	{return classType;}

    //CAPI:verb GetNumHWCompositors
    static int getNumHWCompositors();

    //CAPI:verb GetHWCompositorNetworkId
    static int getHWCompositorNetworkId(int c);

    //CAPI:verb GetHWCompositorNumInputs
    static int getHWCompositorNumInputs(int c);

    //CAPI:verb GetHWCompositorInputType
    static int getHWCompositorInputType(int c, int i);

    //CAPI:verb GetHWCompositorInputPipeName
    static char* getHWCompositorInputPipeName(int c, int i);

    //CAPI:verb GetHWCompositorInputNetworkId
    static int getHWCompositorInputNetworkId(int c, int i);

    //CAPI:verb GetHWCompositorPfCompositor
    static pfCompositor* getHWCompositorPfCompositor(int c);

    //CAPI:verb GetNumCompositedPipes
    static int getNumCompositedPipes();

    //CAPI:verb GetNumCompositors
    static int getNumCompositors();

    //CAPI:verb GetCompositor
    static pfCompositor* getCompositor(int i); 

    //CAPI:verb GetCompositorNetworkId
    int getNetworkId(); 

    //CAPI:verb CompositorAutoSetup
    void autoSetup(int num_inputs);

    // add a pipe child (specified by display string) to compositor.
    //CAPI:verb CompositorAddChild
    int  addChild(char* pipe_name);

    // add a pfCompositor child to compositor.
    //CAPI:verb CompositorAddCompositor
    int  addChild(pfCompositor *comp); 

    //CAPI:verb GetCompositorNumChildren
     int getNumChildren() 
    	{ return children.getNum(); } 

    //CAPI:verb GetCompositorChildType
    int getChildType(int index);

    //CAPI:verb GetCompositorChildCompositor
    pfCompositor *getChildCompositor(int index);

    //CAPI:verb GetCompositorChildPipe
    pfPipe *getChildPipe(int index);

    //CAPI:verb GetCompositorChildPipeName
    char* getChildPipeName(int index);

    //CAPI:verb GetCompositorChildPipeId
    int getChildPipeId(int index);

    //CAPI:verb GetCompositorParent
    pfCompositor* getParent()
    	{return parent;} 

    //CAPI:verb GetCompositorNumActiveChildren
    int getNumActiveChildren();

    //CAPI:verb CompositorNumActiveChildren
    int setNumActiveChildren(int n);

    //CAPI:verb CompositorViewport
    void setViewport(float left, float right, float bottom, float top);

    //CAPI:verb GetCompositorViewport
    void getViewport(float *left, float *right, float *bot, float *top);

    //CAPI:verb CompositorVal
    void setVal(int what, float val);

    //CAPI:verb GetCompositorVal
    float getVal(int what);

    //CAPI:verb CompositorMode
    void setMode(int what, int val);

    //CAPI:verb GetCompositorMode
    int  getMode(int what);

    //CAPI:verb CompositorLoadBalancer
    void setLoadBalancer(pfLoadBalance *balancer);

    //CAPI:verb GetCompositorLoadBalancer
    pfLoadBalance *getLoadBalancer(void);

    //CAPI:verb CompositorChildViewport
    void setChildViewport(int i, float left, float right, float bot, float top);

    //CAPI:verb GetCompositorChildViewport
    void getChildViewport(int i, float* l, float* r, float* b, float* t);

    //CAPI:verb ResetCompositorChildrenViewports
    void resetChildrenViewports(); 

    //CAPI:verb GetCompositorMasterPipe
    pfPipe *getMasterPipe() 
    	{ return masterPipe; }

    //CAPI:verb GetCompositorMasterPipeId
    int getMasterPipeId()
    	{ return masterPipeId; }
    
    //CAPI:verb GetCompositorNumPipes
    int getNumPipes();

    //CAPI:verb GetCompositorPipe
    pfPipe* getPipe(int p);

    //CAPI:verb GetCompositorPWin
    pfPipeWindow* getPWin(int p);

    //CAPI:verb GetCompositorChan
    pfChannel* getChan(int p, int c);


    //CAPI:verb GetCompositorRoot
    pfCompositor* getRoot()
    	{ return root; }



    //CAPI:verb CompositorChannelClipped
    void setChannelClipped(int chan_num, int clip );

    //CAPI:verb GetCompositorChannelClipped
    unsigned char getChannelClipped(int chan_num);

    //CAPI:verb CompositorAntialiasJitter
    int setAntialiasJitter( int n, float* jitter );

    //CAPI:verb GetCompositorAntialiasJitter
    int getAntialiasJitter( int n, float* jitter );

    //CAPI:verb GetCompositorDefaultChanShareMask
    static uint getDefaultChanShareMask()
    	{ return dfltChanShareMask; }

    //CAPI:verb CompositorDefaultChanShareMask
    static void setDefaultChanShareMask(uint mask) 
    	{ dfltChanShareMask = mask; }


PFINTERNAL:

    // Called at the beginning of pfConfig. Automatically attach all
    // physically connected pipes to each pfCompositor, unless user 
    // has explicitely added a list of children.
    static void pf_preConfig();

    void pf_parseAddChildren(char* s);

    // Called at the end of pfConfig. Populate full info about children 
    // in _pfCompositorChild structs. Mark pfPipes as composited pipes.
    // Also allocate fluxed buffers, and create hyperpipe configs here
    static void pf_configAll();

    // Called inside APP process every frame.
    void pf_frame();  

    // Called in DRAW process every frame (from pfPipe::preDraw).
    void pf_preDraw( int child_index );

    // Called in DRAW process every frame (from pfProcess.C).
    void pf_postDraw( int child_index );

    void pf_reset_default_video_cmb();
    static void pf_exit();

    void pf_createChannelOnSlavePipes();
    void pf_createPWinOnSlavePipes();

    void pf_setChanViewportDirty( int chan_index );
    void pf_setChanFrustumDirty( int chan_index );

protected:

    int pf_config(int first_pipe_index);

    void pf_createHyperpipeConfig();
    int pf_bindToHyperpipe(int pipe_index);

    void pf_setDfltChildrenViewports();

    int pf_balance();
    void pf_balanceSoftware();

    // grab stress values from active pipes
    float pf_computeStress();

    void pf_alignViewports();
    void pf_debugViewports();

    // compute children viewports based on compositor viewport, composition 
    // mode, number of active children and their latest workload values
    void pf_convertWorkToViewports();

    // make sure work values for active children add up to 1.0f
    void pf_normalizeWorkArray();

    // returns whether this frame's viewports are different from last frame's
    int pf_haveChildrenViewportsChanged();

    // convert children viewport values to piperect values (origin on
    // screen's top-left) and flux down to draw process
    void pf_updatePipeRects();

    // recompute and set channels output viewport and frustums based on 
    // master channels' viewport wrt pipe-vieworts.
    void pf_updateChanViewports();

    void pf_programCompositor();

    void pf_setupGL();
    void pf_restoreGL();

    inline _pfCompositorChild* getChild(int i)
    	{ return (_pfCompositorChild*)(children[i]); }


protected:
    // list of available hw compositors
    static  pfList* listHWComp; 

    // list of pfCompositors created by user
    static  pfList* listCompositors; 

    // initial value assigned to channels as compositorShareMask
    static uint dfltChanShareMask;

    static int do_swap_barriers;
    static int max_barriers;

    static float *aa_jitter[PFCOMP_MAX_INPUTS];

    int softwareCompositing;

    pfHWCompositor *hwc;
    int hyperId;
    int swap_barrier;

    int composition_mode;

    // Children of this compositor. For a single layer setup they can only
    // be pfPipes. For multi-layer setups they ca also be compositors.
    _pfVoidList children;	

    pfList* listPipes;

    pfPipe *masterPipe;
    int masterPipeId;

    pfCompositor *parent;
    pfCompositor *root;

    ///int numActiveChildren;

    pfLoadBalance *loadBalance;
    int load_balancing;

    // Allocation of work for this compositor. Maximum (full screen) is 1.0
    float total_work;	
    float work[PFCOMP_MAX_INPUTS];

    float stress[PFCOMP_MAX_INPUTS];

    int screenWidth;
    int screenHeight;

    _pfScreenArea viewport;

    _pfScreenArea _viewport[PFCOMP_MAX_INPUTS];
    _pfScreenArea _oldViewport[PFCOMP_MAX_INPUTS];

    // Parameters to be sent to the compositor hardware in the DRAW process.
    pfFlux *fluxDirty;	
    pfFlux *fluxPipeRects;
    pfFlux *fluxReadWrite;
    pfFlux *fluxNumActive;

    float fsreadback;
    unsigned char * screenData[PFCOMP_MAX_INPUTS];
    unsigned char childDone[PFCOMP_MAX_INPUTS];

    int clipping;
    int chan_clip[PFCOMP_MAX_CHANNELS];

    float *usr_jitter[PFCOMP_MAX_INPUTS];

    int aaDirty; 
    int compViewportDirty;
    uint64_t childViewportDirty;
    uint64_t chanViewportDirty;
    uint64_t chanFrustumDirty;

    // For keeping binary compatibility in minor releases.
    void * extraData;		
};

#endif //__PF_COMPOSITOR_H__
