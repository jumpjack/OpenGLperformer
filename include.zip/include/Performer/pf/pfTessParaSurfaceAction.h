//
// Copyright 1996,1997,1998 Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// ####################################################################



// $Revision: 1.15 $
// $Date: 2004/06/14 17:23:33 $

#ifndef  _pfTessParaSurface_h_
#define  _pfTessParaSurface_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfTessellateAction.h>
#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfDisCurve2d.h>
#include <Performer/pf/pfDisCurve3d.h>
#include <Performer/pf/pfCurve2d.h>
#include <Performer/pf/pfCurve3d.h>
#include <Performer/pf/pfEdge.h>
#include <Performer/pf/pfLists.h>

class genericTess;


#define PFTESSPARASURFACEACTION ((pfTessParaSurfaceAction*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFTESSPARASURFACEACTIONBUFFER ((pfTessParaSurfaceAction*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfTessParaSurfaceAction : public pfTessellateAction
{
public:
    pfTessParaSurfaceAction();
    //CAPI:private
    pfTessParaSurfaceAction(pfReal chordalDevTol,pfBool scaleTolByCurvature,int samples );
      
    virtual ~pfTessParaSurfaceAction();

    static void init();
    static pfType *getClassType() { return classType; }

    //CAPI:public
    void   setChordalDevTol(const pfReal chordalDevTol);
    pfReal getChordalDevTol();
    void   setScaleTolByCurvature(const pfReal scaleTolByCurvature);
    pfBool   getScaleTolByCurvature( );
    void setSampling(const int samples);
    int  getSampling( );
    void setNonUniformSampling(const pfBool uniformSamplingFlag);
    pfBool getNonUniformSampling();
    void setGenUVCoordinates(const pfBool genUVCoordinates);
    pfBool getGenUVCoordinates();
    void setGenGeoArrays(pfBool enable);
    pfBool getGenGeoArrays() const;

    static void tessellate(pfTessParaSurfaceAction *action, pfObject *object);
    void tessellator(pfParaSurface *sur);

protected:

    // tessellates a trim curve. It returns true if successful.
    pfBool tessellateEdge( pfParaSurface &sur, pfEdge *e );

    // Tessellates all the trim curves of the surface sur.
    // It returns true if all trim curves are successfully tessellated.
    pfBool tessellateBoundaries(pfParaSurface& sur);

    pfDisCurve3d* computeDiscreteCurve ( pfParaSurface &sur, pfCurve2d *cont_c, pfDisCurve2d  *dis_c, pfDVector<int> &noDelete );
    /*
      Takes a parametric surface sur and a trim curve cont_c and tessellates 
      the trim curve. The resulting discrete curve is stored in dis_c, the
      evaluated xyz coordinates are returned as an pfDisCurve3d. 
      noDelete is used to return an array of indices into those  points in 
      dis_c and indicates that those points should not be deleted by decimation
      because there may be derivative discontinuities at those points.
      The number of samples for tessellation is controlled by samples.
      */      

    void chordalDecimate(pfDisCurve3d **xyz_c, pfDisCurve2d **uv_c, pfDVector<int> &noDelete );
    /*
      Takes a 2d discrete curve uv_c and its evaluated xyz coordinates xyz_c,
      and decimates this curve according to chordalDevTol. The distance between
      the simplified curve and the original curve is no bigger than 
      chordalDevTol in 3D space. Those points which are indexed by noDelete 
      are not deleted. The simplified UV curve is stored back in uv_c, and the
      3D curve is stored back in xyz_c.
      */

    pfReal chordalDevTol;
    /* 
      This number controls both the trim curve tessellation resolution and
      the surface tessellation resolution. The trim curves are tessellated
      such that the error between the tessellated curve and the orignal curve
      in object space is no bigger than chordalDevTol. 
      The surfaces are tessellated such that the error between the tessellated 
      surface and the orignal surface in object space is no bigger than 
      chordalDevTol. 
      The default value is 0.0001.
      */      

    pfBool scaleTolByCurvature;
    /* 
      If set to true, chordalDevTol is scaled by curvature.
      The default value is false.
      */

    int    samples;
    /*
      Each trim curve is first tessellated into samples many
      line segments, then decimated according to chordalDevTol.
      This number should be big enough to ensure chordalDevTol
      is met in the first place. The default value is 100.
      */

    pfBool nonUniformTessFlag;
    /* 
       If true performs sample a nonuniform sampling of the surface
       conforming to the maximum chordal deviation toleration.The
       sampling is done in U and then V creating a nonumiformed ruled
       grid of sample points. By default this value is set to true.
       */
    
    // Flag to indicate whether to generate texture coordinates.
    pfBool genUVCoordinates;

    genericTess *gt; // Internal tessellation utility.

    // Internal triangle primitive mode for collecting tessellated results
    // from tessellator.
    int   mode;

    // flag indicating whether or not we should generate geoarrays
    // or 'simple' geosets.
    pfBool genGeoArrays; 


#define TABLE_W 10
#define TABLE_H 10
    _pfTemplateList<pfRVec2> uvArray[TABLE_W][TABLE_H];
    /* 
       Match table for surface stiching. See also xyzArray.
       Conceptually, each entry of a match table contains (u,v,x,y,z)
       indicating that the object coordinates at (u,v) are (x,y,z).
       In the implementation, we actually have two tables one for (u,v),
       the other for (x,y,z). Each table is really a hash-table.
      */
      
    // Match table for surface stitching. See also uvArray.
    _pfTemplateList<pfRVec3> xyzArray[TABLE_W][TABLE_H];
  

private:


    void pf_construct();
    static pfType* classType;
};
#endif
