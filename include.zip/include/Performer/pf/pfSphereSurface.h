 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.7 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfSphereSurface_H
#define _pfSphereSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>

#define PFSPHERESURFACE ((pfSphereSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSPHERESURFACEBUFFER ((pfSphereSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfSphereSurface : public pfParaSurface
{
public:

    inline void setRadius(pfReal radiusVal)  {
        PFSPHERESURFACE->nb_setRadius(radiusVal);
    }

    inline pfReal getRadius() const  {
        return PFSPHERESURFACE->nb_getRadius();
    }

    inline void evalPt(pfReal  u,pfReal v,pfRVec3 &pnt)  {
        PFSPHERESURFACE->nb_evalPt(u, v, pnt);
    }

    inline void evalNorm(pfReal  u,pfReal v,pfRVec3 &norm)  {
        PFSPHERESURFACE->nb_evalNorm(u, v, norm);
    }
public:
  //CAPI:basename SphereSurface
  //CAPI:updatable
  //CAPI:newargs
  pfSphereSurface();
  //CAPI:verb NewSphereSurfaceWithArgs
  pfSphereSurface(pfReal radius);
  virtual ~pfSphereSurface();

protected:
   pfSphereSurface(pfBuffer *buf);
   pfSphereSurface(const pfSphereSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();

public:
      
   void nb_setRadius(pfReal radiusVal) { radius = radiusVal; }
   pfReal nb_getRadius() const { return radius; }
   void nb_evalPt(pfReal  u,pfReal v,pfRVec3 &pnt);
   void nb_evalNorm(pfReal  u,pfReal v,pfRVec3 &norm);

protected:
   pfReal radius; // radius of the sphere
   // cached values of sin(u), cos(u), sin(v) and cos(v) for
   // evaluation efficiency
   pfReal sin_u, cos_u, sin_v, cos_v;


 private:
   static pfType *classType;
};
#endif
