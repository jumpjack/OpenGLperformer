 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 // ####################################################################


#ifndef _PF_CURVE3D_
#define _PF_CURVE3D_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfLinMath.h>
#include <Performer/pf/pfDVector.h>
#include <Performer/pf/pfDisCurve3d.h>

class pfTessellateAction;

#define PFCURVE3D ((pfCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCURVE3DBUFFER ((pfCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCurve3d : public pfRep
{
public:

    inline void setBeginT(pfReal beginT)  {
        PFCURVE3D->nb_setBeginT(beginT);
    }

    inline void setEndT(pfReal endT)  {
        PFCURVE3D->nb_setEndT(endT);
    }

    inline pfReal getBeginT()  {
        return PFCURVE3D->nb_getBeginT();
    }

    inline pfReal getEndT()  {
        return PFCURVE3D->nb_getEndT();
    }

    inline void getBeginPt(pfRVec3& retVal)  {
        PFCURVE3D->nb_getBeginPt(retVal);
    }

    inline void getEndPt(pfRVec3& retVal)  {
        PFCURVE3D->nb_getEndPt(retVal);
    }

    inline void getBeginTan(pfRVec3& retVal)  {
        PFCURVE3D->nb_getBeginTan(retVal);
    }

    inline void getEndTan(pfRVec3& retVal)  {
        PFCURVE3D->nb_getEndTan(retVal);
    }

    inline void setClosed(pfLoop loopVal)  {
        PFCURVE3D->nb_setClosed(loopVal);
    }

    inline pfLoop getClosed()  {
        return PFCURVE3D->nb_getClosed();
    }

    inline void setClosedTol(pfReal tol)  {
        PFCURVE3D->nb_setClosedTol(tol);
    }

    inline pfReal getClosedTol()  {
        return PFCURVE3D->nb_getClosedTol();
    }

    inline void evalPt(pfReal t, pfRVec3 &pnt)  {
        PFCURVE3D->nb_evalPt(t, pnt);
    }

    inline void evalTan(pfReal t, pfRVec3 &tan)  {
        PFCURVE3D->nb_evalTan(t, tan);
    }

    inline void evalNorm(pfReal t, pfRVec3 &norm)  {
        PFCURVE3D->nb_evalNorm(t, norm);
    }

    inline void evalCurv(pfReal t, pfReal *curv)  {
        PFCURVE3D->nb_evalCurv(t, curv);
    }

    inline void eval(pfReal t, pfRVec3 &pnt, pfRVec3 &tan, pfReal *curv, pfRVec3& norm)  {
        PFCURVE3D->nb_eval(t, pnt, tan, curv, norm);
    }

    inline void tessellate(pfTessellateAction *action,pfBool scaleTolByCurvature,pfReal chordalDevTol,int samples)  {
        PFCURVE3D->nb_tessellate(action, scaleTolByCurvature, chordalDevTol, samples);
    }
public:
   //CAPI:basename Curve3d
   //CAPI:updatable
   //CAPI:newargs

protected:
   // Creating and destroying
   //CAPI:private 
   pfCurve3d( );
   pfCurve3d(pfReal beginT, pfReal endT);
   //CAPI:public
   virtual ~pfCurve3d();

protected:
   pfCurve3d(pfBuffer* buf);
   pfCurve3d(const pfCurve3d* prev, pfBuffer* buf);

public:
   // per class functions
   static void init();
   static pfType* getClassType() { return classType; }

public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);

public:     // class specific sets and gets

   // Accessor functions
   void nb_setBeginT(pfReal beginT);
   void nb_setEndT(pfReal endT);
   pfReal nb_getBeginT();
   pfReal nb_getEndT();
   void nb_getBeginPt(pfRVec3& retVal);
   void nb_getEndPt(pfRVec3& retVal);
   void nb_getBeginTan(pfRVec3& retVal);
   void nb_getEndTan(pfRVec3& retVal);
   void   nb_setClosed(pfLoop loopVal);
   pfLoop nb_getClosed();
   void  nb_setClosedTol(pfReal tol);
   pfReal nb_getClosedTol();

   //CAPI:virtual
   virtual void nb_evalPt(pfReal t, pfRVec3 &pnt) = 0;
   //CAPI:virtual
   virtual void nb_evalTan(pfReal t, pfRVec3 &tan);
   //CAPI:virtual
   virtual void nb_evalNorm(pfReal t, pfRVec3 &norm);
   //CAPI:virtual
   virtual void nb_evalCurv(pfReal t, pfReal *curv);
   //CAPI:virtual
   virtual void nb_eval(pfReal t, pfRVec3 &pnt, pfRVec3 &tan, pfReal *curv, pfRVec3& norm);

   //CAPI:virtual
   virtual void nb_tessellate(pfTessellateAction *action,pfBool scaleTolByCurvature,pfReal chordalDevTol,int samples);

   pfDisCurve3d* nb_computeDiscreteCurve(pfCurve3d *cont_c,pfBool scaleTolByCurvature, int samples,pfDVector<int>& doNotDelete);
   

PFINTERNAL:


protected:
   pfReal beginT, endT;
   pfReal dt;
   pfRVec3    bPnt, ePnt;
   pfRVec3    bTan,   eTan;
   pfLoop closed;
   pfBool closedOverridden;
   pfReal closedTol;
   pfBool unevaluated;
   /*  
      Flag indicating whether the begin and end "t", position and
      tangent values have been lazily evaluated.
    */

   pfBool insideEval;
   /* 
      Flag indicating whether the call to begin/end setT is is being
      called from another member function.
      */

private:
   static pfType*      classType;
};
#endif
