 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.12 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfHsplineSurface_H
#define _pfHsplineSurface_H

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>

#define PFHSPLINESURFACE ((pfHsplineSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFHSPLINESURFACEBUFFER ((pfHsplineSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfHsplineSurface : public pfParaSurface
{
public:

    inline pfRVec3 getP(int i,int j)  {
        return PFHSPLINESURFACE->nb_getP(i, j);
    }

    inline void getP(int i,int j,pfRVec3& v)  {
        PFHSPLINESURFACE->nb_getP(i, j, v);
    }

    inline pfRVec3 getTu(int i,int j)  {
        return PFHSPLINESURFACE->nb_getTu(i, j);
    }

    inline void getTu(int i,int j,pfRVec3& v)  {
        PFHSPLINESURFACE->nb_getTu(i, j, v);
    }

    inline pfRVec3 getTv(int i,int j)  {
        return PFHSPLINESURFACE->nb_getTv(i, j);
    }

    inline void getTv(int i,int j,pfRVec3& v)  {
        PFHSPLINESURFACE->nb_getTv(i, j, v);
    }

    inline pfRVec3 getTuv(int i,int j)  {
        return PFHSPLINESURFACE->nb_getTuv(i, j);
    }

    inline void getTuv(int i,int j,pfRVec3& v)  {
        PFHSPLINESURFACE->nb_getTuv(i, j, v);
    }

    inline pfReal getUknot(int i)  {
        return PFHSPLINESURFACE->nb_getUknot(i);
    }

    inline pfReal getVknot(int j)  {
        return PFHSPLINESURFACE->nb_getVknot(j);
    }

    inline int getUknotCount()  {
        return PFHSPLINESURFACE->nb_getUknotCount();
    }

    inline int getVknotCount()  {
        return PFHSPLINESURFACE->nb_getVknotCount();
    }

    inline pfBool getCylindrical()  {
        return PFHSPLINESURFACE->nb_getCylindrical();
    }

    inline void setAll(pfReal *p,pfReal *tu,pfReal *tv,pfReal *tuv,pfReal *uu,pfReal *vv,int uKnotCount,int vKnotCount)  {
        PFHSPLINESURFACE->nb_setAll(p, tu, tv, tuv, uu, vv, uKnotCount, vKnotCount);
    }

    inline void setCylindrical(pfBool cylindrical)  {
        PFHSPLINESURFACE->nb_setCylindrical(cylindrical);
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFHSPLINESURFACE->nb_evalPt(u, v, pnt);
    }
public:
  //CAPI:basename HsplineSurface
  //CAPI:updatable
  //CAPI:newargs
   pfHsplineSurface();
   //CAPI:verb NewHsplineSurfaceWithArgs
   pfHsplineSurface(pfReal *p,pfReal *tu,pfReal *tv,pfReal *tuv,pfReal *uu,pfReal *vv,int uKnotCount,int vKnotCount);
   virtual ~pfHsplineSurface();
protected:
   pfHsplineSurface(pfBuffer *buf);
   pfHsplineSurface(const pfHsplineSurface* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();

 public:
   //CAPI:private
   pfRVec3& nb_getP(int i,int j);
   //CAPI:public
   void nb_getP(int i,int j,pfRVec3& v) { v = nb_getP(i,j); }

   // XXX Alex: change API for this 
   //CAPI:private
   pfRVec3& nb_getTu(int i,int j);
   //CAPI:public
   void nb_getTu(int i,int j,pfRVec3& v) { v = nb_getTu(i,j); }
   //CAPI:private
   pfRVec3& nb_getTv(int i,int j);
   //CAPI:public
   void nb_getTv(int i,int j,pfRVec3& v) { v = nb_getTv(i,j); }
   //CAPI:private
   pfRVec3& nb_getTuv(int i,int j);
   //CAPI:public
   void nb_getTuv(int i,int j,pfRVec3& v) { v = nb_getTuv(i,j); }
   pfReal  nb_getUknot(int i);
   pfReal  nb_getVknot(int j);
   int     nb_getUknotCount();
   int     nb_getVknotCount();
   pfBool nb_getCylindrical();
   void nb_setAll(pfReal *p,pfReal *tu,pfReal *tv,pfReal *tuv,pfReal *uu,pfReal *vv,int uKnotCount,int vKnotCount);
   void nb_setCylindrical(pfBool cylindrical);
   void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);

protected:
   // The points of the surface at the cross knot points (uu[i], vv[j]).
   pfDVector<pfDVector<pfRVec3> > p;   

   pfDVector<pfDVector<pfRVec3> > tu;  // Tangents in u  and v and points p
   // The tangents in u direction of the surface at the cross knot points (uu[i], vv[j]).
   
   pfDVector<pfDVector<pfRVec3> > tv;
   // The tangents in v direction of the surface at the cross knot points (uu[i], vv[j]).

   pfDVector<pfDVector<pfRVec3> > tuv; // The cross derivative at p
   // The cross derivatives of the surface at the cross knot points (uu[i], vv[j]).

   pfDVector<pfReal> uu; // the u knot values
   pfDVector<pfReal> vv; // the v knot values
   pfBool cylindrical; // if enabled it means that the points and derivatives 
                       // are in cylindrical coordinates


 private:
   static pfType *classType;
};

#endif
