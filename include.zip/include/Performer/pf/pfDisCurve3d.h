 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 // ####################################################################


#ifndef _PF_DISCURVE3D_H_
#define _PF_DISCURVE3D_H_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfLinMath.h>
#include <Performer/pf/pfRep.h>
#include <Performer/pf/pfDVector.h>

class pfDisCurve2d;

#define PFDISCURVE3D ((pfDisCurve3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFDISCURVE3DBUFFER ((pfDisCurve3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfDisCurve3d : public pfRep
{
public:

    inline void set(int nPoints, pfReal *points)  {
        PFDISCURVE3D->nb_set(nPoints, points);
    }

    inline pfRVec3 getBeginPt()  {
        return PFDISCURVE3D->nb_getBeginPt();
    }

    inline pfRVec3 getEndPt()  {
        return PFDISCURVE3D->nb_getEndPt();
    }

    inline pfLoop getClosed()  {
        return PFDISCURVE3D->nb_getClosed();
    }

    inline void setClosed(pfLoop c)  {
        PFDISCURVE3D->nb_setClosed(c);
    }

    inline void setPoint(int i, const pfRVec3& pnt)  {
        PFDISCURVE3D->nb_setPoint(i, pnt);
    }

    inline pfRVec3 getPoint(int i)  {
        return PFDISCURVE3D->nb_getPoint(i);
    }

    inline int getPointCount()  {
        return PFDISCURVE3D->nb_getPointCount();
    }

    inline pfRVec3 getTangent(int i)  {
        return PFDISCURVE3D->nb_getTangent(i);
    }

    inline pfRVec3 getNormal(int i)  {
        return PFDISCURVE3D->nb_getNormal(i);
    }

    inline const pfRVec3* getPointAddr(int i)  {
        return PFDISCURVE3D->nb_getPointAddr(i);
    }

    inline const pfRVec3* getTangentAddr(int i)  {
        return PFDISCURVE3D->nb_getTangentAddr(i);
    }

    inline const pfRVec3* getNormalAddr(int i)  {
        return PFDISCURVE3D->nb_getNormalAddr(i);
    }

    inline pfReal getCurvature(int i)  {
        return PFDISCURVE3D->nb_getCurvature(i);
    }

    inline void computeTangents()  {
        PFDISCURVE3D->nb_computeTangents();
    }

    inline void computeNormals()  {
        PFDISCURVE3D->nb_computeNormals();
    }

    inline void computeCurvatures()  {
        PFDISCURVE3D->nb_computeCurvatures();
    }

    inline void computeDerivatives()  {
        PFDISCURVE3D->nb_computeDerivatives();
    }
public:
  //CAPI:basename DisCurve3d
  //CAPI:updatable
  //CAPI:newargs
  pfDisCurve3d();
  //CAPI:verb NewDisCurve3dWithArgs
  pfDisCurve3d(int nPoints,pfReal *points);
  virtual ~pfDisCurve3d();

protected:
   pfDisCurve3d(pfBuffer* buf);
   pfDisCurve3d(const pfDisCurve3d* prev, pfBuffer* buf);

public:
   // per class functions
   static void init();
   static pfType* getClassType() { return classType; }

public:     // pfMemory virtual functions

PFINTERNAL:     // pfUpdatable virtual functions
   virtual void         pf_applyUpdate(const pfUpdatable *prev, int  upId);
   virtual pfUpdatable* pf_bufferClone(pfBuffer *buf);

PFINTERNAL:     // pfNode virtual functions
   virtual pfNode*  nb_clone();
   virtual int      nb_flatten(pfTraverser* trav);

PFINTERNAL:     // class specific sets and gets

   // Accessor functions
   void nb_set(int nPoints, pfReal *points);   
   //CAPI:private
   pfRVec3 nb_getBeginPt() { return p[0];}
   //CAPI:private
   pfRVec3 nb_getEndPt() { return p[p.getLen()-1];}
   //CAPI:public
   pfLoop nb_getClosed();
   void nb_setClosed(pfLoop c);
   void nb_setPoint(int i, const pfRVec3& pnt);
   //CAPI:private
   pfRVec3 nb_getPoint(int i) {return p[i];}
   //CAPI:public
   int nb_getPointCount() {return p.getLen();}
   // CAPI:private
   pfRVec3 nb_getTangent(int i) {return t[i];}
   pfRVec3 nb_getNormal(int i) {return n[i];}

  //CAPI:public
  const pfRVec3* nb_getPointAddr(int i) { return &(p(i)); }
  const pfRVec3* nb_getTangentAddr(int i) { return &(t(i)); }
  const pfRVec3* nb_getNormalAddr(int i) { return &(n(i)); }

   //CAPI:public
   pfReal nb_getCurvature(int i) {return c[i];}

   // Evaluators
   void nb_computeTangents();
   void nb_computeNormals();
   void nb_computeCurvatures();
   void nb_computeDerivatives();

   static
   void nb_chordalDecimate(pfDisCurve3d **xyz_c,pfDisCurve2d **uv_c,
			   pfDVector<int> &doNotDelete,
			   pfBool scaleTolByCurvature,
			   pfReal chordalDevTol);


public:
   pfDVector<pfRVec3>    p;         // Coordinates of curve or control hull
   pfDVector<pfRVec3>    t;         // Tangents
   pfDVector<pfRVec3>    n;         // Principal normals
   pfDVector<pfReal> c;         // Curvature 
   pfDVector<pfReal> u;         // Curve3d parameter
   pfDVector<pfReal> ds;        // Delta arc length
   pfReal               arcLength; // Integrated arc length
   pfLoop               closed;    // Last point connected to first?

private:
   static pfType*      classType;
};

#endif
