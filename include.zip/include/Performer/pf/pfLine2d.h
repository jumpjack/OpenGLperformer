 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.9 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfLine2d_h_
#define _pfLine2d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve2d.h>

#define PFLINE2D ((pfLine2d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFLINE2DBUFFER ((pfLine2d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfLine2d : public pfCurve2d
{
public:

    inline void setPoint1( pfReal x1, pfReal y1, pfReal t1)  {
        PFLINE2D->nb_setPoint1(x1, y1, t1);
    }

    inline void setPoint2( pfReal x2, pfReal y2, pfReal t2)  {
        PFLINE2D->nb_setPoint2(x2, y2, t2);
    }

    inline void getPoint1( pfReal *x1, pfReal *y1, pfReal *t1) const  {
        PFLINE2D->nb_getPoint1(x1, y1, t1);
    }

    inline void getPoint2( pfReal *x2, pfReal *y2, pfReal *t2) const  {
        PFLINE2D->nb_getPoint2(x2, y2, t2);
    }

    inline void evalPt(pfReal t,pfRVec2 &pnt)  {
        PFLINE2D->nb_evalPt(t, pnt);
    }
public:
  //CAPI:basename Line2d
  //CAPI:updatable
  //CAPI:newargs
   pfLine2d();
  //CAPI:verb NewLine2dWithArgs
   pfLine2d(pfReal x1,pfReal y1,pfReal t1,pfReal x2,pfReal y2,pfReal t2);
   virtual ~pfLine2d();
protected:
   pfLine2d(pfBuffer *buf);
   pfLine2d(const pfLine2d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

 public:
   void nb_setPoint1( pfReal x1, pfReal y1, pfReal t1);
   void nb_setPoint2( pfReal x2, pfReal y2, pfReal t2);
   void nb_getPoint1( pfReal *x1, pfReal *y1, pfReal *t1) const;
   void nb_getPoint2( pfReal *x2, pfReal *y2, pfReal *t2) const;
   //CAPI:virtual
   virtual void nb_evalPt(pfReal t,pfRVec2 &pnt);

protected:
   /*
      The origin of the parametric representation of the line, given by

        line(t) = orig + direction * t

   */
   pfRVec3 orig;

   /*
      The unnormalized direction vector of the parametric
      representation of the line, given by

        line(t) = orig + direction * t

   */
   pfRVec3 direction;

   /*
      The scale and bias applied to t so that when t = <arg t1> then
      the evaluator, <method-ref evalPt>, evaluates to <arg p1>, and
      similarly when t = <arg t2>, then the valuator evaluates to
      P2. The parametric line (i.e. ray) equation becomes:

        line(t) = orig + direction * {(t - bias)/scale}

      when scale is zero, that is <arg t1> = <arg t2>, the scale is
      ignored and the line equation becomes:

      line(t) = orig + direction * (t - bias)
   */
   pfReal scale, bias;


 private:
   static pfType *classType;
};
#endif
