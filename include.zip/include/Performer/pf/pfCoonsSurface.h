 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.8 $
// $Date: 2004/06/14 17:23:33 $

#ifndef __pfCoonsSurface_H__
#define __pfCoonsSurface_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfParaSurface.h>
#include <Performer/pf/pfCurve3d.h>

// The classical bilinear Coons patch. Again see G. Farin for a
// detailed description of a Coons patch. 

#define PFCOONSSURFACE ((pfCoonsSurface*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCOONSSURFACEBUFFER ((pfCoonsSurface*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCoonsSurface : public pfParaSurface
{
public:

    inline void setRight(pfCurve3d *right)  {
        PFCOONSSURFACE->nb_setRight(right);
    }

    inline void setLeft(pfCurve3d *left)  {
        PFCOONSSURFACE->nb_setLeft(left);
    }

    inline void setBottom(pfCurve3d *bottom)  {
        PFCOONSSURFACE->nb_setBottom(bottom);
    }

    inline void setTop(pfCurve3d *top)  {
        PFCOONSSURFACE->nb_setTop(top);
    }

    inline pfCurve3d* getTop() const  {
        return PFCOONSSURFACE->nb_getTop();
    }

    inline pfCurve3d* getBottom() const  {
        return PFCOONSSURFACE->nb_getBottom();
    }

    inline pfCurve3d* getLeft() const  {
        return PFCOONSSURFACE->nb_getLeft();
    }

    inline pfCurve3d* getRight() const  {
        return PFCOONSSURFACE->nb_getRight();
    }

    inline void evalPt(pfReal u,pfReal v,pfRVec3 &pnt)  {
        PFCOONSSURFACE->nb_evalPt(u, v, pnt);
    }
public:
  //CAPI:basename CoonsSurface
  //CAPI:updatable
  //CAPI:newargs
  pfCoonsSurface();
  //CAPI:verb NewCoonsSurfaceWithArgs
  pfCoonsSurface(pfCurve3d *right,pfCurve3d *left,pfCurve3d *bottom,pfCurve3d *top);
  virtual ~pfCoonsSurface( );

protected:
  pfCoonsSurface(pfBuffer *buf);
  pfCoonsSurface(const pfCoonsSurface* prev,pfBuffer *buf);

public:
  static pfType* getClassType() { return classType; }
  static void init();

PFINTERNAL:
  virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
  virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();

public:

   void nb_setRight(pfCurve3d *right);
   void nb_setLeft(pfCurve3d *left);
   void nb_setBottom(pfCurve3d *bottom);
   void nb_setTop(pfCurve3d *top);
   pfCurve3d* nb_getTop() const;
   pfCurve3d* nb_getBottom() const;
   pfCurve3d* nb_getLeft() const;
   pfCurve3d* nb_getRight() const;
   //CAPI:virtual
   void nb_evalPt(pfReal u,pfReal v,pfRVec3 &pnt);
private:
   pfCurve3d  *right, *left, *top, *bottom;
   
   pfReal      rightTRange,  rightStartT;
   pfReal      leftTRange,   leftStartT;
   pfReal      topTRange,    topStartT;
   pfReal      bottomTRange, bottomStartT;

   pfRVec3      p00, p01, p10, p11;
   pfBool dirty, defined;


 private:
   static pfType *classType;
};
#endif
