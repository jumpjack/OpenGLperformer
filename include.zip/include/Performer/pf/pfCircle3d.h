 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.10 $
// $Date: 2004/06/14 17:23:33 $

#ifndef _pfCircle3d_h_
#define _pfCircle3d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfCurve3d.h>

#define PFCIRCLE3D ((pfCircle3d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCIRCLE3DBUFFER ((pfCircle3d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCircle3d : public pfCurve3d
{   
public:

    inline void setRadius(pfReal radius)  {
        PFCIRCLE3D->nb_setRadius(radius);
    }

    inline pfReal getRadius() const  {
        return PFCIRCLE3D->nb_getRadius();
    }

    inline void evalPt(pfReal t,pfRVec3 &pnt)  {
        PFCIRCLE3D->nb_evalPt(t, pnt);
    }

    inline void evalTan(pfReal t,pfRVec3 &tan)  {
        PFCIRCLE3D->nb_evalTan(t, tan);
    }

    inline void evalCurv(pfReal t,pfReal *curv)  {
        PFCIRCLE3D->nb_evalCurv(t, curv);
    }

    inline void evalNorm(pfReal t,pfRVec3 &norm)  {
        PFCIRCLE3D->nb_evalNorm(t, norm);
    }

    inline void eval(pfReal t,pfRVec3 &pnt,pfRVec3 &tan,pfReal *curv,pfRVec3& norm)  {
        PFCIRCLE3D->nb_eval(t, pnt, tan, curv, norm);
    }
public:
  //CAPI:basename Circle3d
  //CAPI:updatable
  //CAPI:newargs
   pfCircle3d();

  //CAPI:verb NewCircle3dWithArgs
   pfCircle3d(pfReal rad,pfRVec3 *org);
  //CAPI:public

   virtual ~pfCircle3d();

protected:
   pfCircle3d(pfBuffer *buf);
   pfCircle3d(const pfCircle3d* prev,pfBuffer *buf);

public:
   static pfType* getClassType() { return classType; }
   static void init();

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:

   void nb_setRadius(pfReal radius);
   pfReal nb_getRadius() const;

   void nb_evalPt(pfReal t,pfRVec3 &pnt);
   void nb_evalTan(pfReal t,pfRVec3 &tan);
   void nb_evalCurv(pfReal t,pfReal *curv);
   void nb_evalNorm(pfReal t,pfRVec3 &norm);

   //CAPI:verb Circle3dEvalAll
   void nb_eval(pfReal t,pfRVec3 &pnt,pfRVec3 &tan,pfReal *curv,pfRVec3& norm);

protected:
   pfReal radius;

   pfReal curvature;
   //  The curvature which is equal to 1/radius. It is a cached value.

   pfReal lastT;
   // Caches the previously evaluated t for evaluation efficiency.

   pfReal sine, cosine;
   // Caches the previously evaluated r*sin(t) and r*cos(t) for evaluation efficiency.


private:
  static pfType *classType;

};
#endif
