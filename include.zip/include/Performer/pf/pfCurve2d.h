 //
 // Copyright 1996,1997,1998 Silicon Graphics, Inc.
 // ALL RIGHTS RESERVED
 //
 // UNPUBLISHED -- Rights reserved under the copyright laws of the United
 // States.   Use of a copyright notice is precautionary only and does not
 // imply publication or disclosure.
 //
 // U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
 // Use, duplication or disclosure by the Government is subject to restrictions
 // as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
 // in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
 // in similar or successor clauses in the FAR, or the DOD or NASA FAR
 // Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
 // 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
 //
 // THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
 // INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
 // DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
 // PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
 // GRAPHICS, INC.
 //
 // ####################################################################



// $Revision: 1.13 $
// $Date: 2004/06/14 17:23:33 $

#ifndef __pfCurve2d_h_
#define __pfCurve2d_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pf/pfRep.h>
#include <Performer/pf/pfDVector.h>

class pfParaSurface;

#define PFCURVE2D ((pfCurve2d*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFCURVE2DBUFFER ((pfCurve2d*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfCurve2d : public pfRep
{
public:

    inline void setBeginT(const pfReal beginT)  {
        PFCURVE2D->nb_setBeginT(beginT);
    }

    inline void setEndT(const pfReal endT)  {
        PFCURVE2D->nb_setEndT(endT);
    }

    inline pfReal getBeginT() const  {
        return PFCURVE2D->nb_getBeginT();
    }

    inline pfReal getEndT() const  {
        return PFCURVE2D->nb_getEndT();
    }

    inline pfRVec2 getBeginPt()  {
        return PFCURVE2D->nb_getBeginPt();
    }

    inline pfRVec2 getEndPt()  {
        return PFCURVE2D->nb_getEndPt();
    }

    inline pfRVec2 getBeginTan()  {
        return PFCURVE2D->nb_getBeginTan();
    }

    inline pfRVec2 getEndTan()  {
        return PFCURVE2D->nb_getEndTan();
    }

    inline void setClosed(const pfLoop loopVal)  {
        PFCURVE2D->nb_setClosed(loopVal);
    }

    inline pfLoop getClosed()  {
        return PFCURVE2D->nb_getClosed();
    }

    inline void setClosedTol(const pfReal tol)  {
        PFCURVE2D->nb_setClosedTol(tol);
    }

    inline pfReal getClosedTol() const  {
        return PFCURVE2D->nb_getClosedTol();
    }

    inline void evalPt(pfReal t,pfRVec2 &pnt)  {
        PFCURVE2D->nb_evalPt(t, pnt);
    }

    inline void evalTan(pfReal t,pfRVec2 &tan)  {
        PFCURVE2D->nb_evalTan(t, tan);
    }

    inline void evalNorm(pfReal t,pfRVec2 &norm)  {
        PFCURVE2D->nb_evalNorm(t, norm);
    }

    inline void evalCurv(pfReal t,pfReal* curv)  {
        PFCURVE2D->nb_evalCurv(t, curv);
    }

    inline void eval(pfReal t,pfRVec2 &pnt,pfRVec2 &tan,pfReal *curv,pfRVec2 &norm)  {
        PFCURVE2D->nb_eval(t, pnt, tan, curv, norm);
    }

    inline pfReal getBreakPoints(int i)  {
        return PFCURVE2D->nb_getBreakPoints(i);
    }

    inline pfRVec3* getBreakPointsXYZ(int i)  {
        return PFCURVE2D->nb_getBreakPointsXYZ(i);
    }

    inline int getBreakPointsSize()  {
        return PFCURVE2D->nb_getBreakPointsSize();
    }

    inline pfReal getSamplePoints(int i)  {
        return PFCURVE2D->nb_getSamplePoints(i);
    }

    inline pfRVec3* getSamplePointsXYZ(int i)  {
        return PFCURVE2D->nb_getSamplePointsXYZ(i);
    }

    inline int getSamplePointsSize()  {
        return PFCURVE2D->nb_getSamplePointsSize();
    }

    inline void getBoxBound(pfBox &retBox)  {
        PFCURVE2D->nb_getBoxBound(retBox);
    }

    inline void setBoxBound(const pfBox &newBox)  {
        PFCURVE2D->nb_setBoxBound(newBox);
    }

    inline void evalBreakPoints(pfParaSurface *sur)  {
        PFCURVE2D->nb_evalBreakPoints(sur);
    }

    inline void updateBreakPoints(pfParaSurface *sur)  {
        PFCURVE2D->nb_updateBreakPoints(sur);
    }

    inline void computeBox3d(pfParaSurface *sur)  {
        PFCURVE2D->nb_computeBox3d(sur);
    }

    inline void updateBox3d(pfParaSurface *sur)  {
        PFCURVE2D->nb_updateBox3d(sur);
    }

    inline void cleanUpCacheSpace()  {
        PFCURVE2D->nb_cleanUpCacheSpace();
    }
public:
  //CAPI:basename Curve2d
  //CAPI:updatable
  //CAPI:newargs
protected:

   //CAPI:private
   pfCurve2d();
   pfCurve2d(pfReal beginT,pfReal endT);
   //CAPI:public
   virtual ~pfCurve2d();

protected:
   pfCurve2d(pfBuffer *buf);
   pfCurve2d(const pfCurve2d* prev,pfBuffer *buf);


public:
   static void init();
   static pfType* getClassType() { return classType; }

PFINTERNAL:
   virtual void pf_applyUpdate(const pfUpdatable *prev,int upId);
   virtual pfUpdatable *pf_bufferClone(pfBuffer *buf);

PFINTERNAL:
   virtual pfNode *nb_clone();
   virtual int nb_flatten(pfTraverser *);

public:
   

   // <subsection Accessor functions>
   void nb_setBeginT(const pfReal beginT);
   void nb_setEndT(const pfReal endT);
   pfReal nb_getBeginT() const;
   pfReal nb_getEndT() const;

   //CAPI:private
   pfRVec2 nb_getBeginPt();

   //CAPI:private
   pfRVec2 nb_getEndPt();

   //CAPI:private
   pfRVec2 nb_getBeginTan();

   //CAPI:private
   pfRVec2 nb_getEndTan();

   //CAPI:public
   void   nb_setClosed(const pfLoop loopVal);
   pfLoop nb_getClosed();

   void  nb_setClosedTol(const pfReal tol);
   pfReal nb_getClosedTol() const;

   // <subsection Evaluators>
   //CAPI:virtual
   virtual void nb_evalPt(pfReal t,pfRVec2 &pnt) = 0;

   //CAPI:virtual
   virtual void nb_evalTan(pfReal t,pfRVec2 &tan);

   //CAPI:virtual
   virtual void nb_evalNorm(pfReal t,pfRVec2 &norm);

   //CAPI:virtual
   virtual void nb_evalCurv(pfReal t,pfReal* curv);

   //CAPI:public
   //CAPI:virtual
   //CAPI:verb Curve2dEvalAll
   virtual void nb_eval(pfReal t,pfRVec2 &pnt,pfRVec2 &tan,pfReal *curv,pfRVec2 &norm);

   // XXX Alex -- don't expose this stuff.
   //CAPI:private
   pfReal  nb_getBreakPoints(int i);
   pfRVec3* nb_getBreakPointsXYZ(int i);
   int     nb_getBreakPointsSize();
   pfReal  nb_getSamplePoints(int i);
   pfRVec3* nb_getSamplePointsXYZ(int i);
   int     nb_getSamplePointsSize();
   void nb_getBoxBound(pfBox &retBox);
   void nb_setBoxBound(const pfBox &newBox);
   virtual void nb_evalBreakPoints(pfParaSurface *sur);
   void nb_updateBreakPoints(pfParaSurface *sur);
   void nb_computeBox3d(pfParaSurface *sur); //3d box and sample points
   void nb_updateBox3d(pfParaSurface *sur);
   void nb_cleanUpCacheSpace();

   
protected:
   pfReal  beginT, endT;
   // Current parametric end point values of the curve.

   pfReal  dt;
   /*
      Value used to to compute differences. Given by:

      dt = (beginT - endT) * pfRep::functionTol * 10.0

      The reason for 10.0 * functionTol is to reduce
      the numerical error of  the 2nd order calculation.  
      funtionTol is about 1.49e-8 for double precision and
      4.88e-4 for single precision.
   */

   pfRVec2  bPnt, ePnt;
   // Current positional values of the end points of the curve.

   pfRVec2  bTan,   eTan;
   // Current tangent values of the end points of the curve.

   pfLoop closed;
   // State of the curve's end point disposition. One of {PFLOOP_OPEN,
   // PFLOOP_CLOSED, PFLOOP_PERIODIC}.

   int closedOverridden;
   /*
     State of the closed value.  The closed curve value is in
     overridden state once it has been set using the 
     ::setClosed method. This override state remains in effect
     until the curve is deleted. Thus subsequent changes in the end
     points have no effect on the closed state of the curve.
   */

   pfReal  closedTol;
   // The tolerance set by ::setClosedTol() by default it is
   // pfRep::subtractiveTol.

   int unevaluated;
   // Flag indicating whether the begin and end "t", position and
   // tangent values have been lazily evaluated.

   int insideEval;
   // Flag indicating whether the call to begin/end setT is is being
   // called from another member function.

   //<subsection Members for topology construction> -- used internally
   pfDVector<pfReal>  breakPoints;
   pfDVector<pfRVec3>  breakPointsXYZ;
   pfDVector<pfReal> *samplePointsPtr;
   pfDVector<pfRVec3> *samplePointsXYZPtr;
   pfBox box;

private:
   static pfType *classType;
};
#endif

