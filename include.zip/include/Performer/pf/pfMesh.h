//
// Copyright 2003, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfMesh.h
//

#ifndef _pf_mesh_h_
#define _pf_mesh_h_

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr.h>
#include <Performer/pr/pfGeoState.h>
#include <Performer/pr/pfGeoSet.h>

#include <Performer/pf.h>
#include <Performer/pf/pfNode.h>
#include <Performer/pf/pfGeode.h>
#include <Performer/pf/pfGroup.h>
#include <Performer/pf/pfSwitch.h>
#include <Performer/pf/pfSCS.h>
#include <Performer/pf/pfDoubleSCS.h>
#include <Performer/pf/pfDCS.h>
#include <Performer/pf/pfDoubleDCS.h>
#include <Performer/pf/pfLOD.h>
#include <Performer/pf/pfSequence.h>


extern "C" {

/* pfMeshVertex flags */
#define PFMV_FLAG_VERTEX_CHANGED            (1<<0)
#define PFMV_FLAG_VERTEX_NEIGHBOR_CHANGED   (1<<1)
#define PFMV_FLAG_VERTEX_FACE_CHANGED       (1<<2)
#define PFMV_FLAG_VERTEX_SPLIT              (1<<3) /* when surface around the
						      vertex is not manifold */

/* pfMeshFace flags */
#define PFMF_FLAG_FACE_CHANGED              (1<<0)

/***** pfMesh FLAGS *****/
/* if PFM_FLAG_TRIANGULATE is set all geometry in addPart is triangulated
   (quads, polys). Used for Loop subdivision, for example. Off by default. */
#define PFM_FLAG_TRIANGULATE                (1<<0) 
    
/* if PFM_FLAG_TEST_ORIENTATION is set the normal at the first vertex is
   compared with the triangle normal and if they point to opposite directions
   the order of vertices is changed */
#define PFM_FLAG_TEST_ORIENTATION           (1<<1) 

/* automatically mark edges between different parts as creases. On by default.
 */
#define PFM_FLAG_CREASES_BETWEEN_PARTS      (1<<2)

/* automatically mark edges between geosets with different geostates. 
   On by default. */
#define PFM_FLAG_CREASES_BETWEEN_GEOSTATES  (1<<3)

/* if PFM_FLAG_QUAD_TSTRIPS is set triangle strips in addPart are converted
   to quads, even if the quads are not planar. Off by default. */
#define PFM_FLAG_QUAD_TSTRIPS               (1<<4) 

#define PFM_FLAG_SORT_BY_GEOSTATE           (1<<5) 

/* use grid when adding faces and checking for existing vertices */
#define PFM_FLAG_USE_VERTEX_GRID            (1<<6)

/* reverses the order of vertices inside addTriangle and addFace */
#define PFM_FLAG_REVERSE_ORDER              (1<<7) 



/***** VALUES *****/
#define PFM_EPSILON         0  /* index to setVal, used to compare vertices */
#define PFM_VERTEX_GRID_SIZE_X  1  /* index to setVal, used for vertex grid */
#define PFM_VERTEX_GRID_SIZE_Y  2 
#define PFM_VERTEX_GRID_SIZE_Z  3 
#define PFM_VERTEX_GRID_SIZE    4  /* sets x,y,z at once */ 

/**************************************************/
#define PFM_VERTEX_NORMAL   0  // smooth
#define PFM_VERTEX_DART     1  // only one crease at this vertex
#define PFM_VERTEX_CREASE   2  // two creases/boundaries
#define PFM_VERTEX_IRREGULAR_CREASE   3  // two creases/boundaries
#define PFM_VERTEX_CORNER   4  // more than two creases/boundaries two corner
#define PFM_VERTEX_CONICAL  5  // conical 
#define PFM_VERTEX_SPLIT    6  // conical 
#define PFM_VERTEX_MAX      7  // value above all others

#define PFM_EDGE_CREASE     3  // must be > 2 
#define PFM_EDGE_BOUNDARY   4
#define PFM_EDGE_SPLIT      5  // split edge - behaves as a crease or boundary
#define PFM_EDGE_NORMAL     6  // must be highest of all edge types
#define PFM_EDGE_MAX        7  // value above all others

}

/* pfMeshVertexNeighbor is defined in pf.h (XXX make it a class as well?) */

//XXX make sure these structures are visible in C api
typedef _pfTemplateList<int>    _pfIntListT; // better than _pfIntList
typedef _pfTemplateList<pfVec2> _pfVec2ListT; 

typedef _pfTemplateList<pfMeshVertexNeighbor> _pfMeshVertexNeighborListT; 

struct pfMeshPointList
{
    int    index;
    struct pfMeshPointList *next;
};
typedef struct pfMeshPointList pfPointListType;

class DLLEXPORT pfMeshVertex;

/*****************************************************/
class DLLEXPORT pfMeshVertex
{
 private: 
    pfVec3   coord; 
    pfVec3   *coordptr; /* so that we can access the original coords if the 
			   user changes them */
    int      flags;

    int      next;     /* links split vertices together */

    //XXX voidlist of additional parameters
   
 public:
    _pfMeshVertexNeighborListT neighbors; 

    void    setCoord(pfVec3 *v) { coord = *v; }
    pfVec3  *getCoord(void) { return &coord; }

    void    setCoordPtr(pfVec3 *v) { coordptr = v; }
    pfVec3  *getCoordPtr(void)  { return coordptr; }

    void    setNextVertex(int v) { next = v; }
    int     getNextVertex(void)  { return next; }

    void setNumNeighbors(int n) {  neighbors.setNum(n); }
    int  getNumNeighbors(void) { return neighbors.getNum(); }
    
    //CAPI:verb MeshVertexSetNeighbor
    void setNeighbor(int i, pfMeshVertexNeighbor *n);

    //CAPI:verb GetMeshVertexNeighbor
    pfMeshVertexNeighbor *getNeighbor(int i) { return &neighbors[i]; }  //no out-of-scope check

    //CAPI:private
    pfMeshVertexNeighbor *replaceNeighbor(int v1, int face1, int face2, int v, _pfMeshVertexNeighborListT *nbrs);

    //CAPI:public
    pfMeshVertexNeighbor *getPreviousNeighbor(int v1); 
    int getPreviousNeighborIndex(int v1); 

    pfMeshVertexNeighbor *getNextNeighbor(int v1); 
    int getNextNeighborIndex(int v1); 

    void setFlags(int which, int value)
    {
	if(value)
	    flags = flags | which;
	else
	    flags = (flags & ~which);
    }

    //CAPI:verb GetMeshVertexFlags
    int  getFlags(int which) { return (flags & which); }
};


/*****************************************************/
class DLLEXPORT pfMeshFace 
{
 private:
    int         part;
    pfGeoState  *gstate;
    int         flags;

 public:
    _pfIntListT  verts;
    _pfVec2ListT texCoords;

     void setPart(int p) { part = p;}
    int  getPart(void)  { return part; }

    void setGState(pfGeoState *g) { gstate = g;}
    pfGeoState *getGState(void)  { return gstate; }

    void setNumVerts(int n) { verts.setNum(n);}
    int  getNumVerts(void)  { return verts.getNum(); }

    void setVertex(int i, int v) {  verts.set(i, v); }
    int  getVertex(int i) { return verts[i]; }      //no out-of-scope check

    void   setTexCoord(int i, pfVec2 *v) { texCoords.set(i, *v); }
    pfVec2 *getTexCoord(int i) { return &(texCoords[i]); } //no out-of-scope check

    void setVerts(int *v, int n) 
    { 
	int i; 
	verts.setNum(n);
	for(i=0; i<n; i++) verts.set(i, v[i]);
    }
    int getVerts(int *v, int size)  
    { 
	int i;
	for(i=0; i<verts.getNum(); i++) 
	{
	    if(i==size)
	    {
		pfNotify(PFNFY_WARN, PFNFY_PRINT,
			 "pfMeshFace::getVerts() - increase size of array.");
		break;
	    }
	    v[i] = verts[i];
	}

	return verts.getNum(); 
    }

    void setFlags(int which, int value)
    {
	if(value)
	    flags = flags | which;
	else
	    flags = (flags & ~which);
    }

    int  getFlags(int which) { return (flags & which); }

};

/*****************************************************/
#define PFMESH ((pfMesh*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFMESHBUFFER ((pfMesh*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfMesh : public pfObject
{
 private: 
    int          flags;

    _pfVoidList	 gsetList;	// List of pfGeoSets

    pfMeshVertex *vertices;
    int          vertArraySize;
    int          numVerts;

    pfMeshFace   *faces;
    int          faceArraySize;
    int          numFaces;

    pfBox        bbox;
    pfSphere     bsphere;       // used for positioning the grid
    pfMeshPointList **grid;
    int          xs, ys, zs;    // grid size in x, y, and z coordinates
    float        gridScale, invGridScale;

    float        epsilon;   // used to compare vertices

    short int determineEdgeType(int face1, int face2);
    int  AddFace(int num, int *verts, int part, pfGeoState *gstate);
    int  AddVertex(pfVec3 *v, pfMatrix *xform, int check);
    int  AddFaceToVertex(int face, int v, int v1, int v2);

 public:

    pfMesh();
    ~pfMesh();

    void setFlags(int which, int value);
    int  getFlags(int which);

    void setVal(int which, float  val);
    void getVal(int which, float *val);
    void setAttr(int which, void *attr);
    void getAttr(int which, void **attr);

    int getNumVertices(void) 
    { 
        return numVerts;
    }

    void setNumVertices(int num);

    pfMeshVertex *getVertex(int i) 
    { 
	return &vertices[i];
    }

    pfVec3 *getVertexCoords(int i) 
    { 
	return vertices[i].getCoord();
    }

    int getEdgeType(int v, int v1); 


    int getNumFaces(void) 
    { 
        return numFaces;
    }
    void setNumFaces(int num);

    void addGeoSet(pfGeoSet *gset, int currentPart, pfMatrix *xform);
    //XXX getNumGeoSets getGeoSet??

    int  addTriangle(pfVec3 *v1, pfVec3 *v2, pfVec3 *v3, pfMatrix *xform, int part, pfGeoState *gstate);
    int  addFace(pfVec3 **verts, int num, pfMatrix *xform, int part, pfGeoState *gstate);

    void getTriangle(int t, int *v1, int *v2, int *v3) 
    { 
        *v1 = faces[t].getVertex(0);
        *v2 = faces[t].getVertex(1);
        *v3 = faces[t].getVertex(2);
	    
	// print warning if face does not have 3 vertices
	if(faces[t].getNumVerts() != 3)
	    pfNotify(PFNFY_WARN, PFNFY_PRINT,
		     "pfMesh::getTriangle() - face %d has %d vertices. ",
		     t, faces[t].getNumVerts());
    }

    pfMeshFace *getFace(int t) 
    { 
	return &faces[t];
    }

    pfBox *getBBox(void) { return &bbox;}
    void   setBBox(pfBox *b) { bbox = *b;}

    pfSphere *getGridBsphere(void) { return &bsphere;}
    void   setGridBsphere(pfSphere *b) { bsphere = *b;}

    void splitVertex(int vbegin, int vend);
    void splitVertices(void);  // splits non-manifold vertices
    void updateMesh(void); // updates CHANGED flags on vertices and faces
};

#endif
