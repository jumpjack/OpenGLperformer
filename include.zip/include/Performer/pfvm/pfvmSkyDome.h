/*
 * Copyright 2002, Silicon Graphics, Inc.
 * ALL RIGHTS RESERVED
 *
 * This source code ("Source Code") was originally derived from a
 * code base owned by Silicon Graphics, Inc. ("SGI")
 * 
 * LICENSE: SGI grants the user ("Licensee") permission to reproduce,
 * distribute, and create derivative works from this Source Code,
 * provided that: (1) the user reproduces this entire notice within
 * both source and binary format redistributions and any accompanying
 * materials such as documentation in printed or electronic format;
 * (2) the Source Code is not to be used, or ported or modified for
 * use, except in conjunction with OpenGL Performer; and (3) the
 * names of Silicon Graphics, Inc.  and SGI may not be used in any
 * advertising or publicity relating to the Source Code without the
 * prior written permission of SGI.  No further license or permission
 * may be inferred or deemed or construed to exist with regard to the
 * Source Code or the code base of which it forms a part. All rights
 * not expressly granted are reserved.
 * 
 * This Source Code is provided to Licensee AS IS, without any
 * warranty of any kind, either express, implied, or statutory,
 * including, but not limited to, any warranty that the Source Code
 * will conform to specifications, any implied warranties of
 * merchantability, fitness for a particular purpose, and freedom
 * from infringement, and any warranty that the documentation will
 * conform to the program, or any warranty that the Source Code will
 * be error free.
 * 
 * IN NO EVENT WILL SGI BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT
 * LIMITED TO DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES,
 * ARISING OUT OF, RESULTING FROM, OR IN ANY WAY CONNECTED WITH THE
 * SOURCE CODE, WHETHER OR NOT BASED UPON WARRANTY, CONTRACT, TORT OR
 * OTHERWISE, WHETHER OR NOT INJURY WAS SUSTAINED BY PERSONS OR
 * PROPERTY OR OTHERWISE, AND WHETHER OR NOT LOSS WAS SUSTAINED FROM,
 * OR AROSE OUT OF USE OR RESULTS FROM USE OF, OR LACK OF ABILITY TO
 * USE, THE SOURCE CODE.
 * 
 * Contact information:  Silicon Graphics, Inc., 
 * 1600 Amphitheatre Pkwy, Mountain View, CA  94043, 
 * or:  http://www.sgi.com
*/


#ifndef __PFV_ESKY_H__
#define __PFV_ESKY_H__

///////////////////////////////////////////////////////////////////////////////

#include <Performer/pfv/pfvViewer.h>
#include <Performer/pf/pfEarthSky.h> 

///////////////////////////////////////////////////////////////////////////////

class pfvXmlNode;

///////////////////////////////////////////////////////////////////////////////

#define PFES_DEPTH_INIT 1
#define PFES_DEPTH_OFF  0

#define PFES_SKY_MID    1312

// sorted by light intensity
#define TODNIGHT        0
#define TODASTRODAWN    1
#define TODASTRODUSK    2
#define TODNAUTIDAWN    3
#define TODNAUTIDUSK    4
#define TODCIVILDAWN    5
#define TODCIVILDUSK    6
#define TODDAWN         7
#define TODDUSK         8
#define TODDAY          9

#define TODLIGHTSWITCH  TODNAUTIDAWN    // turn sunlight off if less
#define TODSHADSWITCH   TODDAWN         // turn shadow off if less

#define TODSTARSWITCHVAL    0.9f
#define TOTAL_HORIZ_ANGLE   36.0f

///////////////////////////////////////////////////////////////////////////////

class pfvmSkyDome : public pfvModule
{
public:	
    pfvmSkyDome( pfvXmlNode* xml=NULL);
    ~pfvmSkyDome() {}

    static void init();
    static pfType* getClassType(){ return classType; }
    virtual const char* getTypeName() const {return "pfvmSkyDome";}

    /*int parseXml(pfvXmlNode*xml);*/
    int setXmlField(pfvXmlNode*xml);

    void postConfig();
    void enterView(pfvView*v);
    void exitView(pfvView*v);
    void sync();
    void preDraw(pfvDispChan *chan);
    int handleEvent(int evType, char key);

    pfEarthSky* getESky() { return esky; }
    
    void calcSunPos(uint seconds, pfVec4 &pos);
    void updateTimeOfDay(time_t dateTime);
	
protected:
    static pfType* classType;
	
private:

    void construct();
    void setColor(int which, pfvXmlNode* xml, int index);
    void setColor(int which, float r, float g, float b, int index);
    void setColor(int which, pfVec3 col, int index);
    void setHoriz(float angle, int index);
   
    static pfNode *stars;

    pfEarthSky* esky;
    pfGeoSet *starGset;
    pfGeoState *starGstate;
    pfGeoState *tentGstate;

    int clearMode;
    int drawStars;
    int drawGrid;
    int depthMode;
    int computeTodColors;

    int gridSize;
    int gridStep;
    
    pfVec3  skyTop;	    // coordinates
    pfVec3  skyMid[16];
    pfVec3  skyBot[16];
    pfVec3  grndFar[16];
    pfVec3  grndNear;

    pfVec3  skyTopCol;	    // colors
    pfVec3  skyMidCol[16];
    pfVec3  skyBotCol[16];
    pfVec3  horizCol[16];
    pfVec3  grndFarCol[16];
    pfVec3  grndNearCol;
    pfVec4  clearCol;
    pfVec4  gridCol;

    float   grndHt;
    float   horizAngle[16];
    float   starAngle;
    float   starTransp;
    float   farDist;
    
    float   longitude;      // Longitude and Latitude define the point
    float   latitude;       // on our earth used for lighting computations
    float   elevation;      // in meter

    int     ToDState;           
    time_t  ToDDateTime;    // UNIX time
    time_t  lastDateTime;
    int     timeOffset;
    int     starVisible;

    pfVec4  west12Normal;   // nautical twilight
    pfVec4  midl00Normal;   // also used for shadow computations
    pfVec4  east12Normal;   // nautical twilight
    
    // colors used for tod computations
    pfVec3  skyCol;
    pfVec3  grndCol;
    pfVec3  niteskyCol;
    pfVec3  a_twilightCol;
    pfVec3  n_twilightCol;
    pfVec3  c_twilightCol;
    pfVec3  redSunCol;
    pfVec3  yellowSunCol;
    pfVec3  horizonCol;

    float   timeWarp;	    // update start within starAngle updates
    double  lastAngleUpdate;
};

///////////////////////////////////////////////////////////////////////////////

#endif // end of __PFV_ESKY_H__






