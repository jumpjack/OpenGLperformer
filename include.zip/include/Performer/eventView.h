#ifndef	__EVENTOR_H__
#define	__EVENTOR_H__

#ifndef	WIN32
#include <sys/time.h>
#else
#include <windows.h>
#endif

#ifndef WIN32
#include <inttypes.h>
#else
#include <wintypes.h>
#endif

#ifdef __LOCAL_BUILD__
#include "pfDLL.h"
#else
#include <Performer/pfDLL.h>
#endif

/*
 *	data types and constants
 */

enum
{
	EV_VER0_9,
	EV_VER1_0,
	EV_VER1_1,
	EV_VER1_2
};

#define	EVMAGIC_VER1_0			0x0250
#define	EVMAGIC_VER1_1			0x0251
#define	EVMAGIC_VER1_2			0x0252
#define	EVMAGIC					EVMAGIC_VER1_2

#define	EVTYPE_GRAPHIC			0x00000001
#define	EVTYPE_GRAPHIC_PROF		0x00000002
#define	EVTYPE_FRAME			0x00000004

#define	EVDBG_MODE_PIPEFLUSH	0x00000001
#define	EVDBG_MODE_GLPROF		0x00000002
#define	EVDBG_MODE_GLDEBUG		0x00000004

#define	EVGL_IRISGL				1
#define	EVGL_OPENGL				2

typedef void *(*evMallocFunc) (size_t);
typedef void (*evFreeFunc) (void*);

typedef	struct timeval	TIMEVAL;


enum
{
	EV_ITYPE_INT,
	EV_ITYPE_FLOAT,
	EV_ITYPE_ENUM
};


/*
 *	Old disk structures
 */
typedef struct
{
	int			eventClass;
	TIMEVAL		start, end;
} evEvent_DiskV1_0;

typedef struct
{
	char		*name;
	int			fractionSize;
} evInfo_DiskV1_1;

/*
 *	Data types
 */
typedef struct
{
	TIMEVAL		start, end;
	int			eventClass;
	int			pid;

	int			*info;
} evEvent;

typedef struct _evInfo
{
	char		*name;
	int			fractionSize;
	int			type;
	int			enumId;
} evInfo;

typedef struct evClassData
{

	char		*name;
	int			type;

	short		groupLevel;
	uint64_t	groupMask;

	int			infoSize;

	evInfo		*infoDescription;
} evClassData;

typedef struct
{
	char		*name;

	int			nitems;
	char		**items;
} evEnum;

typedef struct
{
	char		*name;
	int			from, to;
} evRange;

typedef struct
{
	int			pid;
	char		*name;
} evProcess;

typedef struct
{
	uint64_t	mask;
	char		*name;
	int			initState;
} evGroup;

typedef struct evEventList
{
	char				*name;

	int 					maxEvents;

	/*
	 *	 unsigned long because test_then_add expects one.
	 */
	uint32_t			numEvents;

	int					maxClasses;

	int					numEnums;
	int					numRanges;
	int					numProcesses;
	int					numGroups;


	int					lock;
	evEvent				**openEvents;

	evClassData			*classData;

	evEvent				*events;

	evEnum				*enums;

	evRange				*ranges;
	evProcess			*procs;
	evGroup				*groups;

	void				*userData;
} evEventList;

/*
 *	prototypes
 */

#ifdef __cplusplus
extern "C" 
{
#endif


DLLEXPORT void evSetMallocFunc (evMallocFunc func);
DLLEXPORT void evSetFreeFunc (evFreeFunc func);
DLLEXPORT int evGetMyId (void);
DLLEXPORT void evRegisterList (evEventList *list);
DLLEXPORT evEventList *evCreateList (int maxEvents, int maxClasses);
DLLEXPORT void evListName (evEventList *list, char *name);
DLLEXPORT void evFreeList (evEventList *list);
DLLEXPORT void evClearList (evEventList *list);
DLLEXPORT void evClearAll (evEventList *list);
DLLEXPORT void evClearAllLists();

DLLEXPORT void evClassName (evEventList *list, int eventClass, char *name);
DLLEXPORT void evClassType (evEventList *list, int eventClass, int type);
DLLEXPORT void evClassGroupMask (evEventList *list, int eventClass, uint64_t mask);
DLLEXPORT void evClassGroupLevel (evEventList *list, int eventClass, int groupLevel);
DLLEXPORT void evClassGroupName (evEventList *list, int eventClass, char *name);
DLLEXPORT void evClassInfoSize (evEventList *list, int eventClass, int info_size);
DLLEXPORT void evInfoDescription (evEventList *list, int eventClass, 
							int info, char *name, int fractionSize);
DLLEXPORT void evInfoType (evEventList *list, int eventClass, int info, int type);
DLLEXPORT void evInfoName (evEventList *list, int eventClass, int info, char *name);
DLLEXPORT void evInfoFraction (evEventList *list, int eventClass,
					int info, int fractionSize);
DLLEXPORT void evInfoEnum (evEventList *list, int eventClass, int info, char *name);

DLLEXPORT void evSetEnum (evEventList *list, char *name, int nitems, char **items);

DLLEXPORT void evSetProc (evEventList *list, int _pid, char *name);

DLLEXPORT void evSetGroup (evEventList *list, uint64_t mask, char *name, int initState);
DLLEXPORT int evGetGroupId (evEventList *list, char *name);

DLLEXPORT void evConfig (evEventList *list);

DLLEXPORT void evListUserData (evEventList *list, void *data);
DLLEXPORT void *evGetListUserData(evEventList *list);
DLLEXPORT void evGetAllLists (evEventList ***lists, int *num);

DLLEXPORT evEvent *evStart (evEventList *list, int eventClass);
DLLEXPORT void evEnd (evEventList *list, evEvent *event);

DLLEXPORT evEvent *evFrame (evEventList *list, int eventClass);

DLLEXPORT evEvent *evStartT (evEventList *list, int eventClass, TIMEVAL *time);
DLLEXPORT void evEndT (evEventList *list, evEvent *event, TIMEVAL *time);

DLLEXPORT void evSetInfo (evEventList *list, evEvent *event, int index, int info);

DLLEXPORT void evWriteList (char *file, evEventList *list);
DLLEXPORT evEventList *evReadList (char *file);
DLLEXPORT void evWriteAllLists (char *file);
DLLEXPORT evEventList *evMergeLists (int num, evEventList **lists);

DLLEXPORT void evPrintTotals (FILE *fp, evEventList *list);

DLLEXPORT int evGetEventClassId(evEventList *list, char *name);
DLLEXPORT int evGetInfoId(evEventList *list, int eventClass, char *name);
DLLEXPORT int evGetFreeClassId (evEventList *list);

#ifdef __cplusplus
}
#endif

#endif
