#include "image.h"
#include <time.h> /* for CLK_TCK */
#include <stdlib.h> /* for malloc() */
#include <string.h> /* for memset() */
#include <unistd.h> /* for getpid() */
#ifndef __APPLE__
#include <GL/gl.h>  /* for glxxxEXT externs */
#else
#include <OpenGL/gl.h>
#endif


#ifndef _LINUXSTUBS_H_
#define _LINUXSTUBS_H_

#ifdef __cplusplus
extern "C" {
  void linuxSTUB();
}
#else
void linuxSTUB();
#endif /*PF_CPLUSPLUS_API*/



#endif /*_LINUXSTUBS_H_*/

