#ifndef	__TIMEVAL_H__
#define	__TIMEVAL_H__

#ifndef	WIN32
#include "sys/time.h"
#else
#include "windows.h"
#endif

#ifdef __LOCAL_BUILD__
#include "pfDLL.h"
#else
#include <Performer/pfDLL.h>
#endif


#ifdef __cplusplus
extern "C"
{
#endif

DLLEXPORT int compare_timeval (struct timeval *a, struct timeval *b);
DLLEXPORT long subtract_timeval (struct timeval *a, struct timeval *b, struct timeval *c);
/* ZZZ Alex -- where is add_timeval() defined? */
int add_timeval (struct timeval *a, struct timeval *b, struct timeval *c);

#ifdef __cplusplus
}
#endif

#endif	/* __TIMEVAL_H__ */
