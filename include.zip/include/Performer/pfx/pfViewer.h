//
// Copyright 2001, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// This source code ("Source Code") was originally derived from a
// code base owned by Silicon Graphics, Inc. ("SGI")
// 
// LICENSE: SGI grants the user ("Licensee") permission to reproduce,
// distribute, and create derivative works from this Source Code,
// provided that: (1) the user reproduces this entire notice within
// both source and binary format redistributions and any accompanying
// materials such as documentation in printed or electronic format;
// (2) the Source Code is not to be used, or ported or modified for
// use, except in conjunction with OpenGL Performer; and (3) the
// names of Silicon Graphics, Inc.  and SGI may not be used in any
// advertising or publicity relating to the Source Code without the
// prior written permission of SGI.  No further license or permission
// may be inferred or deemed or construed to exist with regard to the
// Source Code or the code base of which it forms a part. All rights
// not expressly granted are reserved.
// 
// This Source Code is provided to Licensee AS IS, without any
// warranty of any kind, either express, implied, or statutory,
// including, but not limited to, any warranty that the Source Code
// will conform to specifications, any implied warranties of
// merchantability, fitness for a particular purpose, and freedom
// from infringement, and any warranty that the documentation will
// conform to the program, or any warranty that the Source Code will
// be error free.
// 
// IN NO EVENT WILL SGI BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT
// LIMITED TO DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES,
// ARISING OUT OF, RESULTING FROM, OR IN ANY WAY CONNECTED WITH THE
// SOURCE CODE, WHETHER OR NOT BASED UPON WARRANTY, CONTRACT, TORT OR
// OTHERWISE, WHETHER OR NOT INJURY WAS SUSTAINED BY PERSONS OR
// PROPERTY OR OTHERWISE, AND WHETHER OR NOT LOSS WAS SUSTAINED FROM,
// OR AROSE OUT OF USE OR RESULTS FROM USE OF, OR LACK OF ABILITY TO
// USE, THE SOURCE CODE.
// 
// Contact information:  Silicon Graphics, Inc., 
// 1600 Amphitheatre Pkwy, Mountain View, CA  94043, 
// or:  http://www.sgi.com
//
//

#ifndef pfViewer_h
#define pfViewer_h 1

// pfObject
#include <Performer/pr/pfObject.h>

#include <Performer/pr/pfLinMath.h>
class pfLightSource;
class pfEarthSky;
class pfPipeWindow;
class pfPipe;
class pfChannel;
class pfScene;
class pfNode;

class pfDrawAction;
class pfViewer;

#define PFVIEWER_MONO 0
#define PFVIEWER_QUAD_BUFFERED_STEREO 1
#define PFVIEWER_TOP_BOTTOM_STEREO 2

#define PFVIEWER_DEFAULT_HEIGHT 600
#define PFVIEWER_DEFAULT_WIDTH  600

#define PFVIEWER_DEFAULT_CONVERGENCE 0.2f
#define PFVIEWER_DEFAULT_INTEROCULAR_DISTANCE 2.0f

#define PFVIEWER ((pfViewer*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFVIEWERBUFFER ((pfViewer*)buf->pf_indexUpdatable(this))

class pfViewer : public pfObject
{
  public:
      virtual ~pfViewer();

      static void init();

      static pfType* getClassType();

      pfLightSource* getHeadLight() const;

      void setHeadLight(pfLightSource* headlight);

      pfEarthSky* getESky() const;

      void setESky(pfEarthSky* eSky);

      void loadModel(char* filename, int optimize = 1);

      void setSceneGraph(pfNode* newRoot, int optimize = 0);

      //	Returns pfNode* that corresponds to the modelRoot. Note
      //	that if you change the hierarchy of the Scene at any
      //	point above this node then the behaviour of this class
      //	is undefined. (don't manipulate the scene graph directly
      //	by retreiving the pfScene* for the channel(s) associated
      //	with this pfViewer or ....)
      pfNode* getSceneGraph() const;

      void updateView();

      //	Convenience method to retreive specified pfChannel
      //	associated with the pfPipeWindow that this pfViewer
      //	encapsulates.
      pfChannel* getChannel(int i = 0);

      //	Convenience method to retreive the number of channels
      //	associated with the pfPipeWindow that this pfViewer
      //	encapsulates.
      int getNumChannels() const;

      //	Returns pfPipeWindow associated with this pfViewer.
      pfPipeWindow* getPipeWindow() const;

      void resetToHomePosition();

      //	Sets current view as view to be used for home position.
      void saveHomePosition();

      //	Convincence method used to retreive pointer to pfScene
      //	for the pfChannel(s) that this pfViewer encapsulates.
      pfScene* getScene(int whichChannel = 0) const;

      int getWidth() const;

      int getHeight() const;

      void setWidth(int width);

      void setHeight(int height);

      void setWinSizes(int width, int height);

      void setOriginSize(int origX, int origY, int width, int height);

      int getXOrigin() const;

      int getYOrigin() const;

      Window getXWin() const;

      Window getGXWin() const;

      pfCoord& getView();

      void setView(pfCoord& view);

      int getLoadNewModelFlag() const;

      const char* getLoadFilename();

      pfDrawAction* getDrawAction(int i = 0);

      void setDrawAction(int i, pfDrawAction* drawAction);

      void setInterOcularDistance(float distance);
      void setConvergenceRatio(float ratio);

      //	This method is the one that gets invoked by setting the
      //	traversal function for the draw on the given channel. It
      //	in turn will call the pre-draw, draw and post-draw
      //	methods associated with the drawAction specified for the
      //	given channel.
      static void drawCB(pfChannel *channel, void *data);

      int getStereoMode() const;

      //	Virtual method used to show viewer. Note that this
      //	method gets called by the viewer manager and should not
      //	be called directly in user code. In addition to
      //	displaying the viewer, this method should also call
      //	setXWin() and setGXWin().
      virtual void show();

      //	after calling pfViewer::show() this gets called by the
      //	viewer manager on the given pfViewer to indicate that it
      //	is now visible on screen so that if any processes that
      //	have been waiting for this event to occur may unblock.
      void setShowing(int yesOrNo);

      int isShowing() const;

	struct channelCallbackDataType {
		pfDrawAction *drawAction;
		pfViewer     *viewer;
		int	     leftOrRight;
		channelCallbackDataType() :
		  leftOrRight(0), drawAction(0), viewer(0) {}

		PFSTRUCT_DECLARE;
	};

      Display *getDisplay() const { return _dpy; }

      virtual void viewAll();

      void initInput(int inputType);

  protected:
      //	Creates a new pfViewer which in turn creates a
      //	pfPipeWindow and all associated channels as well as a
      //	single pfScene ptr which is associated to the channel(s).
      //
      //	Note that you should not specify a traversal function
      //	for PFTRAV_DRAW or specify channel data for the channels
      //	associated with the pfPipeWindow as this will cause this
      //	viewer's callbacks to get overriden. Specifying user
      //	data can be done instead via pfObject::setUserData() and
      //	retreived via ::getUserData() (on this object.) As for
      //	the draw callback on the channel, the user can instead
      //	specify a pre or post channel draw callback by using a
      //	specialized pfDrawAction.
      pfViewer(pfPipe* p = NULL, int numChannels = 1, int stereoMode = PFVIEWER_MONO,int *attrs = NULL);


      void setLoadNewModelFlag(int flag);

      void setLoadFilename(const char* filename);

      void setXWin(Window win);

      void setGXWin(Window win);

      void setDisplay(Display *dpy) { _dpy = dpy; }


  private:
      static void openPipeWin(pfPipeWindow *pw);

      void setChannelOffsets(pfChannel *channel,int leftOrRight,
                             float oldConvRatio=0.0f,float oldIOD=0.0f);

      int *getFBAttrs();
      void setFBAttrs(int *);

      void setStereo(int onOrOff) { _gotStereo = onOrOff; }
      int  gotStereo() const { return _gotStereo; }

      float _convergenceRatio, _interOcularDistance;
      int *_fbAttrs;
      int _numChannels;
      Display *_dpy;
      static pfType* classType;
      Window _xWin;
      Window _gXWin;
      pfCoord _view;
      pfCoord _viewOrig;
      int _loadNewModel;
      char _loadFileName[PF_MAXSTRING];
      pfPipeWindow* _pipeWindow;
      int _resetViewFlag;
      pfScene* _scene;
      pfNode* _modelRoot;
      pfLightSource* _headlight;
      pfEarthSky* _eSky;
      int _width;
      int _height;
      int _origX;
      int _origY;
      int _drawActionSharing;
      pfList* _channelCallbackData;
      int _stereoMode, _gotStereo;
      int _showing;
};

// Class pfViewer 

#endif


