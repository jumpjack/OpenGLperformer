//
// Copyright 2001, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// This source code ("Source Code") was originally derived from a
// code base owned by Silicon Graphics, Inc. ("SGI")
// 
// LICENSE: SGI grants the user ("Licensee") permission to reproduce,
// distribute, and create derivative works from this Source Code,
// provided that: (1) the user reproduces this entire notice within
// both source and binary format redistributions and any accompanying
// materials such as documentation in printed or electronic format;
// (2) the Source Code is not to be used, or ported or modified for
// use, except in conjunction with OpenGL Performer; and (3) the
// names of Silicon Graphics, Inc.  and SGI may not be used in any
// advertising or publicity relating to the Source Code without the
// prior written permission of SGI.  No further license or permission
// may be inferred or deemed or construed to exist with regard to the
// Source Code or the code base of which it forms a part. All rights
// not expressly granted are reserved.
// 
// This Source Code is provided to Licensee AS IS, without any
// warranty of any kind, either express, implied, or statutory,
// including, but not limited to, any warranty that the Source Code
// will conform to specifications, any implied warranties of
// merchantability, fitness for a particular purpose, and freedom
// from infringement, and any warranty that the documentation will
// conform to the program, or any warranty that the Source Code will
// be error free.
// 
// IN NO EVENT WILL SGI BE LIABLE FOR ANY DAMAGES, INCLUDING, BUT NOT
// LIMITED TO DIRECT, INDIRECT, SPECIAL OR CONSEQUENTIAL DAMAGES,
// ARISING OUT OF, RESULTING FROM, OR IN ANY WAY CONNECTED WITH THE
// SOURCE CODE, WHETHER OR NOT BASED UPON WARRANTY, CONTRACT, TORT OR
// OTHERWISE, WHETHER OR NOT INJURY WAS SUSTAINED BY PERSONS OR
// PROPERTY OR OTHERWISE, AND WHETHER OR NOT LOSS WAS SUSTAINED FROM,
// OR AROSE OUT OF USE OR RESULTS FROM USE OF, OR LACK OF ABILITY TO
// USE, THE SOURCE CODE.
// 
// Contact information:  Silicon Graphics, Inc., 
// 1600 Amphitheatre Pkwy, Mountain View, CA  94043, 
// or:  http://www.sgi.com
//
//

#ifndef pfViewerManager_h
#define pfViewerManager_h 1

// pfObject
#include <Performer/pr/pfObject.h>

#define PFVMAN_FRAME_RATE 1
#define PFVMAN_PHASE 2
#define PFVMAN_FORK_GUI 3
#define PFVMAN_EVENT_SAMPLING 4
#define PFVMAN_RUN_TIME 5
#define PFVMAN_WIN_MODE 6 // XXX Alex -- still useful?

class pfList;
class pfType;
class pfViewer;

// XXX --- remove this header file
#include <Performer/pfutil.h>
typedef void (funcPtr)(pfViewer *viewer,void *data);
typedef void (eventFuncPtr)(pfuEventStream *);

#define PFVIEWERMANAGER ((pfViewerManager*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFVIEWERMANAGERBUFFER ((pfViewerManager*)buf->pf_indexUpdatable(this))

class pfViewerManager : public pfObject
{
  public:
      static void init(int argc, char **argv);
      static pfType* getClassType();
      static void addViewer(pfViewer* viewer);
      static int removeViewer(pfViewer* viewer);

      //	This method behaves much in the same fashion as
      //	pfConfig. Note that contrary to pfConfig(), you can
      //	specify a number of values in a via a NULL terminated
      //	variable argument list. The current list of
      //	argument/value pairs are:
      //
      //	PFVMAN_FRAME_RATE frameRate
      //	  will set frame rate via pfFrameRate()
      //	PFVMAN_PHASE phase
      //	  will set phase via pfPhase()
      //	PFVMAN_FORK_GUI yesOrNo
      //	  toggle to determine wether or not to fork GUI process
      //	if using a viewer derived from pfGUIViewer
      //	PFVMAN_EVENT_SAMPLING filename
      //	  file to use for event sampling logs
      //	PFVMAN_RUN_TIME runTime
      //	  amount of time to run program for (0 == forever)
      //	PFVMAN_WIN_MODE winMode
      //	  will use winMode for setting attributes on associated
      //	pipe window for all pfViewers in application (upon
      //	creation.)
      //
      //	Any Performer calls that are valid between pfInit() and
      //	pfConfig() can also be performed between
      //	pfViewerManager::init() and pfViewerManager::config().
      static void config(int arg, ... );

      //	convenience method that calls config() with single
      //	parameter indicating no special arguments are used for
      //	running program.
      static void config();

      static void setExitFlag();

      static void mainLoop();

      static void finish();

      static void initPipes();

      static int simFrame();

      static pfViewer * getViewer(int i = 0);

      static int getNumViewers();

      //	Returns true if there is a separate draw process, false
      //	otherwise. This method is used by the
      //	pfGUIViewer:mapUnmapCB() to determine what action to
      //	take when window(s) are map and unmapped.
      static int forkedGUI();

      static int getArgc();

      static char** getArgv();

      static void setPostFrameFuncPtr(funcPtr* f, void* data);

      static funcPtr* getPostFrameFuncPtr(void** data);

      static void setPostSyncFuncPtr(funcPtr* f, void* data);

      static funcPtr* getPostSyncFuncPtr(void** data);

      static void setReturnValueForCallbacks(int value);

      static int getWinMode();

      static void usingPFUEvents(int onOrOff);
      static int  isUsingPFUEvents() { return _usingPFUEvents; }

      static pfuMouse *getPFUMouse() { return _mouse; }
      static pfuEventStream *getPFUEventStream() { return _events; }
      static void setEventsFuncPtr(eventFuncPtr *ptr);

  private:
      //	We don't want to allow anyone the possibility of
      //	creating a pfViewerManager so we make it's constructor
      //	private.
      pfViewerManager();


      static void doGUI();
      static void processEvents();

      static pfType *classType;
      static pfList* _viewers;
      static int* _exitFlag;
      static int* _forkGUI;
      static char *_eventSamplingFilename;
      static double _runTime;
      static int _argc;
      static char** _argv;
      static funcPtr* _postFrameFuncPtr;
      static void* _postFrameData;
      static funcPtr* _postSyncFuncPtr;
      static void* _postSyncData;
      static int _returnValueForCallbacks;
      static int _winMode;

      static int _usingPFUEvents;
      static pfuMouse *_mouse;
      static pfuEventStream *_events;

      static eventFuncPtr *_processEventsFuncPtr;
};

// Class pfViewerManager 

#endif
