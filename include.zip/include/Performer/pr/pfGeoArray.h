//
//
// Copyright 2003,2004 Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfGeoArray.h
//
// $Revision: 1.25 $
// $Date: 2005/06/22 22:12:02 $
//
//

#ifndef __PF_GEOARRAY_H__
#define __PF_GEOARRAY_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

// Includes ///////////////////////////

// For 3.2 minor releases, need to define this flag
// Enables some ugly hacks, but allows cache management stuff 
// to work without breaking binary compatibility
// For binary comp, we use a void*, vertexBlock for the record list.
#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
#error "Fix pfGeoArrayCacheManager binary compatibility hacks!"
#else
#define GA_BINARY_COMP
#endif

#include <Performer/pr/pfGeoSet.h>

// define (standard OpenGL) array types 
// customized implies callback function not a gl*Pointer 

// Constants //////////////////////////

// Exported Tokens

extern "C" { 	/* EXPORT to CAPI */
/* define standard vertex array attr types */
#define PFGA_CUSTOMIZED		-1
#define PFGA_COORD_ARRAY	1
#define PFGA_NORMAL_ARRAY	2
#define PFGA_COLOR_ARRAY	3
#define PFGA_COLOR2_ARRAY	4
#define PFGA_FOG_ARRAY		5
#define PFGA_WEIGHT_ARRAY	6
#define PFGA_TEX_ARRAY 		7
#define PFGA_GENERIC_ARRAY	8
}


// Class Declarations /////////////////

class pfVertexAttr;
class pfGeoArray;

// Class Definitions //////////////////

// VertexAttr /////////////////////////

//CAPI:struct
struct DLLEXPORT pfVertexAttr
{
public:

    //CAPI:basename VAttr
    pfVertexAttr(pfGeoArray *parent,int attrType);
    ~pfVertexAttr();


    void setName(char *name);

    char *getName() const;
    pfFunc getGLFunc() const;

    // getClientState() will return one of GL_VERTEX_ARRAY, GL_NORMAL_ARRAY, 
    // GL_COLOR_ARRAY, GL_TEXTURE_COORD_ARRAY or 0 for generic data.
    GLenum getClientState() const;

    unsigned short getMask() const;
    short getInstance() const;
    short getMaskOff() const;

    void* getPtr() const;
    GLsizei getStride() const;
    GLenum getDataType() const;
    short  getSize() const;

    void setPtr(void *data);
    void setStride(GLsizei stride);
    void setDataType(GLenum type);
    void setSize(short size);

    void setAll(void *ptr,GLsizei stride,GLenum type,short size);

    int copy(const pfVertexAttr *_src);
    int compare(const pfVertexAttr *_obj) const;
    
    PFSTRUCT_DECLARE
};

// GeoArray ///////////////////////////

#define PFGEOARRAY ((pfGeoArray*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFGEOARRAYBUFFER ((pfGeoArray*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfGeoArray : public pfGeoSet
{
public:
    // constructors and destructors
    // CAPI:basename GArray
    pfGeoArray();
    virtual ~pfGeoArray();

public:

    // per class functions
    static void	   init();
    static pfType* getClassType() { return classType; }
	
    // virtual
    virtual int copy(const pfMemory *_src);
    virtual int compare(const pfMemory *_obj) const;

    // calls to setup Vertex Array Attributes Types
    //CAPI:verb GArrayAddAttrType
    pfVertexAttr* addAttrType(int type,char* name,int stage);

    // get existing ArrayAttr pointer by name
    //CAPI:verb GArrayQueryAttrTypeByName
    pfVertexAttr* queryAttrType(char *_name) const;
    // or by attrType which is one of PFGA_COORD_ARRAY, PFGA_NORMAL_ARRAY,
    // PFGA_TEX_ARRAY, PFGA_COORD_ARRAY or 0 for a generic array.

    //CAPI:verb GArrayQueryAttrType
    pfVertexAttr* queryAttrType(int attrType) const;
    //CAPI:verb GArrayQueryAttrTypeStage
    pfVertexAttr* queryAttrType(int attrType,int inst) const;

    int getNumAttrsOfType(int attrType) const;

    //
    // setup array data with given ArrayAttr
    //CAPI:verb GArrayAddAttr
    void addAttr(pfVertexAttr *ai, int size, GLenum type, GLsizei stride, void *ptr);

    //CAPI:virtual
    void setAttr(int _attr, int _bind, void* _alist, unsigned short* _ilist);
    //CAPI:virtual
    void setMultiAttr(int _attr, int _index, int _bind, void* _alist, unsigned short* _ilist);

    //CAPI:virtual
    int         getAttrBind(int _attr) const;
    //CAPI:virtual
    int         getMultiAttrBind(int _attr, int _index) const;

    //CAPI:virtual
    void        getAttrLists(int _attr, void** _alist, unsigned short** _ilist) const;
    //CAPI:virtual
    void        getMultiAttrLists(int _attr, int _index, void** _alist, unsigned short** _ilist) const;
    //CAPI:virtual
    int         getAttrRange(int _attr, int *_min, int *_max) const;
    //CAPI:virtual
    int         getMultiAttrRange(int _attr, int _index, int *_min, int *_max) const;

    //CAPI:verb GArraySetAttr
    pfVertexAttr* setAttr(int attrType,int size,GLenum type,GLenum stride,void *ptr);
    //CAPI:verb GArraySetMultiAttr
    pfVertexAttr* setMultiAttr(int attrType,int stage,int size,GLenum type,GLenum stride,void *ptr);

    // remove Attributes (permanently)
    void removeAttr(pfVertexAttr *ai);

    // disable/enables
    void disableAttr(pfVertexAttr *ai);
    void enableAttr(pfVertexAttr *ai);

    // GeoArray Index (differs/conflicts with GeoSet Index)
    // use GeoSet's "lengths" to set tri-strip lengths
    //CAPI:verb GArrayIndexArray
    void  setIndexArray(unsigned int *iarray);

#if 0
    //CAPI:verb GArrayIndexArrayShort
    void setIndexArray(unsigned short *iarray);
    //CAPI:verb GArrayIndexArrayByte
    void setIndexArray(unsigned char *iarray);
#endif

    //CAPI:verb GetGArrayIndexArray
    unsigned int* getIndexArray() const;

#if 0
    GLenum getIndexArrayType() const;
#endif

    // VA Cache Controls
    void allowCache(int x);
    
    // call when vertex data is changed, will update cache
    void updateData();

    // support for gathering all array data
    //CAPI:verb GetGArrayNumAttrs
    int getNumAttrs() const;
    //CAPI:verb GetGArrayNthAttr
    pfVertexAttr* getNthAttr(int n) const;

    // is Standard if all function pointers go to gl calls, not user code
    //CAPI:verb GArrayIsStandardArray
    int isStandardArray(pfVertexAttr *ai, int *gtype, int *gindex);

    // byte length of array data and sizeof element (ie float=4, short=2)
    //CAPI:verb GetGArrayArrayMemSize
    int getArrayMemSize(pfVertexAttr *ai, int *elemSize);

public:

    virtual void pr_virtualDraw(void);
    void setDrawIndex(void);
    // here attr type corresponds to one of PFGA_XXX.
    int XformAttr(GLenum attrType, int ptType, pfMatrix *xform);
    
    //CAPI:verb GArraySetupCoords   
    static void setupCoords(pfGeoArray *dis);

    //CAPI:verb GArrayCleanupCoords
    static void cleanupCoords(pfGeoArray *dis);


private:
#ifdef GA_BINARY_COMP
#endif
    int getIdIndex(pfVertexAttr *, int inst) const;
    int getIdIndex(int attrType, int inst) const;
#ifdef GA_BINARY_COMP
    int tryVAOcache();
    void drawVAOcached();
#endif
    static pfType *classType;
    pfList *vertexAttrs;
    unsigned int *index_array;
#if 0
    GLenum indexArrayType;
#endif

#ifdef GA_BINARY_COMP
    // Data caching information
    void *vertexBlock;
    void *indexBlock;

    int index_vaOffset;
    int vaoIndex;
#else    
#endif

    unsigned short gaFlags;	// geoArray flags
    int vtotal;
};

#endif // !__PF_GEOARRAY_H__
