//
//
// Copyright 2003, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfGProgram.h
//    Generic/GPU program base class
//
// $Id: pfGProgram.h,v 1.8 2004/06/14 17:23:33 naaman Exp $
// 
//

#ifndef __PF_GPROG_H__
#define __PF_GPROG_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfObject.h>
#include <Performer/pr/pfState.h>

//////////////////////////////////// pfGProgram ////////////////////////////////////


/* ------------------ pfGProgram Related Functions--------------------- */

extern "C" { 	// EXPORT to CAPI
#define PF_MAX_PGTYPE 2
}

extern  DLLEXPORT pfVertexProgram*   pfGetCurVProg(void);

#define PFGPROGRAM ((pfGProgram*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFGPROGRAMBUFFER ((pfGProgram*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfGProgram : public pfObject
{
public:
    pfGProgram();
    virtual ~pfGProgram();

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }

public:
    // virtual functions
    virtual int compare(const pfMemory *_mem) const;
    virtual int copy(const pfMemory *_src);
    virtual int print(uint _travMode, uint _verbose, char *_prefix, FILE *_file);

    virtual int getGLHandle() const;
    virtual void deleteGLHandle(); // aka pfTexture -- needed?
    
public:
    // sets and gets

    // base functions, subclasses inline to call this, passing type
    int   loadProgram(const char *filename);
    void  setProgram(const char *code);
    // CAPI:verb GProgramProgramLen
    void  setProgram(const char *code, int length);
    // CAPI:noverb 
    void  getProgram(char **code)const { *code = program; }
	
    // Querys for currently bound program should work for all types 
    int		getProgramLength();				// querys
    int		getNativeProgramLength();
    int		isValid();
	
public:
    // other functions
    void	apply();


PFINTERNAL: // XXX - should make protected???

    int		index;	// unique descriptor 
    char	*program;
    int		dirty;	// for changes after binding 
    int 	iCount, niCount;   // gl instruction count, native instruction count
    ushort	valid;
    ushort	progLen;
    short	progType;	// ARB_Vertex, or ARB_Fragment Programs

private:
    static pfType   *classType;
};


#endif	// !__PF_GPROG_H__
