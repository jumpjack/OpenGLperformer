//
//
// Copyright 2004, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfShaderProgram.h
//
// $Id: pfShaderProgram.h,v 1.13 2005/02/17 02:30:55 naaman Exp $
// 
//

#ifndef __PF_SHADERPROG_H__
#define __PF_SHADERPROG_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfObject.h>
#include <Performer/pr/pfState.h>
#include <Performer/pr/pfGProgram.h>
#include <Performer/pr/pfShaderObject.h>
#include <Performer/pr/pfStruct.h>

//////////////////////////////////// pfShaderProgram ////////////////////////////////////

/* ------------------ pfShaderProgram Related Functions--------------------- */
extern  DLLEXPORT pfShaderProgram*   pfGetCurSProg(void);

#define PFSHADERPROGRAM ((pfShaderProgram*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSHADERPROGRAMBUFFER ((pfShaderProgram*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfShaderProgram : public pfObject
{
public:
    // constructors and destructors
    //CAPI:basename SProg
    pfShaderProgram();
    virtual ~pfShaderProgram();

    void addShader(pfShaderObject *shader);
    int  getNumShaders();
    pfShaderObject* getShader(int i);
    void removeShader(pfShaderObject *shader);
    void replaceShader(pfShaderObject *_old,pfShaderObject *_new);

    //CAPI:verb SProgReplaceShaderIndex
    void replaceShader(int i,pfShaderObject *replacement);

    // XXX Alex .. how about remove all ...

    void apply();
     
    // returns 0 if ok, -1 if handle is NULL or other error occured
    // and positive integer indicating how many pfShaderObjects
    // did *not* compile successfully during link failure.
    int link(GLcharARB *log = NULL);

    // force re-linking of program even though Performer
    // doesn't think we need to.
    int forceRelink(GLcharARB *log = NULL);

    GLboolean validate();
#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
#error "remove this if statement for 3.3"
    GLhandleARB getHandle() const { return program; }
#endif

    GLint findUniform(const GLcharARB *name);
    // uniType is one of PFUNI_XXX type
    //CAPI:verb SProgAddUniform
    GLint addUniform(const GLcharARB *name,unsigned int uniType,int size,void *data);
    void setUniform(GLint whichOne,void *data);
    GLint getUniformDataSize(GLint whichOne) const;
    // XXX Alex -- why don't we generate the name for this one correctly?
    //CAPI:verb GetSProgNumUniforms
    int getNumUniforms();

    //CAPI:verb GetSProgUniformData
    void* getUniformData(int whichOne);
    //CAPI:verb GetSProgUniformName
    char* getUniformName(int whichOne);
    //CAPI:verb GetSProgUniformVals
    int   getUniformNumVals(int whichOne);
    //CAPI:verb GetSProgUniformType
    int   getUniformType(int whichOne);

    //CAPI:verb GetSProgUniformClampMode
    char getUniformClampMode(int whichOne) const;
    //CAPI:verb SProgUniformClampMode
    void setUniformClampMode(int whichOne,char clampMode);
    
    //CAPI:verb GetSProgUniformMin
    void *getUniformMin(int whichOne) const;
    //CAPI:verb GetSProgUniformMax
    void *getUniformMax(int whichOne) const;
    //CAPI:verb SProgUniformMin
    void  setUniformMin(int whichOne,void *data);
    //CAPI:verb SProgUniformMax
    void  setUniformMax(int whichOne,void *data);

    //CAPI:verb GetSProgUniformNormalizedFlag
    char getUniformNormalizedFlag(int whichOne) const;
    //CAPI:verb SProgUniformNormalizedFlag
    void setUniformNormalizedFlag(int whichOne,char onOrOff);

    int compare(const pfMemory *_mem) const;
    int copy(const pfMemory *_src);

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }
    static int getUniTypeSize(int uniType);

#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
#error "remove this if statement for 3.3"
    virtual int         getGLHandle() const;
    virtual void	deleteGLHandle();
#endif


private:
    static pfType   *classType;
    pfList *shaders;
    GLhandleARB program;

#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
#error "remove this if statement for 3.3"
    int index; /* XXX Alex -- get rid of handle to program and use this instead */
#endif
    int numUniforms, dirty;

    pfList *uniforms;

    struct _pfUniform {
        PFSTRUCT_DECLARE;

	GLcharARB *name;
        int location, numVals;
        GLenum uniType;
        void *data, *minVal, *maxVal;
        int dataSize;
        int dirtyUni;
        char clampMode, isNormalized;
        short flags;

        _pfUniform();
        ~_pfUniform();

        GLint getLocation() const { return location; }
        GLcharARB *getName() const { return name; }
        void* getData() const { return data; }
        GLenum getType() const { return uniType; }
        int getDataSize() const { return dataSize; }
        int getNumVals() const { return numVals; }
        int getDirty() const { return dirtyUni; }

	void setLocation(int location);
	void setName(const GLcharARB *name);
	void setData(void *data,int size,int numVals);
        void setData(void *data);
	void setType(GLenum uniType);

        void* getMin() const { return minVal; }
        void* getMax() const { return maxVal; }
        void  setMin(void *data);
        void  setMax(void *data);
        char  getClampMode() const { return clampMode; }
        void  setClampMode(char mode);

        char getNormalizedFlag() const { return isNormalized; }
        void setNormalizedFlag(char onOrOff);

        int pr_setValue() const;
        void normalize();
        void clamp(void *origValue);

        int compare(const _pfUniform *_mem) const;

        void *_pfUniformExtraData;
    };


    void *_pfShaderProgramExtraData;
};

#endif	// !__PF_SHADERPROG_H__
