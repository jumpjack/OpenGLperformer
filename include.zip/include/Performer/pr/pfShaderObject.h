//
//
// Copyright 2004, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfShaderObject.h
//
// $Id: pfShaderObject.h,v 1.7 2005/02/17 02:30:55 naaman Exp $
// 
//

#ifndef __PF_SHADER_OBJECT_H__
#define __PF_SHADER_OBJECT_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfObject.h>
#include <Performer/pr/pfShaderProgram.h>

//////////////////////////////////// pfShaderObject ////////////////////////////////////


extern "C" {
#define PFSHD_OBJECT_TYPE                              0
#define PFSHD_OBJECT_SUBTYPE                           1
#define PFSHD_OBJECT_DELETE_STATUS                     2
#define PFSHD_OBJECT_COMPILE_STATUS                    3
#define PFSHD_OBJECT_INFO_LOG_LENGTH                   4
#define PFSHD_OBJECT_SHADER_SOURCE_LENGTH              5
#define PFSHD_OBJECT_MAX_QUERY_VAL                     PFSHD_OBJECT_SHADER_SOURCE_LENGTH

#define PFSHD_FRAGMENT_SHADER 0x1
#define PFSHD_VERTEX_SHADER   0x2
}



/* ------------------ pfShaderObject Related Functions--------------------- */

#define PFSHADEROBJECT ((pfShaderObject*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFSHADEROBJECTBUFFER ((pfShaderObject*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfShaderObject : public pfObject
{
public:
    // constructors and destructors
    //CAPI:private
    pfShaderObject(int type,GLint numStrings,const GLcharARB **strings=NULL,GLint *lengths=NULL);

    // if you use this constructor then you'll need to make subsequent calls to
    // setShaderType() and setSource().
    //CAPI:public
    pfShaderObject();

    // XXX Alex -- provide alternate constructor which just takes one string and the type

    virtual ~pfShaderObject();

    // will return one of PFSHD_FRAGMENT_SHADER or PFSHD_VERTEX_SHADER
    // or -1 if unset.
    int getShaderType() const { return shaderType; }
    
    // this will (if not yet already done) create the shader
    void setShaderType(int shdType);

    const char *getName() const;
    void setName(const char *name);

    void load(); 

    void setSource(GLcharARB *src);
    //CAPI:verb ShaderSourceWithArgs
    void setSource(GLint numStrings,const GLcharARB **src,GLint *lengths);

    //CAPI:verb GetShaderObjectSource
    char *getSource() const { return (char *)source; }

    // returns 1 if recompile req'd, 0 otherwise
    int getCompileStatus() const;

    // if you want to store the results of the compilation log
    // make the 'log' parameter non null.
    // This will return 1 if successful
    GLboolean compile(char **log = NULL);

#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
    virtual int         getGLHandle() const;
    virtual void        deleteGLHandle();
#error "Fix shader object binary compatablity hacks - remove getHandle() method"
#else
    GLhandleARB getHandle() const; // XXX Alex - deprecate this...
#endif


    int getAttr(int what) const;

    int compare(const pfMemory *_mem) const;
    int copy(const pfMemory *_src);

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }


private:
    void pr_init();
    int  pr_createShader();
    void pr_setSource(GLcharARB *src);
    void pr_reallySetSource();

    static pfType   *classType;

    int shaderType, dirty;
#if (PFMAJOR_VERSION == 3 && PF_MINOR_VERSION > 2)
#error "remove this ifdef and don't use _pfShaderObjectExtraData any more for 3.3"
    int index;
#endif
    GLhandleARB handle;
    GLcharARB *source;
    pfList *spList;
    char *name;

    void *_pfShaderObjectExtraData;
};

#endif	// !__PF_SHADER_OBJECT_H__
