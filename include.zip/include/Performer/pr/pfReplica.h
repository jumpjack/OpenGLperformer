//
//
// Copyright 1997, Silicon Graphics, Inc.
// ALL RIGHTS RESERVED
//
// UNPUBLISHED -- Rights reserved under the copyright laws of the United
// States.   Use of a copyright notice is precautionary only and does not
// imply publication or disclosure.
//
// U.S. GOVERNMENT RESTRICTED RIGHTS LEGEND:
// Use, duplication or disclosure by the Government is subject to restrictions
// as set forth in FAR 52.227.19(c)(2) or subparagraph (c)(1)(ii) of the Rights
// in Technical Data and Computer Software clause at DFARS 252.227-7013 and/or
// in similar or successor clauses in the FAR, or the DOD or NASA FAR
// Supplement.  Contractor/manufacturer is Silicon Graphics, Inc.,
// 2011 N. Shoreline Blvd. Mountain View, CA 94039-7311.
//
// THE CONTENT OF THIS WORK CONTAINS CONFIDENTIAL AND PROPRIETARY
// INFORMATION OF SILICON GRAPHICS, INC. ANY DUPLICATION, MODIFICATION,
// DISTRIBUTION, OR DISCLOSURE IN ANY FORM, IN WHOLE, OR IN PART, IS STRICTLY
// PROHIBITED WITHOUT THE PRIOR EXPRESS WRITTEN PERMISSION OF SILICON
// GRAPHICS, INC.
//
// pfReplica.h
//
// $Revision: 1.8 $
// $Date: 2004/06/14 17:23:33 $
//

#ifndef __PF_REPLICA_H__
#define __PF_REPLICA_H__

#ifndef PF_CPLUSPLUS_API
#define PF_CPLUSPLUS_API 1
#else
#if !PF_CPLUSPLUS_API
#error "Cannot include C++ API header with PF_CPLUSPLUS_API disabled."
#endif
#endif

#include <Performer/pr/pfMemory.h>
#include <Performer/pr/pfList.h>
#include <Performer/pr/pfState.h>
#include <Performer/pr/pfLinMath.h>
#include <Performer/pr/pfEngine.h>

class pfReplica;

#if defined(__sgi) && !defined(_ABIO32)
// disable warning about having an operator new, but no
// operator delete for class pfReplicaMemory
#pragma set woff 1373 
#endif

#define PFREPLICAMEMORY ((pfReplicaMemory*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFREPLICAMEMORYBUFFER ((pfReplicaMemory*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfReplicaMemory : public pfMemory
{
public:
    // new and delete
    // CAPI:private

    // operator for allocating nbytes from default arena
    void* operator      new(size_t s, size_t nybtes);
    // operator for allocating nbytes from specific arena
    void* operator      new(size_t s, size_t nbytes, void *arena);

public:
    // Constructors, destructors
    //CAPI:private
    pfReplicaMemory(pfReplica *replica);
    virtual ~pfReplicaMemory();

private:
    static pfType *classType;

public:
    // virtual functions
    // CAPI:private
    void	*getData() const {
	return (void*) (((char *)this)+sizeof(pfReplicaMemory));
    }

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }
    // CAPI:verb GetReplicaMemory
    static pfReplicaMemory* getReplicaMemory(void *data) {
	return (pfReplicaMemory*) (((char *)data)-sizeof(pfReplicaMemory));
    }
    // CAPI:noverb

public:
    // gets and sets
    pfReplica *		getReplica()	 { return parent; }

private:
    pfReplica		*parent;
#if !defined(N64) && !defined(__ia64__)
    void		*pad;		// needed to pad to double alignment
#endif
};

#ifdef __sgi
#pragma reset woff 1373
#endif

typedef struct 
{
    void 	*data;
    pfReplicaMemory *mem;
    int	  	cpuID;
    char  	*nodeName;
    int		numNodes;
} replica_buf_t;

typedef struct
{
    int		cpuID;
    int		bufferID;
} replica_assignment_t;


// Exported Tokens
extern "C" {     // EXPORT to CAPI

#define	PFREPLICA_MAX_READERS	1024

}


#define PFREPLICA ((pfReplica*)_pfCurrentBuffer->pf_indexUpdatable(this))

#define PFREPLICABUFFER ((pfReplica*)buf->pf_indexUpdatable(this))

class DLLEXPORT pfReplica : public pfObject
{
public:
    // Constructors, destructors
    pfReplica(size_t nbytes, int _numBuffers);

public:
    virtual ~pfReplica();

public:
    // per class functions;
    static void	   init();
    static pfType* getClassType() { return classType; }

public:
    // virtual functions

    virtual int		copy(const pfMemory *_src);
    virtual int		compare(const pfMemory *_mem) const;
    virtual int		print(uint _travMode, uint _verbose,
			      char *_prefix, FILE *file);

public:
    // sets and gets
    void*		getWritableData();
    void*		getReadableData();
    size_t		getDataSize(void) { return m_dataSize; }
    int			getNumReadBuffers() { return m_numReadBuffers; }

    void		writeComplete(void);

    void		assignReaderCPU(int cpuID, int bufferID);

    // CAPI:verb PlaceReplicaReadableDataByCPU
    void		placeReadableBuffer(int bufferID, int cpuID);
    // CAPI:verb PlaceReplicaReadableDataByNode
    void 		placeReadableBuffer(int bufferID, char *nodeName);

    // CAPI:verb PlaceReplicaReadableDataRRByCPU
    void		placeReadableBuffer(int bufferID, int numCPUs, int *cpuID);
    // CAPI:verb PlaceReplicaReadableDataRRByNode
    void 		placeReadableBuffer(int bufferID, int numNodes, char **nodeName);

    // CAPI:verb PlaceReplicaWritableDataByCPU
    void		placeWritableBuffer(int cpuID);
    // CAPI:verb PlaceReplicaWritableDataByNode
    void 		placeWritableBuffer(char *nodeName);

    // CAPI:verb PlaceReplicaWritableDataRRByCPU
    void		placeWritableBuffer(int numCPUs, int *cpuID);
    // CAPI:verb PlaceReplicaWritableDataRRByNode
    void 		placeWritableBuffer(int numNodes, char **nodeName);

    int			loadConfigFile(char *filename);

    int			pinBuffers();
    int			unpinBuffers();

    void 		realloc(size_t newSize);



public:
    // CAPI:verb GetReplica
    static pfReplica *	getReplica(void *_data);

private:
    void		pr_construct(size_t nbytes);

private:

    size_t 		m_dataSize;

    int 		m_numReadBuffers;
    replica_buf_t 	*m_readBuffers;
    replica_buf_t 	*m_writeBuffer;

    // Assignment of CPUs to buffers 
    // (A process on CPU `i' reads data from buffer `j');

    int				m_numAssignments;
    int				m_sizeAssignments;
    replica_assignment_t	*m_assignment;

    int				pinned;

private:
    static pfType *classType;
};

#endif // !__PF_REPLICA_H__
