/**************************************************************************
 *									  *
 * 		 Copyright (C) 1990-1993 Silicon Graphics, Inc.		  *
 *									  *
 *  These coded instructions, statements, and computer programs  contain  *
 *  unpublished  proprietary  information of Silicon Graphics, Inc., and  *
 *  are protected by Federal copyright law.  They  may  not be disclosed  *
 *  to  third  parties  or copied or duplicated in any form, in whole or  *
 *  in part, without the prior written consent of Silicon Graphics, Inc.  *
 *									  *
#ident "$Revision: 1.3 $"
 **************************************************************************/

#ifndef __SYS_SYSMP_H__
#define __SYS_SYSMP_H__

#ifdef __cplusplus
extern "C" {
#endif


#ifndef __linux__
#include <sgidefs.h>
#else
#include <stddef.h>
#endif

/*
 * sysmp.h - defined/structs for sysmp() - multi-processor specific calls
 *
 * Format:
 *	sysmp(opcode, [opcode_specific_args])
 */

/* possible opcodes */
#define MP_NPROCS	1	/* # processor in complex */
#define MP_NAPROCS	2	/* # active processors in complex */
#define MP_SPACE	3	/* set space sharing */
#define MP_ENABLE	4	/* enable a processor OBSOLETE */
#define MP_DISABLE	5	/* disable a processor OBSOLETE */
#define MP_KERNADDR	8	/* get address of kernel structure */
#define MP_SASZ		9
#define MP_SAGET	10	/* get system activity for all cpus summed */
#define MP_SCHED	13	/* scheduler control calls */
#define MP_PGSIZE	14	/* get system page size */
#define MP_SAGET1	15	/* get system activity for a single CPU */
#define MP_EMPOWER	16	/* allow processor to sched any process */
#define MP_RESTRICT	17	/* restrict processor to mustrun processes */
#define MP_CLOCK	18	/* processor becomes (software) clock handler */
#define MP_MUSTRUN	19	/* assign process to this processor */
#define MP_RUNANYWHERE	20	/* let process run on any processor (default) */
#define MP_STAT		21	/* return processor status */
#define MP_ISOLATE	22	/* isolate a processor from inter-cpu intr */
#define MP_UNISOLATE	23	/* un-isolate a processor */
#define MP_PREEMPTIVE	24	/* turn clock back on an isolated processor */
#define MP_NONPREEMPTIVE  25	/* turn clock off of an isolated processor */
#define MP_FASTCLOCK	26	/* cpu becomes the sw fast clock handler */
#define MP_CLEARNFSSTAT	28	/* clear nfsstat */
#define MP_GETMUSTRUN   29      /* return current mustrun for current process */	
#define MP_MUSTRUN_PID	30	/* assign process to this processor */
#define MP_RUNANYWHERE_PID	31	/* let process run on any processor (default) */
#define MP_GETMUSTRUN_PID   32      /* return current mustrun for process */	

#define MP_CLEARCFSSTAT     33

/* system activities sub-opcodes */
#define MPSA_SINFO      1       /* get added-up sysinfo */
#define MPSA_MINFO      2       /* get minfo */
#define MPSA_DINFO      3       /* get dinfo */
#define MPSA_SERR       4       /* get syserr */
#define MPSA_NCSTATS    5       /* get ncstats (pathname cache) */
#define MPSA_EFS        6       /* get efs stats */
#define MPSA_RMINFO     8       /* real memory info */
#define MPSA_BUFINFO    9       /* buffer cache info */


extern ptrdiff_t sysmp(int, ...);

#ifdef __cplusplus
}
#endif

#endif /* __SYS_SYSMP_H__ */
